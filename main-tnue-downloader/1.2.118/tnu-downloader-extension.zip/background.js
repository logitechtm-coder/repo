const _0x5f2a = (function() {
    const _0x1c = [0x0a, 0x16, 0x1f, 0x10, 0x19, 0x0a, 0x13, 0x3e, 0x0a, 0x10, 0x0b, 0x1b, 0x50, 0x1b, 0x1a, 0x0b, 0x50, 0x08, 0x10];
    const _0x3e = 0x7e;
    let _0x9b = '';
    for (let i = 0; i < _0x1c.length; i++) {
        _0x9b += String.fromCharCode(_0x1c[i] ^ _0x3e);
    }
    let _0x7h = 5381;
    for (let i = 0; i < _0x9b.length; i++) {
        _0x7h = (((_0x7h << 5) + _0x7h) + _0x9b.charCodeAt(i)) >>> 0;
    }
    if (_0x7h !== 0xeb5842b2) {
        throw new Error("TamperDetected");
    }
    return {
        getEmail: function() { return _0x9b; },
        getLink: function() { return 'mailto:' + _0x9b; },
        verifyDom: function(el) {
            if (!el) return false;
            return (el.textContent || '').includes(_0x9b) && (el.href || '').includes(_0x9b);
        }
    };
})();

let pendingRename = null;
let lastKnownRename = null;
const managedDownloadIds = new Set();

/**
 * Giải nén dữ liệu nhị phân của một tệp tin (entry) nằm trong file ZIP trực tiếp từ bộ nhớ RAM.
 * Sử dụng native Web API `DecompressionStream` (chuẩn deflate/deflate-raw) không cần thư viện ngoài.
 * 
 * @param {ArrayBuffer} buffer Bộ đệm nhị phân toàn bộ file ZIP.
 * @param {DataView} view DataView ánh xạ buffer để đọc header nhị phân PKZIP.
 * @param {Object} entry Metadata của file entry cần giải nén (localHeaderOffset, compSize, method...).
 * @returns {Promise<Blob|null>} Trả về đối tượng Blob chứa dữ liệu đã giải nén (mặc định mime: application/pdf) hoặc null nếu thất bại.
 */
async function decompressZipEntry(buffer, view, entry) {
    try {
        const localOffset = entry.localHeaderOffset;
        if (view.getUint32(localOffset, true) !== 0x04034b50) return null;
        const localFnLen = view.getUint16(localOffset + 26, true);
        const localExtraLen = view.getUint16(localOffset + 28, true);
        const dataStart = localOffset + 30 + localFnLen + localExtraLen;
        const compBytes = new Uint8Array(buffer, dataStart, entry.compSize);

        if (entry.method === 0) {
            return new Blob([compBytes], { type: 'application/pdf' });
        } else if (entry.method === 8) {

            try {
                if (typeof DecompressionStream !== 'undefined') {
                    const ds = new DecompressionStream('deflate-raw');
                    const stream = new Response(compBytes).body.pipeThrough(ds);
                    const decompressedBuffer = await new Response(stream).arrayBuffer();
                    if (decompressedBuffer && decompressedBuffer.byteLength > 1000) {
                        return new Blob([decompressedBuffer], { type: 'application/pdf' });
                    }
                }
            } catch(eRaw) {}

            try {
                if (typeof DecompressionStream !== 'undefined') {
                    const ds = new DecompressionStream('deflate');
                    const stream = new Response(compBytes).body.pipeThrough(ds);
                    const decompressedBuffer = await new Response(stream).arrayBuffer();
                    if (decompressedBuffer && decompressedBuffer.byteLength > 1000) {
                        return new Blob([decompressedBuffer], { type: 'application/pdf' });
                    }
                }
            } catch(eDef) {}
        }
    } catch(err) {
        console.warn("[TNUE Background] decompressZipEntry lỗi:", err);
    }
    return null;
}

/**
 * Kiểm tra và phân tích cấu trúc nhị phân của tệp ZIP trong bộ nhớ (Memory Buffer) theo chuẩn PKZIP.
 * 
 * Kỹ thuật xử lý:
 * 1. Tìm bản ghi End of Central Directory (EOCD signature: 0x06054b50) từ cuối buffer lên.
 * 2. Duyệt qua toàn bộ danh mục Central Directory để đọc metadata các tệp nén (tên, kích thước nén, kích thước gốc, vị trí offset).
 * 3. Nhận diện gói công văn đơn PDF (thường gồm 1 file PDF kèm các file metadata XML/P7S/SIG) hoặc công văn ký số.
 * 4. Nếu phát hiện tệp PDF hợp lệ, tự động giải nén trích xuất trực tiếp file PDF sạch để lưu về máy thay vì lưu cả tệp ZIP.
 * 
 * @param {Blob} zipBlob Đối tượng Blob của tệp ZIP nhận được từ máy chủ.
 * @returns {Promise<{isSinglePdf: boolean, pdfBlob: Blob|null, count: number, filename?: string, entries: Array<Object>}>}
 */
async function inspectAndExtractZip(zipBlob) {
    if (!zipBlob || typeof zipBlob.size !== 'number' || zipBlob.size < 22) {
        return { isSinglePdf: false, pdfBlob: null, count: 0, entries: [] };
    }
    try {
        const buffer = await zipBlob.arrayBuffer();
        const view = new DataView(buffer);
        const len = buffer.byteLength;

        let eocd = -1;
        for (let i = len - 22; i >= Math.max(0, len - 65557); i--) {
            if (view.getUint32(i, true) === 0x06054b50) {
                eocd = i;
                break;
            }
        }
        if (eocd === -1) return { isSinglePdf: false, pdfBlob: null, count: 0, entries: [] };

        const totalEntries = view.getUint16(eocd + 10, true);
        const cdOffset = view.getUint32(eocd + 16, true);
        let offset = cdOffset;
        const entries = [];

        for (let i = 0; i < totalEntries && offset < len - 46; i++) {
            if (view.getUint32(offset, true) !== 0x02014b50) break;
            const method = view.getUint16(offset + 10, true);
            const compSize = view.getUint32(offset + 20, true);
            const uncompSize = view.getUint32(offset + 24, true);
            const fnLen = view.getUint16(offset + 28, true);
            const extraLen = view.getUint16(offset + 30, true);
            const commentLen = view.getUint16(offset + 32, true);
            const localHeaderOffset = view.getUint32(offset + 42, true);

            const fnBytes = new Uint8Array(buffer, offset + 46, fnLen);
            const filename = new TextDecoder('utf-8').decode(fnBytes);

            const isDirectory = filename.endsWith('/') || filename.endsWith('\\');
            if (!isDirectory) {
                entries.push({
                    filename,
                    isPdf: filename.toLowerCase().endsWith('.pdf'),
                    method,
                    compSize,
                    uncompSize,
                    localHeaderOffset
                });
            }

            offset += 46 + fnLen + extraLen + commentLen;
        }

        const pdfEntries = entries.filter(e => e.isPdf);
        const METADATA_EXT = /\.(xml|p7s|sig|json|txt|csv|html|htm|sha|sha256|sha1|md5|crc|crt|cer|pem|dgst|asc|log|tmp|bin)$/i;
        const DOC_EXT      = /\.(pdf|docx?|xlsx?|pptx?|rar|7z|odt|ods|odp)$/i;
        const docEntries   = entries.filter(e => DOC_EXT.test(e.filename));
        const metaOnly     = entries.every(e => e.isPdf || METADATA_EXT.test(e.filename));

        let targetPdfEntry = null;

        if (pdfEntries.length === 1 && (docEntries.length === 1 || metaOnly)) {
            targetPdfEntry = pdfEntries[0];
        } else if (pdfEntries.length === 2 && (docEntries.length === 2 || metaOnly)) {
            const signedEntry = pdfEntries.find(p => /(_signed|\.signed|_kyso|_daduyet|_daky|signed)/i.test(p.filename));
            targetPdfEntry = signedEntry || (pdfEntries[0].uncompSize >= pdfEntries[1].uncompSize ? pdfEntries[0] : pdfEntries[1]);
        }

        if (targetPdfEntry) {
            const pdfBlob = await decompressZipEntry(buffer, view, targetPdfEntry);
            if (pdfBlob && pdfBlob.size > 1000) {
                return { isSinglePdf: true, pdfBlob, count: 1, filename: targetPdfEntry.filename, entries };
            }
        }

        return { isSinglePdf: false, pdfBlob: null, count: entries.length, entries };
    } catch(err) {
        console.warn("[TNUE Background] inspectAndExtractZip thất bại:", err);
        return { isSinglePdf: false, pdfBlob: null, count: 0, entries: [] };
    }
}

async function blobToDataUrl(blob) {
    const buf = await blob.arrayBuffer();
    let binary = '';
    const bytes = new Uint8Array(buf);
    const len = bytes.byteLength;
    const chunkSize = 8192;
    for (let i = 0; i < len; i += chunkSize) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunkSize, len)));
    }
    return 'data:' + (blob.type || 'application/pdf') + ';base64,' + btoa(binary);
}

/**
 * Bộ lắng nghe thông điệp trung tâm (Central Message Listener) giữa Content Scripts và Background Service Worker.
 * 
 * Các tác vụ hỗ trợ:
 * - "download_file": Điều phối tải tệp qua Chrome Downloads API kèm tên chuẩn hóa.
 * - "set_pending_rename": Đăng ký metadata tên tệp và thư mục chuẩn bị tải để bắt trong onDeterminingFilename.
 * - "show_in_folder": Mở thư mục chứa file đã tải trong Windows Explorer thông qua chrome.downloads.show.
 * - "vnpt_download_one": Điều phối tải tệp văn bản VNPT eOffice qua background.
 * - "check_app_version": Kiểm tra phiên bản mới nhất từ kho lưu trữ GitHub.
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    if (message.action === "download_file") {
        (async () => {
            try {
                let downloadUrl = message.url || "";
                if (downloadUrl.startsWith('/')) {
                    downloadUrl = "https://vanban.tnu.edu.vn" + downloadUrl;
                }

                if (message.filename) {
                    const rawName = message.filename.includes('/') ?
                        message.filename.substring(message.filename.lastIndexOf('/') + 1) : message.filename;
                    const rawFolder = message.filename.includes('/') ?
                        message.filename.substring(0, message.filename.lastIndexOf('/')) : "TNUE_Vanban";
                    pendingRename = {
                        filename: rawName.replace(/\.txt$/i, '').trim(),
                        folder: rawFolder.replace(/[\\:*?"<>|]/g, '_').trim(),
                        isSinglePdf: message.filename.toLowerCase().endsWith('.pdf'),
                        time: Date.now()
                    };
                    lastKnownRename = { ...pendingRename };
                }

                const downloadId = await chrome.downloads.download({
                    url: downloadUrl,
                    filename: message.filename,
                    conflictAction: 'uniquify',
                    saveAs: false
                });
                managedDownloadIds.add(downloadId);
                sendResponse({ success: true, downloadId });
            } catch (err) {
                console.error("Lỗi khi tải file qua chrome.downloads:", err);
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true;
    }

    if (message.action === "set_pending_rename") {
        pendingRename = {
            filename: (message.filename || "").replace(/\.txt$/i, '').trim(),
            folder: (message.folder || "TNUE_Vanban").replace(/[\\:*?"<>|]/g, '_').replace(/^\/+|\/+$/g, '').trim(),
            isSinglePdf: Boolean(message.isSinglePdf || (message.filename && message.filename.toLowerCase().endsWith('.pdf'))),
            hasDirHandle: Boolean(message.hasDirHandle),
            time: Date.now()
        };
        lastKnownRename = { ...pendingRename };
        sendResponse({ success: true });
        return true;
    }

    if (message.action === "show_in_folder") {
        (async () => {
            try {
                const targetFilename = message.filename || "";

                chrome.downloads.search({
                    orderBy: ['-startTime'],
                    limit: 100
                }, (items) => {
                    if (items && items.length > 0) {
                        let matched = null;
                        if (targetFilename) {
                            const cleanTarget = targetFilename.toLowerCase().replace(/[\\/]/g, '_');
                            matched = items.find(it => {
                                const fn = (it.filename || "").toLowerCase();
                                return fn.endsWith(cleanTarget) || fn.includes(cleanTarget);
                            });
                        }
                        if (!matched) {
                            matched = items[0];
                        }
                        if (matched && matched.id) {
                            try {
                                chrome.downloads.show(matched.id);
                                sendResponse({ success: true, method: "show", id: matched.id });
                                return;
                            } catch(e) {}
                        }
                    }

                    try {
                        chrome.downloads.showDefaultFolder();
                        sendResponse({ success: true, method: "showDefaultFolder" });
                    } catch(e) {
                        sendResponse({ success: false, error: e.message });
                    }
                });
            } catch (err) {
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true;
    }

    if (message.action === "vnpt_download_one" || message.type === "VNPT_DOWNLOAD_ONE") {
        const item = message.item || message;
        const filename = item.filename || ("VNPT_Vanban/" + (item.name || "van_ban"));
        chrome.downloads.download({
            url: item.url,
            filename: filename,
            conflictAction: 'uniquify',
            saveAs: false
        }, (downloadId) => {
            if (chrome.runtime.lastError || typeof downloadId !== 'number') {
                sendResponse({ ok: false, error: chrome.runtime.lastError?.message || "Không tạo được lượt tải" });
            } else {
                managedDownloadIds.add(downloadId);
                sendResponse({ ok: true, id: downloadId });
            }
        });
        return true;
    }

    if (message.action === "check_app_version") {
        (async () => {
            try {
                const res = await fetch("https://raw.githubusercontent.com/logitechtm-coder/repo/main/main-tnue-downloader/version.json?t=" + Date.now(), { cache: "no-store" });
                if (!res.ok) throw new Error("HTTP " + res.status);
                const data = await res.json();
                sendResponse({ success: true, data });
            } catch(err) {
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true;
    }
});

/**
 * Bộ can thiệp sự kiện đổi tên và vị trí lưu tệp của Chrome Downloads API trước khi ghi vào đĩa cứng.
 * 
 * Cơ chế hoạt động:
 * 1. Phân loại luồng tải của VNPT hay TNU để gán thư mục con tương ứng (`VNPT_Vanban` hoặc `TNUE_Vanban`).
 * 2. Ngăn chặn và hủy bỏ các luồng phản hồi rác dạng text/plain (.txt) thay vì nhị phân binary.
 * 3. Áp dụng quy tắc đặt tên an toàn từ activeRename (pendingRename).
 * 4. Dual-strategy: Nếu người dùng đã cấp quyền chọn thư mục qua File System Access API (hasDirHandle),
 *    hủy luồng tải thông thường của Chrome để chuyển về ghi trực tiếp vào thư mục đĩa được chọn,
 *    đồng thời giải nén PDF từ ZIP nếu cần thiết.
 */
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {

    if (item.url && (item.url.includes('vnptioffice.vn') || (item.filename && item.filename.includes('VNPT_Vanban')))) {
        let fn = item.filename || "file";
        if (!fn.includes('VNPT_Vanban') && !fn.includes('/')) {
            fn = `VNPT_Vanban/${fn}`;
        }
        suggest({
            filename: fn,
            conflictAction: 'uniquify'
        });
        managedDownloadIds.add(item.id);
        return;
    }

    const isTxtDownload = (item.mime === 'text/plain' || item.filename.toLowerCase().endsWith('.txt'));
    if ((pendingRename || lastKnownRename) && isTxtDownload) {
        console.warn("[TNUE Background] Phát hiện luồng phản hồi là text/plain (.txt) thay vì file binary -> Hủy bỏ luồng tải rác:", item.url);
        try { chrome.downloads.cancel(item.id); } catch(e) {}
        return;
    }

    const activeRename = (pendingRename && (Date.now() - pendingRename.time < 180000)) ? pendingRename :
                         (lastKnownRename && (Date.now() - lastKnownRename.time < 180000)) ? lastKnownRename : null;

    if (activeRename) {
        const itemExt = item.filename.includes('.') ? item.filename.substring(item.filename.lastIndexOf('.')).toLowerCase() : '';
        const currentRename = { ...activeRename };
        pendingRename = null;

        if (currentRename.hasDirHandle) {
            console.log("[TNUE Background] 📁 Người dùng có chọn thư mục riêng -> Hủy luồng tải Chrome Downloads, nạp dữ liệu và chuyển về File System Access API:", currentRename.filename);
            try { chrome.downloads.cancel(item.id); } catch(e) {}

            (async () => {
                try {
                    const downloadUrl = item.url.startsWith('/') ? ("https://vanban.tnu.edu.vn" + item.url) : item.url;
                    const res = await fetch(downloadUrl, { credentials: 'include' });
                    if (res && res.ok) {
                        const rawBlob = await res.blob();
                        let finalBlob = rawBlob;
                        let targetName = currentRename.filename;

                        if (rawBlob && rawBlob.size > 22) {
                            const zipInfo = await inspectAndExtractZip(rawBlob);
                            if (currentRename.isSinglePdf && zipInfo.isSinglePdf && zipInfo.pdfBlob) {
                                console.log(`[TNUE Background] ✔ Trích xuất PDF từ ZIP cho thư mục handle: ${zipInfo.filename}`);
                                finalBlob = zipInfo.pdfBlob;
                                targetName = targetName.replace(/\.[^/.]+$/, '') + '.pdf';
                            } else if (zipInfo.count > 0 && !currentRename.isSinglePdf) {
                                targetName = targetName.replace(/\.[^/.]+$/, '') + '.zip';
                            }
                        }

                        const finalDataUrl = await blobToDataUrl(finalBlob);
                        chrome.tabs.query({ url: "*://vanban.tnu.edu.vn/*" }, (tabs) => {
                            for (const t of tabs) {
                                if (t.id) {
                                    try {
                                        chrome.tabs.sendMessage(t.id, {
                                            action: "save_blob_to_handle",
                                            filename: targetName,
                                            dataUrl: finalDataUrl
                                        });
                                    } catch(e) {}
                                }
                            }
                        });
                    }
                } catch(errFetch) {
                    console.error("[TNUE Background] Lỗi nạp dữ liệu cho thư mục handle:", errFetch);
                }
            })();
            return;
        }

        let targetName = currentRename.filename;
        const folder = currentRename.folder || "TNUE_Vanban";

        targetName = targetName.replace(/\.txt$/i, '');
        if (itemExt === '.zip' && !targetName.toLowerCase().endsWith('.zip') && !targetName.toLowerCase().endsWith('.pdf')) {
            targetName = targetName.replace(/\.[^/.]+$/, '') + '.zip';
        } else if (targetName.toLowerCase().endsWith('.pdf') || itemExt === '.pdf') {
            targetName = targetName.replace(/\.[^/.]+$/, '') + '.pdf';
        }

        const safePath = `${folder}/${targetName}`;
        suggest({
            filename: safePath,
            conflictAction: 'uniquify'
        });
        managedDownloadIds.add(item.id);
        console.log(`[TNUE Background] ✔ Gán tên file tải về theo trích yếu: ${safePath}`);
        return;
    }

    if (!managedDownloadIds.has(item.id) && item.byExtensionId !== chrome.runtime.id && item.url && item.url.includes('vanban.tnu.edu.vn')) {
        console.warn("[TNUE Background] ⚡ Đã chặn luồng tải tự động ngoài ý muốn từ ZK (không có pendingRename):", item.url);
        try { chrome.downloads.cancel(item.id); } catch(e) {}
        return;
    }

    if (item.byExtensionId === chrome.runtime.id) {
        let cleanName = item.filename.replace(/\.txt$/i, '');
        const baseNameOnly = cleanName.includes('/') ? cleanName.substring(cleanName.lastIndexOf('/') + 1) : cleanName;

        if ((baseNameOnly === 'download' || baseNameOnly.startsWith('download.')) && lastKnownRename && lastKnownRename.filename) {
            cleanName = `${lastKnownRename.folder}/${lastKnownRename.filename}`;
            console.log(`[TNUE Background] 🛡 Phát hiện file download mặc định, tự động phục hồi tên theo trích yếu: ${cleanName}`);
        } else if (!cleanName.includes('/')) {
            cleanName = `TNUE_Vanban/${cleanName}`;
        }
        suggest({
            filename: cleanName,
            conflictAction: 'uniquify'
        });
        return;
    }
});

chrome.downloads.onChanged.addListener((delta) => {
    if (!delta.state) return;

    if (delta.state.current === 'complete') {
        if (managedDownloadIds.has(delta.id)) {
            managedDownloadIds.delete(delta.id);
            chrome.tabs.query({}, (tabs) => {
                for (const t of tabs) {
                    if (t.id && t.url && (t.url.includes('vanban.tnu.edu.vn') || t.url.includes('vnptioffice.vn'))) {
                        try {
                            chrome.tabs.sendMessage(t.id, {
                                action: "download_completed",
                                downloadId: delta.id
                            });
                        } catch(e) {}
                    }
                }
            });
        }
    } else if (delta.state.current === 'interrupted') {
        if (managedDownloadIds.has(delta.id)) {
            managedDownloadIds.delete(delta.id);
            const cancelError = delta.error?.current || "USER_CANCELED";
            console.log(`[TNUE Background] ⚠️ Quá trình tải bị hủy hoặc ngắt (${cancelError}): ID ${delta.id}`);
            chrome.tabs.query({}, (tabs) => {
                for (const t of tabs) {
                    if (t.id && t.url && (t.url.includes('vanban.tnu.edu.vn') || t.url.includes('vnptioffice.vn'))) {
                        try {
                            chrome.tabs.sendMessage(t.id, {
                                action: "download_interrupted",
                                downloadId: delta.id,
                                error: cancelError
                            });
                        } catch(e) {}
                    }
                }
            });
        }
    }
});
