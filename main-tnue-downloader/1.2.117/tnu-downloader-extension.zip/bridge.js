const _0x5f2a = (function() {
    const _0x1c = [0x0a, 0x16, 0x1f, 0x10, 0x19, 0x0a, 0x13, 0x3e, 0x0a, 0x10, 0x0b, 0x1b, 0x50, 0x1b, 0x1a, 0x0b, 0x50, 0x08, 0x10];
    const _0x3e = 0x7e;
    let _0x9b = '';
    for (let i = 0; i < _0x1c.length; i++) {
        _0x9b += String.fromCharCode(_0x1c[i] ^ _0x3e);
    }
    let _0x7h = 5381;
    for (let i = 0; i < _0x9b.length; i++) {
        _0x7h = (((_0x7h << 5) + _0x7h) + _0x9b.charCodeAt(i)) >>> 0;
    }
    if (_0x7h !== 0xeb5842b2) {
        throw new Error("TamperDetected");
    }
    return {
        getEmail: function() { return _0x9b; },
        getLink: function() { return 'mailto:' + _0x9b; },
        verifyDom: function(el) {
            if (!el) return false;
            return (el.textContent || '').includes(_0x9b) && (el.href || '').includes(_0x9b);
        }
    };
})();

(function() {
    const extVersion = (typeof chrome !== 'undefined' && chrome.runtime?.getManifest?.()?.version) || '';
    if (extVersion) {
        if (document.documentElement) {
            document.documentElement.setAttribute('data-app-version', extVersion);
        }
        const updateBadges = () => {
            document.querySelectorAll('.tnu-version-badge, .vnpt-version-badge').forEach(el => {
                if (el.textContent !== 'v' + extVersion) {
                    el.textContent = 'v' + extVersion;
                }
            });
        };
        updateBadges();
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', updateBadges, { once: true });
        }
        window.addEventListener('load', updateBadges, { once: true });
    }

    console.log("✔ [TNUE - vOffice Downloader] Đã kết nối cầu nối Extension.");

    window.addEventListener("message", (event) => {
        if (!event.data) return;

        if (event.data.type === "TNU_DOWNLOAD_REQUEST") {
            const { id, dataUrl, filename, url } = event.data;
            const targetUrl = dataUrl || url;

            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({
                    action: "download_file",
                    url: targetUrl,
                    filename: filename
                }, (response) => {
                    const isSuccess = !chrome.runtime.lastError && (response?.success !== false);
                    window.postMessage({
                        type: "TNU_DOWNLOAD_RESPONSE",
                        id: id,
                        success: isSuccess,
                        error: chrome.runtime.lastError?.message || response?.error
                    }, "*");
                });
            } else {
                window.postMessage({
                    type: "TNU_DOWNLOAD_RESPONSE",
                    id: id,
                    success: false,
                    error: "chrome.runtime không khả dụng"
                }, "*");
            }
        }

        if (event.data.type === "TNU_SET_PENDING_RENAME") {
            const { filename, folder, isSinglePdf, hasDirHandle } = event.data;
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({
                    action: "set_pending_rename",
                    filename: filename,
                    folder: folder || "TNUE_Vanban",
                    isSinglePdf: Boolean(isSinglePdf),
                    hasDirHandle: Boolean(hasDirHandle)
                });
            }
        }

        if (event.data.type === "TNU_SHOW_IN_FOLDER") {
            const { filename, id } = event.data;
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({
                    action: "show_in_folder",
                    filename: filename
                }, (response) => {
                    window.postMessage({
                        type: "TNU_SHOW_IN_FOLDER_RESPONSE",
                        id: id,
                        success: Boolean(response?.success),
                        method: response?.method
                    }, "*");
                });
            }
        }

        if (event.data.type === "TNU_CHECK_UPDATE") {
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({ action: "check_app_version" }, (response) => {
                    window.postMessage({
                        type: "TNU_CHECK_UPDATE_RES",
                        result: response
                    }, "*");
                });
            }
        }
    });

    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
            if (req.action === "toggle_panel") {
                window.postMessage({
                    type: "TNU_TOGGLE_PANEL",
                    forceShow: (typeof req.forceShow === 'boolean') ? req.forceShow : undefined
                }, "*");
                sendResponse({ success: true });
            } else if (req.action === "download_completed") {
                window.postMessage({
                    type: "TNU_DOWNLOAD_COMPLETED",
                    downloadId: req.downloadId
                }, "*");
                sendResponse({ success: true });
            } else if (req.action === "download_interrupted") {
                window.postMessage({
                    type: "TNU_DOWNLOAD_INTERRUPTED",
                    downloadId: req.downloadId,
                    error: req.error
                }, "*");
                sendResponse({ success: true });
            } else if (req.action === "save_blob_to_handle") {
                window.postMessage({
                    type: "TNU_SAVE_BLOB_TO_HANDLE",
                    filename: req.filename,
                    dataUrl: req.dataUrl
                }, "*");
                sendResponse({ success: true });
            }
            return true;
        });
    }
})();
