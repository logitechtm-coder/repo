(function() {
    if (window.__VNPT_CONTENT_LOADED__) return;
    window.__VNPT_CONTENT_LOADED__ = true;
    console.log("✔ [VNPT eOffice Downloader] Đã khởi tạo công cụ tải văn bản VNPT.");

    const oldP = document.getElementById('vnpt-download-panel');
    if (oldP) oldP.remove();
    const oldM = document.getElementById('vnpt-log-modal');
    if (oldM) oldM.remove();

    window.__vnpt_downloader = {
        isRunning: false,
        isPaused: false,
        stopRequested: false
    };

    window.__vnpt_dir_handle = null;
    window.__vnpt_logs = [];
    const STORAGE_KEY = "vnpt_download_logs";

    function isSameVnptDoc(docA, docB) {
        if (!docA || !docB) return false;
        if (docA.docId && docB.docId && String(docA.docId).trim() === String(docB.docId).trim()) {
            return true;
        }
        if (docA.tenFile && docB.tenFile && docA.tenFile !== '-' && docB.tenFile !== '-') {
            const fA = String(docA.tenFile).trim().toLowerCase();
            const fB = String(docB.tenFile).trim().toLowerCase();
            if (fA === fB) return true;
        }
        const skhA = String(docA.soKyHieu || '').trim().toLowerCase();
        const skhB = String(docB.soKyHieu || '').trim().toLowerCase();
        const ngayA = String(docA.ngayVanBan || docA.ngay || '').trim();
        const ngayB = String(docB.ngayVanBan || docB.ngay || '').trim();
        if (skhA && skhB && skhA === skhB) {
            if (ngayA && ngayB && ngayA === ngayB) return true;
            if (skhA.includes('/') || skhA.includes('-')) return true;
        }
        return false;
    }

    function findExistingLogIndex(logs, item) {
        if (!logs || !Array.isArray(logs) || !logs.length || !item) return -1;
        return logs.findIndex(l => isSameVnptDoc(l, item));
    }

    function cleanDuplicateLogs(logs) {
        if (!logs || !Array.isArray(logs) || logs.length <= 1) return logs || [];
        const unique = [];
        for (const item of logs) {
            const idx = unique.findIndex(u => isSameVnptDoc(u, item));
            if (idx === -1) {
                unique.push({ ...item });
            } else {
                const existing = unique[idx];
                if (item.trangThai === 'THÀNH CÔNG') {
                    existing.trangThai = 'THÀNH CÔNG';
                    existing.lyDoLoi = '';
                    if (item.tenFile && item.tenFile !== '-') existing.tenFile = item.tenFile;
                    if (item.loaiFile && item.loaiFile !== 'ĐÃ TẢI' && item.loaiFile !== 'NONE') existing.loaiFile = item.loaiFile;
                    if (parseFloat(item.dungLuongMb) > 0) existing.dungLuongMb = item.dungLuongMb;
                } else if (existing.trangThai !== 'THÀNH CÔNG' && item.trangThai === 'LỖI') {
                    existing.trangThai = 'LỖI';
                    existing.lyDoLoi = item.lyDoLoi || existing.lyDoLoi;
                }
                if (item.thoiGian) existing.thoiGian = item.thoiGian;
                if (item.trichYeu && item.trichYeu.length > (existing.trichYeu || '').length) {
                    existing.trichYeu = item.trichYeu;
                }
            }
        }
        return unique;
    }

    try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) window.__vnpt_logs = cleanDuplicateLogs(JSON.parse(saved));
    } catch(e) {}

    const MAX_RELATIVE_PATH = 190;
    const MAX_ROOT = 40;
    const MAX_FILE = 140;

    const RESERVED_NAMES = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;

    function truncate(text, maxLength) {
        const value = String(text == null ? '' : text);
        const limit = Math.floor(Number(maxLength) || 0);
        if (limit <= 0) return '';
        if (value.length <= limit) return value;
        let cut = value.slice(0, limit);
        if (/[\uD800-\uDBFF]$/.test(cut)) cut = cut.slice(0, -1);
        return cut.replace(/[\s._-]+$/g, '');
    }

    function sanitizeSegment(value, maxLength) {
        if (value == null) return '';

        let text = String(value)
            .normalize('NFC')
            .replace(/[\u0000-\u001f\u007f]/g, ' ')
            .replace(/[\\/]/g, '-')
            .replace(/[<>:"|?*]/g, '-')
            .replace(/[^\p{L}\p{N} ._()\-]/gu, ' ')
            .replace(/\s*-\s*/g, '-')
            .replace(/\s+/g, ' ')
            .replace(/-{2,}/g, '-')
            .replace(/_{2,}/g, '_')
            .replace(/^[\s._-]+/, '')
            .replace(/[\s._-]+$/, '');

        if (!text) return '';

        const limit = Math.floor(Number(maxLength) || 0);
        if (limit > 0) text = truncate(text, limit).replace(/[\s._-]+$/, '');

        if (!text) return '';
        if (RESERVED_NAMES.test(text)) text = '_' + text;
        return text;
    }

    function truncateFileName(name, maxLength) {
        const limit = Math.floor(Number(maxLength) || 0);
        if (limit <= 0) return '';
        if (name.length <= limit) return name;

        const dot = name.lastIndexOf('.');
        if (dot > 0 && name.length - dot <= 12) {
            const extension = name.slice(dot);
            const base = truncate(name.slice(0, dot), Math.max(1, limit - extension.length));
            return (base || 'file') + extension;
        }
        return truncate(name, limit);
    }

    function sanitizeFileName(name, maxLength) {
        const cleaned = sanitizeSegment(name, 400);
        if (!cleaned) return 'file';
        return truncateFileName(cleaned, Math.floor(Number(maxLength) || MAX_FILE));
    }

    function splitExtension(name) {
        const value = String(name == null ? '' : name).trim();
        const dot = value.lastIndexOf('.');
        if (dot <= 0 || value.length - dot > 12) return '';
        const extension = value.slice(dot);
        return /^\.[\p{L}\p{N}]{1,10}$/u.test(extension) ? extension : '';
    }

    function buildDocName(doc) {
        const source = doc || {};
        const parts = [];

        const code = sanitizeSegment(source.soKyHieu, 80);
        if (code) parts.push(code);

        const date = sanitizeSegment(source.ngay, 20);
        if (date) parts.push(date);

        const summary = sanitizeSegment(source.trichYeu, 400);
        if (summary) parts.push(summary);

        if (!parts.length) {
            const fallback = sanitizeSegment(source.docId, 40);
            parts.push(fallback || 'VanBan');
        }

        return parts
            .join('_')
            .replace(/_{2,}/g, '_')
            .replace(/^_+|_+$/g, '');
    }

    function buildDocFileName(doc, attachment, options) {
        const source = attachment || {};
        const opts = options || {};
        const extension = splitExtension(source.name) || '.pdf';

        const index = Math.floor(Number(opts.index) || 0);
        const suffix = index > 1 ? `_${index}` : '';
        const maxLength = Math.max(20, Math.floor(Number(opts.maxLength) || MAX_FILE));
        const tail = `${suffix}${extension}`;
        const baseLimit = Math.max(1, maxLength - tail.length);

        let base = truncate(buildDocName(doc) || 'VanBan', baseLimit);
        if (!base) base = 'VanBan';

        return `${base}${tail}`;
    }

    function buildDownloadPath(rootFolder, doc, attachment, options) {
        const root = sanitizeSegment(rootFolder, MAX_ROOT) || 'VNPT_Vanban';
        const budget = MAX_RELATIVE_PATH - root.length - 1;
        const limit = Math.max(20, Math.min(MAX_FILE, budget));
        const fileName = buildDocFileName(doc, attachment, { ...(options || {}), maxLength: limit });
        return `${root}/${fileName}`;
    }

    const Naming = {
        MAX_RELATIVE_PATH,
        MAX_ROOT,
        MAX_FILE,
        sanitizeSegment,
        sanitizeFileName,
        truncateFileName,
        splitExtension,
        buildDocName,
        buildDocFileName,
        buildDownloadPath,
    };
    window.VnptNaming = Naming;

    function saveLogsToStorage() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(window.__vnpt_logs.slice(-3000)));
        } catch(e) {}
    }

    async function syncLogsFromDiskDirectory(dirHandle) {
        if (!dirHandle) return;
        try {
            let fileHandle = null;
            try {
                fileHandle = await dirHandle.getFileHandle("log_download_vnpt.json");
            } catch(e) {
                try {
                    fileHandle = await dirHandle.getFileHandle("log_download.json");
                } catch(e2) {}
            }
            if (fileHandle) {
                const file = await fileHandle.getFile();
                const text = await file.text();
                if (text && text.trim()) {
                    const parsed = JSON.parse(text);
                    if (Array.isArray(parsed)) {
                        const isVnptLog = parsed.some(p => p.docId !== undefined || (p.tenFile && p.tenFile.includes('_')));
                        if (isVnptLog || parsed.length === 0) {
                            window.__vnpt_logs = cleanDuplicateLogs(parsed);
                            saveLogsToStorage();
                            updateCounts();
                            renderLogTable();
                            console.log(`[VNPT] Đã nạp ${window.__vnpt_logs.length} bản ghi nhật ký từ thư mục.`);
                        }
                    }
                }
            }
        } catch(e) {
            console.warn("[VNPT] Lỗi nạp nhật ký từ đĩa:", e);
        }
    }

    async function syncLogsToDirectory(dirHandle) {
        if (!dirHandle) return;
        try {
            const fileHandle = await dirHandle.getFileHandle("log_download_vnpt.json", { create: true });
            const writable = await fileHandle.createWritable();
            await writable.write(JSON.stringify(window.__vnpt_logs, null, 2));
            await writable.close();
        } catch(e) {
            console.warn("[VNPT] Lỗi ghi log_download.json vào thư mục:", e);
        }
    }

    async function recordDocLog(item) {
        const timeStr = item.thoiGian || new Date().toLocaleString('vi-VN');
        const existingIdx = findExistingLogIndex(window.__vnpt_logs, item);

        if (existingIdx >= 0) {
            const old = window.__vnpt_logs[existingIdx];

            let nextStatus = item.trangThai || old.trangThai;
            let nextLyDo = item.lyDoLoi !== undefined ? item.lyDoLoi : (old.lyDoLoi || "");
            if (old.trangThai === 'THÀNH CÔNG' && nextStatus === 'BỎ QUA') {
                nextStatus = 'THÀNH CÔNG';
                nextLyDo = "";
            } else if (nextStatus === 'THÀNH CÔNG') {
                nextLyDo = "";
            }

            old.docId = item.docId || old.docId;
            old.soKyHieu = item.soKyHieu || old.soKyHieu;
            if (item.trichYeu && item.trichYeu.length > (old.trichYeu || '').length) {
                old.trichYeu = item.trichYeu;
            }
            old.ngayVanBan = item.ngayVanBan || old.ngayVanBan;
            old.nam = item.nam || old.nam;
            old.thang = item.thang || old.thang;
            if (item.loaiFile && item.loaiFile !== 'ĐÃ TẢI' && item.loaiFile !== 'NONE') {
                old.loaiFile = item.loaiFile;
            }
            if (item.tenFile && item.tenFile !== '-') {
                old.tenFile = item.tenFile;
            }
            if (parseFloat(item.dungLuongMb) > 0) {
                old.dungLuongMb = item.dungLuongMb;
            }
            old.trangThai = nextStatus;
            old.lyDoLoi = nextLyDo;
            old.thoiGian = timeStr;

            saveLogsToStorage();
            if (window.__vnpt_dir_handle) {
                await syncLogsToDirectory(window.__vnpt_dir_handle);
            }
            updateCounts();
            return old;
        }

        const logItem = {
            id: window.__vnpt_logs.length + 1,
            stt: item.stt || (window.__vnpt_logs.length + 1),
            docId: item.docId || "",
            soKyHieu: item.soKyHieu || "",
            trichYeu: item.trichYeu || "",
            ngayVanBan: item.ngayVanBan || "",
            nam: item.nam || "",
            thang: item.thang || "",
            loaiFile: item.loaiFile || "PDF",
            tenFile: item.tenFile || "",
            dungLuongMb: item.dungLuongMb || 0,
            trangThai: item.trangThai || "THÀNH CÔNG",
            lyDoLoi: item.lyDoLoi || "",
            thoiGian: timeStr
        };

        window.__vnpt_logs.push(logItem);
        saveLogsToStorage();
        if (window.__vnpt_dir_handle) {
            await syncLogsToDirectory(window.__vnpt_dir_handle);
        }
        updateCounts();
        return logItem;
    }

    function isDocAlreadySuccess(docId, soKyHieu, ngay) {
        if (!window.__vnpt_logs || window.__vnpt_logs.length === 0) return false;
        return window.__vnpt_logs.some(l =>
            l.trangThai === "THÀNH CÔNG" &&
            ((docId && l.docId === docId) || (soKyHieu && l.soKyHieu === soKyHieu && l.ngayVanBan === ngay))
        );
    }

    function dwrRSet(expression, timeoutMs = 6000) {
        return new Promise((resolve, reject) => {
            if (!window.NEORemoting || typeof window.NEORemoting.getRSet !== 'function') {
                reject(new Error("Không tìm thấy hàm NEORemoting.getRSet trên trang VNPT."));
                return;
            }

            try {
                if (window.dwr && window.dwr.engine && typeof window.dwr.engine._batchDepth === 'number') {
                    while (window.dwr.engine._batchDepth > 0) {
                        window.dwr.engine.endBatch();
                    }
                }
            } catch(e) {}

            let done = false;
            const timer = setTimeout(() => {
                if (!done) { done = true; reject(new Error("DWR timeout (getRSet)")); }
            }, timeoutMs);

            try {
                window.NEORemoting.getRSet(expression, {
                    callback: (data) => {
                        if (done) return;
                        done = true;
                        clearTimeout(timer);
                        resolve(data == null ? '' : String(data));
                    },
                    errorHandler: (errorString, exception) => {
                        if (done) return;
                        done = true;
                        clearTimeout(timer);
                        reject(new Error(errorString || (exception && exception.message) || "Lỗi DWR getRSet"));
                    },
                    timeout: Math.max(1000, timeoutMs - 500)
                });
            } catch(e) {
                try {
                    window.NEORemoting.getRSet(expression, (data) => {
                        if (done) return;
                        done = true;
                        clearTimeout(timer);
                        resolve(data == null ? '' : String(data));
                    });
                } catch(e2) {
                    if (!done) { done = true; clearTimeout(timer); reject(e2); }
                }
            }
        });
    }

    function dwrGetDoc(expression, timeoutMs = 15000) {
        return new Promise((resolve, reject) => {
            if (!window.DataRemoting || typeof window.DataRemoting.getDoc !== 'function') {
                reject(new Error("Không tìm thấy hàm DataRemoting.getDoc trên trang VNPT."));
                return;
            }

            try {
                if (window.dwr && window.dwr.engine && typeof window.dwr.engine._batchDepth === 'number') {
                    while (window.dwr.engine._batchDepth > 0) {
                        window.dwr.engine.endBatch();
                    }
                }
            } catch(e) {}

            let done = false;
            const timer = setTimeout(() => {
                if (!done) { done = true; reject(new Error("DWR timeout (getDoc)")); }
            }, timeoutMs);

            try {
                window.DataRemoting.getDoc(expression, {
                    callback: (data) => {
                        if (done) return;
                        done = true;
                        clearTimeout(timer);
                        resolve(data == null ? '' : String(data));
                    },
                    errorHandler: (errorString, exception) => {
                        if (done) return;
                        done = true;
                        clearTimeout(timer);
                        reject(new Error(errorString || (exception && exception.message) || "Lỗi DWR getDoc"));
                    },
                    timeout: Math.max(1000, timeoutMs - 500)
                });
            } catch(e) {
                try {
                    window.DataRemoting.getDoc(expression, (data) => {
                        if (done) return;
                        done = true;
                        clearTimeout(timer);
                        resolve(data == null ? '' : String(data));
                    });
                } catch(e2) {
                    if (!done) { done = true; clearTimeout(timer); reject(e2); }
                }
            }
        });
    }

    function captureListTemplate(pageSize) {
        const p = window.page;
        if (!p || typeof p.data_func !== 'string' || !window.DataRemoting) return null;

        const origGetDoc = window.DataRemoting.getDoc;
        let captured = null;
        const oldRec = p.page_rec;
        const oldCurr = p.curr_page;
        const oldUrlData = p.url_data;

        window.DataRemoting.getDoc = function(url) {
            captured = url;
        };

        try {
            p.page_rec = pageSize;
            p.curr_page = 1;
            (0, eval)(p.data_func);
        } catch(err) {
            captured = null;
        } finally {
            window.DataRemoting.getDoc = origGetDoc;
            p.page_rec = oldRec;
            p.curr_page = oldCurr;
            p.url_data = oldUrlData;
            try {
                if (window.jQuery) window.jQuery('#btnSearchVB_dsvb').button('reset');
            } catch(e) {}
            try {
                if (window.dwr && window.dwr.engine && typeof window.dwr.engine._batchDepth === 'number') {
                    while (window.dwr.engine._batchDepth > 0) {
                        window.dwr.engine.endBatch();
                    }
                }
            } catch(e) {}
        }

        return typeof captured === 'string' ? captured : null;
    }

    function buildPageExpression(template, pageNumber, pageSize) {
        const jsonIndex = template.indexOf("'");
        let index = 0;
        return template.replace(/"(\d+)"/g, (match, digits, offset) => {
            if (jsonIndex >= 0 && offset > jsonIndex) return match;
            index += 1;
            if (index === 1) return `"${pageNumber}"`;
            if (index === 2) return `"${pageSize}"`;
            return match;
        });
    }

    function extractAttachmentsFromRow(row) {
        if (!row) return [];
        const list = [];
        
        const dlLinks = Array.from(row.querySelectorAll('a[href*="download.jsp"], [data-url*="download.jsp"]'));
        for (const a of dlLinks) {
            const href = a.getAttribute('href') || a.getAttribute('data-url') || '';
            const name = a.innerText.trim() || a.getAttribute('title') || a.getAttribute('filename') || 'attachment.pdf';
            if (href) {
                list.push({
                    name: name,
                    path: href,
                    url: href.startsWith('http') ? href : (location.origin + (href.startsWith('/') ? '' : '/') + href),
                    isPhieuTrinh: /phiếu trình|phieutrinh/i.test(name),
                    size: 0
                });
            }
        }
        if (list.length > 0) return list;

        const clickables = Array.from(row.querySelectorAll('[onclick*="download"], [onclick*="Download"], [onclick*="viewFile"], [onclick*="fileAttach"]'));
        for (const el of clickables) {
            const onclick = el.getAttribute('onclick') || '';
            const m = onclick.match(/(?:downloadFile|viewFile|downFile)\s*\(\s*['"]([^'"]+)['"]\s*,\s*['"]([^'"]+)['"]/i);
            if (m) {
                const name = m[1];
                const path = m[2];
                list.push({
                    name: name,
                    path: path,
                    isPhieuTrinh: /phiếu trình|phieutrinh/i.test(name),
                    size: 0
                });
            }
        }

        return list;
    }

    function parseRows(root) {
        let rows = Array.from(root.querySelectorAll('tr[id^="vb_"]'));
        if (!rows.length) {
            rows = Array.from(root.querySelectorAll('tr[flyid], tr[docid], tr[doc_id], tr[data-docid]'));
        }

        const result = [];
        const seen = new Set();

        const pick = (row, names) => {
            for (const n of names) {
                const v = row.getAttribute(n);
                if (v) return v.trim();
            }
            return '';
        };

        for (const row of rows) {
            let docId = '';
            if (/^vb_\d+$/.test(row.id)) docId = row.id.slice(3);
            else {
                const attr = pick(row, ['flyid', 'docid', 'doc_id', 'data-docid']);
                if (/^\d+$/.test(attr)) docId = attr;
                else {
                    const onclick = row.getAttribute('onclick') || '';
                    const m = onclick.match(/showDocDetail\((\d+)/) || onclick.match(/docid['"\s:=]+(\d+)/i);
                    if (m) docId = m[1];
                }
            }

            if (!docId || seen.has(docId)) continue;
            seen.add(docId);

            const soKyHieu = pick(row, ['so_ky_hieu', 'so_ky_hieu_di']);
            const trichYeu = pick(row, ['trich_yeu']);
            const ngay = pick(row, ['ngay_van_ban', 'ngay_den']);
            const donVi = pick(row, ['don_vi_ban_hanh']);

            const directAtts = extractAttachmentsFromRow(row);

            result.push({
                docId,
                soKyHieu,
                trichYeu,
                ngay,
                donVi,
                rawRow: row,
                embeddedAttachments: directAtts
            });
        }
        return result;
    }

    async function getAttachments(doc) {
        const docId = typeof doc === 'object' ? doc.docId : doc;
        const row = typeof doc === 'object' ? doc.rawRow : null;

        if (typeof doc === 'object' && doc.embeddedAttachments && doc.embeddedAttachments.length > 0) {
            return doc.embeddedAttachments;
        }
        if (row) {
            const domAtts = extractAttachmentsFromRow(row);
            if (domAtts.length > 0) return domAtts;
        }

        if (!/^\d+$/.test(String(docId))) return [];

        const expressions = [
            `qlvb.van_ban_den.getFileAttachLst(${docId},0)`,
            `qlvb.van_ban_den.getFileAttachLst('${docId}',0)`,
            `qlvb.van_ban_di.getFileAttachLst(${docId},0)`,
            `qlvb.van_ban_den.getFileAttachLst("${docId}",0)`
        ];

        let raw = null;
        for (const expr of expressions) {
            try {
                raw = await dwrRSet(expr, 4000);
                if (raw && raw !== 'null' && raw !== '[]' && raw !== '""') {
                    break;
                }
            } catch(e) {
            }
        }

        if (!raw || raw === 'null' || raw === '[]' || raw === '""') return [];

        let list;
        try {
            list = JSON.parse(raw);
        } catch(e) {
            return [];
        }
        if (!Array.isArray(list)) return [];

        return list.map(item => ({
            name: String(item.name || item.file_name || ''),
            path: String(item.hdd_file || item.path || item.file_path || ''),
            size: Number(item.file_size || item.size) || 0,
            fileId: String(item.file_id || ''),
            isPhieuTrinh: String(item.is_phieu_trinh) === '1' || /phiếu trình|phieutrinh/i.test(String(item.name || '')),
            type: String(item.type || '0')
        })).filter(item => item.name && (item.path || item.url));
    }

    function base64EncodeSafe(str) {
        if (window.Base64_Coder && typeof window.Base64_Coder.encode === 'function') {
            return window.Base64_Coder.encode(String(str));
        }
        try {
            return btoa(unescape(encodeURIComponent(String(str))));
        } catch(e) {
            return btoa(String(str));
        }
    }

    function buildDownloadUrl(attachment) {
        if (attachment.url) return attachment.url;
        const encode = (v) => encodeURIComponent(base64EncodeSafe(String(v)));
        return (
            location.origin +
            '/qlvbdh/smartoffice/jbm/download.jsp?5E1XCBS.=' + encode(attachment.name) +
            '&5FpXTEW.=' + encode(attachment.path) +
            '&TFbm5O..=' + encode('vb')
        );
    }

    const appVersion = document.documentElement?.getAttribute('data-app-version') || (typeof chrome !== 'undefined' && chrome.runtime?.getManifest?.()?.version) || '1.2.117';

    const panel = document.createElement('div');
    panel.id = 'vnpt-download-panel';
    panel.style.cssText = `
        position: fixed; bottom: 15px; right: 15px; z-index: 2147483647;
        width: 380px; background: #ffffff; border-radius: 8px;
        box-shadow: 0 10px 25px -5px rgba(0,0,0,0.25), 0 8px 10px -6px rgba(0,0,0,0.2);
        border: 1px solid #cbd5e1; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 13px; color: #1e293b; overflow: hidden;
    `;

    panel.innerHTML = `
        <div style="background: linear-gradient(180deg, #f0f9ff 0%, #e0f2fe 100%); color: #0369a1; padding: 9px 13px; font-weight: 600; font-size: 13px; display: flex; justify-content: space-between; align-items: center; user-select: none; border-bottom: 1px solid #bae6fd;">
            <div style="display: flex; align-items: center; gap: 6px;">
                <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #0284c7; box-shadow: 0 0 0 2px #bae6fd;"></span>
                <span style="font-weight: 700; color: #0369a1; letter-spacing: -0.2px;">VNPT eOffice Downloader</span>
                <span class="vnpt-version-badge" style="font-size: 11px; font-weight: 600; background: #ffffff; color: #0284c7; border: 1px solid #7dd3fc; padding: 1px 6px; border-radius: 4px; box-shadow: 0 1px 2px rgba(2, 132, 199, 0.08);">v${appVersion}</span>
            </div>
            <div style="display: flex; align-items: center; gap: 3px;">
                <span id="vnpt-btn-guide-header" style="cursor: pointer; font-size: 13px; padding: 2px 5px; border-radius: 4px; color: #0284c7; transition: all 0.15s;" title="Xem hướng dẫn sử dụng">❓</span>
                <span id="vnpt-btn-minimize" style="cursor: pointer; font-size: 13px; padding: 2px 5px; border-radius: 4px; color: #64748b; transition: all 0.15s;" title="Thu nhỏ / Mở rộng">➕</span>
                <span id="vnpt-btn-close-panel" style="cursor: pointer; font-size: 13px; padding: 2px 5px; border-radius: 4px; color: #ef4444; transition: all 0.15s;" title="Ẩn hoàn toàn">❌</span>
            </div>
        </div>
        <div id="vnpt-panel-body" style="padding: 10px 12px; display: none;">
            <div id="vnpt-tab-info-card" style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 9px; margin-bottom: 8px; font-size: 12px; color: #334155; line-height: 1.45; word-break: break-word; transition: all 0.2s;">
                <strong style="color: #0f172a;">Mở:</strong> VNPT eOffice (Văn bản đến / Văn bản đến chờ xử lý)
            </div>

            <button id="vnpt-btn-select-dir" style="width: 100%; padding: 7px 10px; background: #f8fafc; border: 1px dashed #64748b; border-radius: 5px; cursor: pointer; text-align: left; display: flex; align-items: center; gap: 6px; font-size: 12px; margin-bottom: 8px; transition: background 0.15s;">
                <span style="font-size: 15px;">📂</span>
                <div style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                    <div style="font-weight: 600; color: #334155;">Chọn thư mục lưu trên máy tính</div>
                    <div id="vnpt-dir-name" style="color: #64748b; font-size: 11px;">Mặc định: Downloads/VNPT_Vanban/</div>
                </div>
            </button>

            <div style="margin-bottom: 8px; display: grid; grid-template-columns: 1fr 1fr; gap: 6px;">
                <div style="background: #f8fafc; padding: 5px 8px; border-radius: 5px; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between;">
                    <span style="font-size: 12px; font-weight: 600; color: #475569;">📅 Năm:</span>
                    <select id="vnpt-year-select" style="padding: 3px 6px; border-radius: 3px; border: 1px solid #cbd5e1; font-size: 12px; font-weight: 600; background: #ffffff; color: #0f172a; outline: none;">
                        <option value="ALL">Tất cả</option>
                        <option value="2025" selected>2025</option>
                        <option value="2024">2024</option>
                        <option value="2023">2023</option>
                    </select>
                </div>
                <div style="background: #f8fafc; padding: 5px 8px; border-radius: 5px; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between;">
                    <span style="font-size: 12px; font-weight: 600; color: #475569;">🗓 Tháng:</span>
                    <select id="vnpt-month-select" style="padding: 3px 6px; border-radius: 3px; border: 1px solid #cbd5e1; font-size: 12px; font-weight: 600; background: #ffffff; color: #0f172a; outline: none;">
                        <option value="ALL" selected>Tất cả</option>
                        <option value="1">Tháng 1</option><option value="2">Tháng 2</option>
                        <option value="3">Tháng 3</option><option value="4">Tháng 4</option>
                        <option value="5">Tháng 5</option><option value="6">Tháng 6</option>
                        <option value="7">Tháng 7</option><option value="8">Tháng 8</option>
                        <option value="9">Tháng 9</option><option value="10">Tháng 10</option>
                        <option value="11">Tháng 11</option><option value="12">Tháng 12</option>
                    </select>
                </div>
            </div>

            <div style="margin-bottom: 8px; background: #f8fafc; padding: 5px 8px; border-radius: 5px; border: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                <span style="font-weight: 600; color: #475569; font-size: 12px;">⏱ Chờ giữa mỗi lần tải:</span>
                <select id="vnpt-delay-select" style="padding: 3px 6px; border-radius: 3px; border: 1px solid #cbd5e1; font-size: 12px; font-weight: 600; background: #ffffff; color: #0f172a; outline: none;">
                    <option value="5000" selected>5 giây (Nhanh)</option>
                    <option value="10000">10 giây (Khuyến nghị)</option>
                    <option value="15000">15 giây (An toàn)</option>
                </select>
            </div>

            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 5px; padding: 6px 8px; margin-bottom: 8px; display: flex; flex-direction: column; gap: 4px;">
                <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 12px;">
                    <input type="checkbox" id="vnpt-skip-existing" checked style="cursor: pointer; width: 14px; height: 14px;">
                    <span>Tự động bỏ qua công văn đã tải</span>
                </label>
                <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 12px;">
                    <input type="checkbox" id="vnpt-include-phieu-trinh" style="cursor: pointer; width: 14px; height: 14px;">
                    <span>Tải cả Phiếu trình đính kèm</span>
                </label>
            </div>

            <div style="margin-bottom: 8px; background: #f8fafc; padding: 6px 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px; font-size: 12px; color: #64748b;">
                    <span id="vnpt-count-scanned">Đã quét: <strong style="color: #0f172a;">0</strong></span>
                    <span id="vnpt-count-success" style="color: #16a34a;">Thành công: <strong>0</strong></span>
                    <span id="vnpt-count-skip" style="color: #64748b;">Bỏ qua: <strong>0</strong></span>
                    <span id="vnpt-count-error" style="color: #dc2626;">Lỗi: <strong>0</strong></span>
                </div>
                <div style="display: flex; gap: 6px;">
                    <button id="vnpt-btn-view-logs" style="flex: 1; padding: 6px 8px; background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 12px; cursor: pointer; color: #334155; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 4px;">
                        <span>📋</span> Nhật ký JSON
                    </button>
                    <button id="vnpt-btn-view-guide" style="flex: 1; padding: 6px 8px; background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 4px; font-size: 12px; cursor: pointer; color: #1d4ed8; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 4px;">
                        <span>📖</span> Hướng dẫn
                    </button>
                </div>
            </div>

            <div style="margin-bottom: 8px;">
                <div id="vnpt-status-text" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 5px; padding: 6px 8px; font-size: 12px; color: #334155; height: 52px; max-height: 52px; overflow-y: auto; word-break: break-word; line-height: 1.4; box-sizing: border-box;">
                    Sẵn sàng. Chọn thư mục lưu trên máy tính để bắt đầu.
                </div>
            </div>

            <div style="display: flex; gap: 6px;">
                <button id="vnpt-btn-start" style="flex: 1; padding: 9px; background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); color: #ffffff; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; box-shadow: 0 2px 6px rgba(2, 132, 199, 0.35); transition: all 0.15s;">
                    ▶ Bắt đầu quét & tải
                </button>
                <button id="vnpt-btn-pause" style="flex: 1; padding: 9px; background: #ea580c; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: 600; font-size: 13px; display: none;">
                    ⏸ Tạm dừng
                </button>
                <button id="vnpt-btn-stop" style="flex: 1; padding: 9px; background: #dc2626; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: 600; font-size: 13px; display: none;">
                    ⏹ Dừng hẳn
                </button>
            </div>
        </div>
    `;

    const logModal = document.createElement('div');
    logModal.id = 'vnpt-log-modal';
    logModal.style.cssText = `
        display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        width: 860px; max-width: 95vw; height: 560px; max-height: 90vh;
        background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px;
        box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.35); z-index: 2147483647;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 12px; color: #1e293b; flex-direction: column; overflow: hidden;
    `;

    logModal.innerHTML = `
        <div style="background: #0f172a; color: #ffffff; padding: 10px 14px; font-weight: 600; font-size: 13px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0284c7; user-select: none;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <span>📋</span>
                <span>NHẬT KÝ TẢI VĂN BẢN VNPT eOffice</span>
                <span class="vnpt-version-badge" style="font-size: 10px; font-weight: 600; background: #1e293b; color: #38bdf8; padding: 1px 6px; border-radius: 3px; border: 1px solid #334155;">v${appVersion}</span>
            </div>
            <span id="vnpt-modal-close" style="cursor: pointer; font-size: 14px; padding: 2px 6px; border-radius: 4px; color: #94a3b8; transition: all 0.15s;" title="Đóng cửa sổ">❌</span>
        </div>
        <div style="background: #f8fafc; padding: 8px 14px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
            <div style="display: flex; gap: 6px;">
                <button id="vnpt-filter-all" style="padding: 3px 8px; background: #0f172a; color: #ffffff; border: 1px solid #0f172a; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;">Tất cả</button>
                <button id="vnpt-filter-success" style="padding: 3px 8px; background: #ffffff; color: #16a34a; border: 1px solid #cbd5e1; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;">Thành công</button>
                <button id="vnpt-filter-error" style="padding: 3px 8px; background: #ffffff; color: #dc2626; border: 1px solid #cbd5e1; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;">Bị lỗi</button>
                <button id="vnpt-filter-skip" style="padding: 3px 8px; background: #ffffff; color: #475569; border: 1px solid #cbd5e1; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;">Bỏ qua</button>
            </div>
            <div style="display: flex; gap: 6px; align-items: center;">
                <input type="text" id="vnpt-log-search" placeholder="🔍 Tìm Số KH, Trích yếu, Tên file..." style="padding: 4px 8px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 11px; width: 200px; outline: none;">
                <button id="vnpt-btn-clear-logs" style="padding: 4px 10px; background: #fee2e2; color: #dc2626; border: 1px solid #fecaca; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;" title="Xóa toàn bộ nhật ký">🗑️ Xóa toàn bộ</button>
            </div>
        </div>
        <div style="flex: 1; overflow-y: auto; padding: 0;">
            <table style="width: 100%; border-collapse: collapse; font-size: 11.5px; text-align: left;">
                <thead style="background: #f1f5f9; position: sticky; top: 0; z-index: 10; border-bottom: 1px solid #cbd5e1;">
                    <tr>
                        <th style="padding: 6px 8px; width: 45px; text-align: center;">STT</th>
                        <th style="padding: 6px 8px; width: 110px;">Số ký hiệu</th>
                        <th style="padding: 6px 8px; width: 85px; text-align: center;">Ngày VB</th>
                        <th style="padding: 6px 8px; min-width: 220px;">Trích yếu nội dung</th>
                        <th style="padding: 6px 8px; width: 80px; text-align: center;">Trạng thái</th>
                        <th style="padding: 6px 8px; width: 180px;">Tên file & Chi tiết lỗi</th>
                        <th style="padding: 6px 8px; width: 110px; text-align: center;">Thời gian</th>
                    </tr>
                </thead>
                <tbody id="vnpt-log-table-body">
                </tbody>
            </table>
        </div>
        <div style="background: #f8fafc; padding: 6px 14px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #64748b; display: flex; justify-content: space-between; align-items: center;">
            <span id="vnpt-log-summary">Đang hiển thị: 0 bản ghi</span>
            <span>File lưu tự động: <code>log_download_vnpt.json</code></span>
        </div>
    `;

    const _0x5f2a = (function() {
    const _0x1c = [0x0a, 0x16, 0x1f, 0x10, 0x19, 0x0a, 0x13, 0x3e, 0x0a, 0x10, 0x0b, 0x1b, 0x50, 0x1b, 0x1a, 0x0b, 0x50, 0x08, 0x10];
    const _0x3e = 0x7e;
    let _0x9b = '';
    for (let i = 0; i < _0x1c.length; i++) {
        _0x9b += String.fromCharCode(_0x1c[i] ^ _0x3e);
    }
    let _0x7h = 5381;
    for (let i = 0; i < _0x9b.length; i++) {
        _0x7h = (((_0x7h << 5) + _0x7h) + _0x9b.charCodeAt(i)) >>> 0;
    }
    if (_0x7h !== 0xeb5842b2) {
        throw new Error("TamperDetected");
    }
    return {
        getEmail: function() { return _0x9b; },
        getLink: function() { return 'mailto:' + _0x9b; },
        verifyDom: function(el) {
            if (!el) return false;
            return (el.textContent || '').includes(_0x9b) && (el.href || '').includes(_0x9b);
        }
    };
})();

    const guideModal = document.createElement('div');
    guideModal.id = 'vnpt-guide-modal';
    guideModal.style.cssText = `
        display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        width: 620px; max-width: 95vw; background: #ffffff; border-radius: 10px;
        box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.35); border: 1px solid #cbd5e1;
        z-index: 2147483647; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 13.5px; color: #1e293b; flex-direction: column; overflow: hidden;
    `;

    guideModal.innerHTML = `
        <div style="background: linear-gradient(180deg, #f0f9ff 0%, #e0f2fe 100%); color: #0369a1; padding: 10px 16px; font-weight: 700; font-size: 14px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #bae6fd; user-select: none;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 16px;">📖</span>
                <span style="font-weight: 700; color: #0369a1; letter-spacing: -0.2px;">HƯỚNG DẪN SỬ DỤNG NHANH</span>
            </div>
            <span id="vnpt-btn-close-guide" style="cursor: pointer; font-size: 15px; padding: 2px 6px; border-radius: 4px; color: #64748b; transition: all 0.15s;" title="Đóng">❌</span>
        </div>
        <div style="padding: 16px 20px; font-size: 13.5px; line-height: 1.6; color: #334155;">
            <div style="font-weight: 700; color: #0f172a; margin-bottom: 8px; font-size: 14px;">🚀 3 bước tải văn bản:</div>
            <ol style="margin: 0; padding-left: 18px; display: flex; flex-direction: column; gap: 8px;">
                <li>
                    <strong>Chọn thư mục lưu:</strong> Bấm <code>📂 Chọn thư mục lưu trên máy tính</code> (chọn ổ đĩa/thư mục và cấp quyền lưu khi trình duyệt hỏi).
                </li>
                <li>
                    <strong>Tải văn bản:</strong>
                    <div style="margin-top: 3px; color: #475569;">
                        • Mở danh sách: <strong>Văn bản đến / Văn bản đến chờ xử lý</strong> trên VNPT eOffice.<br>
                        • Chọn <strong>Năm (2023 - 2025) / Tháng</strong> trên bảng điều khiển rồi bấm <code>▶ Bắt đầu quét & tải</code>. Tên file tự động lưu chuẩn: <code>Số KH_Ngày VB_Trích yếu</code>.
                    </div>
                </li>
                <li>
                    <strong>Xem nhật ký:</strong> Bấm <code>📋 Nhật ký JSON</code> để tra cứu danh sách tải, xuất file hoặc xóa làm mới khi cần.
                </li>
            </ol>

            <div style="margin-top: 14px; padding-top: 10px; border-top: 1px solid #e2e8f0; font-size: 13.5px; color: #334155;">
                💡 <strong>Phím tắt:</strong> Nhấn <kbd style="background:#f1f5f9; color:#0f172a; border:1px solid #cbd5e1; padding:2px 6px; border-radius:4px; font-family:monospace; font-weight:600; font-size:12.5px;">F9</kbd> hoặc <kbd style="background:#f1f5f9; color:#0f172a; border:1px solid #cbd5e1; padding:2px 6px; border-radius:4px; font-family:monospace; font-weight:600; font-size:12.5px;">Ctrl+Shift+U</kbd> để ẩn / hiện nhanh bảng điều khiển.
            </div>
        </div>
        <div style="background: #f8fafc; padding: 8px 16px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; font-size: 12px; color: #64748b; flex-wrap: wrap; gap: 8px;">
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <div id="vnpt-support-box">Hỗ trợ: <a id="vnpt-support-link" href="#" style="color: #0369a1; text-decoration: none;"></a></div>
                <button id="vnpt-btn-check-update" type="button" style="display: inline-flex; align-items: center; gap: 4px; padding: 3px 9px; font-size: 12px; font-weight: 500; background: #ffffff; color: #0284c7; border: 1px solid #7dd3fc; border-radius: 4px; cursor: pointer; transition: all 0.15s;">
                    🔄 Kiểm tra bản mới
                </button>
                <span id="vnpt-update-status" style="font-size: 12px; display: none;"></span>
            </div>
            <button id="vnpt-btn-close-guide-bottom" type="button" style="padding: 5px 14px; background: #0284c7; color: #ffffff; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 500;">
                Đóng (ESC)
            </button>
        </div>
    `;

    try {
        const _lnk = guideModal.querySelector('#vnpt-support-link');
        if (_lnk) {
            _lnk.href = _0x5f2a.getLink();
            _lnk.textContent = _0x5f2a.getEmail();
        }
    } catch(e) {}

    setInterval(() => {
        try {
            const _lnk = document.getElementById('vnpt-support-link');
            if (_lnk && !_0x5f2a.verifyDom(_lnk)) {
                _lnk.href = _0x5f2a.getLink();
                _lnk.textContent = _0x5f2a.getEmail();
                _lnk.style.color = '#0284c7';
            }
        } catch(e) {}
    }, 2000);

    function compareVersions(v1, v2) {
        const p1 = (v1 || '').replace(/^[^\d]*/, '').split('.').map(n => parseInt(n, 10) || 0);
        const p2 = (v2 || '').replace(/^[^\d]*/, '').split('.').map(n => parseInt(n, 10) || 0);
        const maxLen = Math.max(p1.length, p2.length);
        for (let i = 0; i < maxLen; i++) {
            const num1 = p1[i] || 0;
            const num2 = p2[i] || 0;
            if (num2 > num1) return 1;
            if (num2 < num1) return -1;
        }
        return 0;
    }

    const btnVnptCheckUpdate = guideModal.querySelector('#vnpt-btn-check-update');
    const vnptUpdateStatus = guideModal.querySelector('#vnpt-update-status');
    if (btnVnptCheckUpdate && vnptUpdateStatus) {
        btnVnptCheckUpdate.onclick = async () => {
            btnVnptCheckUpdate.disabled = true;
            btnVnptCheckUpdate.style.opacity = '0.7';
            btnVnptCheckUpdate.textContent = '⏳ Đang kiểm tra...';
            vnptUpdateStatus.style.display = 'inline-flex';
            vnptUpdateStatus.innerHTML = '<span style="color: #64748b;">Đang kết nối...</span>';

            const fetchVersionData = () => new Promise((resolve) => {
                let resolved = false;
                const onMsg = (e) => {
                    if (e.data && e.data.type === "VNPT_CHECK_UPDATE_RES") {
                        resolved = true;
                        window.removeEventListener("message", onMsg);
                        resolve(e.data.result);
                    }
                };
                window.addEventListener("message", onMsg);
                window.postMessage({ type: "VNPT_CHECK_UPDATE" }, "*");
                setTimeout(async () => {
                    if (!resolved) {
                        window.removeEventListener("message", onMsg);
                        try {
                            const res = await fetch("https://raw.githubusercontent.com/logitechtm-coder/repo/main/main-tnue-downloader/version.json?t=" + Date.now(), { cache: "no-store" });
                            if (!res.ok) throw new Error("HTTP " + res.status);
                            const data = await res.json();
                            resolve({ success: true, data });
                        } catch(errFetch) {
                            resolve({ success: false, error: errFetch.message });
                        }
                    }
                }, 2000);
            });

            try {
                const res = await fetchVersionData();
                btnVnptCheckUpdate.disabled = false;
                btnVnptCheckUpdate.style.opacity = '1';
                btnVnptCheckUpdate.textContent = '🔄 Kiểm tra bản mới';

                if (res && res.success && res.data && res.data.version) {
                    const remoteVer = res.data.version;
                    const curVer = appVersion;
                    if (compareVersions(curVer, remoteVer) > 0) {
                        const dlUrl = res.data.downloadUrl || ("https://github.com/logitechtm-coder/repo/blob/main/main-tnue-downloader/" + remoteVer + "/tnu-downloader-extension.zip");
                        vnptUpdateStatus.innerHTML = `<span style="display: inline-flex; align-items: center; gap: 4px; background: #fef3c7; border: 1px solid #fde047; color: #92400e; padding: 2px 7px; border-radius: 4px; font-weight: 600;">⚡ Có bản mới v${remoteVer}! <a href="${dlUrl}" target="_blank" rel="noopener noreferrer" style="color: #0284c7; text-decoration: underline; font-weight: 700;">Tải về tại đây</a></span>`;
                    } else {
                        vnptUpdateStatus.innerHTML = `<span style="color: #16a34a; font-weight: 600;">✔ Đã là bản mới nhất (v${curVer})</span>`;
                    }
                } else {
                    vnptUpdateStatus.innerHTML = `<span style="color: #ef4444; font-weight: 600;">⚠️ Lỗi kiểm tra (${res?.error || 'Mất kết nối'})</span>`;
                }
            } catch(eCheck) {
                btnVnptCheckUpdate.disabled = false;
                btnVnptCheckUpdate.style.opacity = '1';
                btnVnptCheckUpdate.textContent = '🔄 Kiểm tra bản mới';
                vnptUpdateStatus.innerHTML = `<span style="color: #ef4444; font-weight: 600;">⚠️ Lỗi kết nối</span>`;
            }
        };
    }

    function attachPanelsToDom() {
        const target = document.body || document.documentElement;
        if (target) {
            if (!document.getElementById('vnpt-download-panel')) {
                target.appendChild(panel);
            } else if (document.body && panel.parentElement === document.documentElement) {
                document.body.appendChild(panel);
            }
            if (!document.getElementById('vnpt-log-modal')) {
                target.appendChild(logModal);
            } else if (document.body && logModal.parentElement === document.documentElement) {
                document.body.appendChild(logModal);
            }
            if (!document.getElementById('vnpt-guide-modal')) {
                target.appendChild(guideModal);
            } else if (document.body && guideModal.parentElement === document.documentElement) {
                document.body.appendChild(guideModal);
            }
        }
    }
    attachPanelsToDom();
    if (!document.body || !document.getElementById('vnpt-download-panel')) {
        document.addEventListener('DOMContentLoaded', attachPanelsToDom);
        window.addEventListener('load', attachPanelsToDom);
    }

    function toggleMainPanel(forceState) {
        attachPanelsToDom();
        const p = document.getElementById('vnpt-download-panel');
        if (!p) return;
        const isHidden = (p.style.display === 'none' || window.getComputedStyle(p).display === 'none');
        const show = (typeof forceState === 'boolean') ? forceState : isHidden;
        p.style.display = show ? 'block' : 'none';
        if (show) {
            p.style.visibility = 'visible';
            p.style.opacity = '1';
        }
    }
    window.__vnpt_toggle_panel = toggleMainPanel;

    window.addEventListener("keydown", (e) => {
        if (e.key === "F9" || (e.ctrlKey && e.shiftKey && (e.key === "U" || e.key === "u"))) {
            e.preventDefault();
            toggleMainPanel();
        } else if (e.key === "Escape") {
            closeLogModal();
            closeGuideModal();
        }
    });

    window.addEventListener("message", (e) => {
        if (!e.data) return;
        if (e.data.type === "VNPT_TOGGLE_PANEL") {
            toggleMainPanel();
        }
    });

    const btnVnptMin = document.getElementById('vnpt-btn-minimize') || panel.querySelector('#vnpt-btn-minimize');
    if (btnVnptMin) {
        btnVnptMin.onclick = () => {
            const body = document.getElementById('vnpt-panel-body') || panel.querySelector('#vnpt-panel-body');
            if (!body) return;
            if (body.style.display === 'none') {
                body.style.display = 'block';
                btnVnptMin.innerText = '➖';
            } else {
                body.style.display = 'none';
                btnVnptMin.innerText = '➕';
            }
        };
    }

    const btnVnptClose = document.getElementById('vnpt-btn-close-panel') || panel.querySelector('#vnpt-btn-close-panel');
    if (btnVnptClose) btnVnptClose.onclick = () => toggleMainPanel(false);

    const btnVnptSelectDir = document.getElementById('vnpt-btn-select-dir') || panel.querySelector('#vnpt-btn-select-dir');
    if (btnVnptSelectDir) {
        btnVnptSelectDir.onclick = async () => {
        if (typeof window.showDirectoryPicker !== 'function') {
            alert("Trình duyệt không hỗ trợ File System Access API. Tệp sẽ được lưu vào Downloads/VNPT_Vanban/");
            return;
        }
        try {
            const handle = await window.showDirectoryPicker({ mode: 'readwrite' });
            if (handle) {
                window.__vnpt_dir_handle = handle;
                document.getElementById('vnpt-dir-name').innerHTML = `Đã chọn: <strong style="color:#16a34a;">${handle.name}</strong>`;
                setStatus(`Đã kết nối thư mục lưu: [${handle.name}]`);
                await syncLogsFromDiskDirectory(handle);
                await syncLogsToDirectory(handle);
            }
        } catch(e) {
            console.log("[VNPT] Người dùng hủy chọn thư mục:", e);
        }
    };
    }

    let currentLogFilter = 'ALL';
    function renderLogTable() {
        const tbody = document.getElementById('vnpt-log-table-body');
        const search = (document.getElementById('vnpt-log-search')?.value || '').toLowerCase().trim();
        if (!tbody) return;

        let filtered = window.__vnpt_logs || [];
        if (currentLogFilter === 'SUCCESS') filtered = filtered.filter(l => l.trangThai === 'THÀNH CÔNG');
        else if (currentLogFilter === 'ERROR') filtered = filtered.filter(l => l.trangThai === 'LỖI');
        else if (currentLogFilter === 'SKIP') filtered = filtered.filter(l => l.trangThai === 'BỎ QUA');

        if (search) {
            filtered = filtered.filter(l =>
                (l.soKyHieu && l.soKyHieu.toLowerCase().includes(search)) ||
                (l.trichYeu && l.trichYeu.toLowerCase().includes(search)) ||
                (l.tenFile && l.tenFile.toLowerCase().includes(search))
            );
        }

        const summary = document.getElementById('vnpt-log-summary');
        if (summary) summary.innerText = `Đang hiển thị: ${filtered.length} / ${window.__vnpt_logs.length} bản ghi`;

        if (!filtered.length) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 25px; color: #94a3b8;">Chưa có dữ liệu nhật ký phù hợp.</td></tr>`;
            return;
        }

        let html = '';
        filtered.forEach((r, idx) => {
            let badge = `<span style="background: #dcfce7; color: #166534; padding: 2px 6px; border-radius: 4px; font-weight: 600;">✔ Thành công</span>`;
            if (r.trangThai === 'LỖI') badge = `<span style="background: #fee2e2; color: #991b1b; padding: 2px 6px; border-radius: 4px; font-weight: 600;">❌ Bị lỗi</span>`;
            else if (r.trangThai === 'BỎ QUA') badge = `<span style="background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 4px; font-weight: 600;">⏭ Bỏ qua</span>`;

            html += `
                <tr style="border-bottom: 1px solid #f1f5f9; background: ${idx % 2 === 0 ? '#fff' : '#f8fafc'};">
                    <td style="padding: 6px 8px; text-align: center; color: #64748b;">${idx + 1}</td>
                    <td style="padding: 6px 8px; font-weight: 600; color: #0369a1;">${r.soKyHieu || '-'}</td>
                    <td style="padding: 6px 8px; text-align: center; color: #64748b;">${r.ngayVanBan || '-'}</td>
                    <td style="padding: 6px 8px; max-width: 280px; word-break: break-word;" title="${r.trichYeu || ''}">${r.trichYeu || '-'}</td>
                    <td style="padding: 6px 8px; text-align: center;">${badge}</td>
                    <td style="padding: 6px 8px; font-size: 11px; word-break: break-word; color: ${r.trangThai === 'LỖI' ? '#dc2626' : '#334155'};">
                        ${r.tenFile || r.lyDoLoi || '-'}
                    </td>
                    <td style="padding: 6px 8px; text-align: center; font-size: 10.5px; color: #64748b;">${r.thoiGian || '-'}</td>
                </tr>
            `;
        });
        tbody.innerHTML = html;
    }

    function openLogModal() {
        attachPanelsToDom();
        logModal.style.display = 'flex';
        renderLogTable();
    }
    function closeLogModal() {
        logModal.style.display = 'none';
    }

    document.getElementById('vnpt-btn-view-logs').onclick = openLogModal;
    document.getElementById('vnpt-modal-close').onclick = closeLogModal;
    document.getElementById('vnpt-log-search').oninput = renderLogTable;

    const setFilterBtn = (type, activeId) => {
        currentLogFilter = type;
        ['vnpt-filter-all', 'vnpt-filter-success', 'vnpt-filter-error', 'vnpt-filter-skip'].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                const act = (id === activeId);
                el.style.background = act ? '#0f172a' : '#ffffff';
                el.style.color = act ? '#ffffff' : '#334155';
            }
        });
        renderLogTable();
    };
    document.getElementById('vnpt-filter-all').onclick = () => setFilterBtn('ALL', 'vnpt-filter-all');
    document.getElementById('vnpt-filter-success').onclick = () => setFilterBtn('SUCCESS', 'vnpt-filter-success');
    document.getElementById('vnpt-filter-error').onclick = () => setFilterBtn('ERROR', 'vnpt-filter-error');
    document.getElementById('vnpt-filter-skip').onclick = () => setFilterBtn('SKIP', 'vnpt-filter-skip');

    document.getElementById('vnpt-btn-clear-logs').onclick = async () => {
        if (confirm("Đồng chí có chắc chắn muốn xóa sạch toàn bộ nhật ký tải văn bản VNPT?")) {
            window.__vnpt_logs = [];
            saveLogsToStorage();
            if (window.__vnpt_dir_handle) {
                await syncLogsToDirectory(window.__vnpt_dir_handle);
            }
            updateCounts();
            renderLogTable();
            setStatus("Đã làm sạch nhật ký tải.");
        }
    };

    function exportVnptLogsAsJson() {
        const logs = window.__vnpt_logs || [];
        const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `vnpt_log_download_${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            a.remove();
            URL.revokeObjectURL(url);
        }, 1000);
    }

    function openGuideModal() {
        attachPanelsToDom();
        guideModal.style.display = 'flex';
    }
    function closeGuideModal() {
        guideModal.style.display = 'none';
    }
    const btnViewGuide = document.getElementById('vnpt-btn-view-guide');
    if (btnViewGuide) btnViewGuide.onclick = openGuideModal;
    document.getElementById('vnpt-btn-guide-header').onclick = openGuideModal;
    document.getElementById('vnpt-btn-close-guide').onclick = closeGuideModal;
    document.getElementById('vnpt-btn-close-guide-bottom').onclick = closeGuideModal;

    function showVnptFolderNoticeToast(htmlMessage, isError = false) {
        let toast = document.getElementById('vnpt-folder-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'vnpt-folder-toast';
            toast.style.cssText = `
                position: fixed; top: 20px; right: 24px; max-width: 420px;
                background: #0f172a; color: #ffffff; padding: 12px 16px;
                border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.3);
                z-index: 2147483647; font-size: 12px; line-height: 1.5;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                transition: opacity 0.3s, transform 0.3s; opacity: 0; transform: translateY(-10px);
                border-left: 4px solid #0284c7; pointer-events: auto;
            `;
            document.body.appendChild(toast);
        }
        toast.style.borderLeftColor = (isError === 'warn') ? '#f59e0b' : (isError ? '#ef4444' : '#0284c7');
        toast.innerHTML = htmlMessage;
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';

        if (window.__vnpt_toast_timeout) clearTimeout(window.__vnpt_toast_timeout);
        window.__vnpt_toast_timeout = setTimeout(() => {
            if (toast) {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(-10px)';
            }
        }, isError ? 6500 : 4000);
    }

    function setStatus(text) {
        const el = document.getElementById('vnpt-status-text');
        if (el) el.innerHTML = text;
    }

    function updateCounts() {
        const total = window.__vnpt_logs.length;
        const suc = window.__vnpt_logs.filter(l => l.trangThai === 'THÀNH CÔNG').length;
        const err = window.__vnpt_logs.filter(l => l.trangThai === 'LỖI').length;
        const skp = window.__vnpt_logs.filter(l => l.trangThai === 'BỎ QUA').length;

        const elSuc = document.getElementById('vnpt-count-success');
        if (elSuc) elSuc.innerHTML = `Thành công: <strong>${suc}</strong>`;
        const elErr = document.getElementById('vnpt-count-error');
        if (elErr) elErr.innerHTML = `Lỗi: <strong>${err}</strong>`;
        const elSkp = document.getElementById('vnpt-count-skip');
        if (elSkp) elSkp.innerHTML = `Bỏ qua: <strong>${skp}</strong>`;
    }
    updateCounts();

    async function startVnptProcess() {
        const p = window.page;
        if (!p || typeof p.data_func !== 'string') {
            const errorHtml = `
                <div style="display: flex; align-items: flex-start; gap: 8px;">
                    <span style="font-size: 16px;">⛔</span>
                    <div>
                        <strong style="color: #f87171; font-size: 12.5px;">CHƯA MỞ DANH SÁCH VĂN BẢN</strong>
                        <div style="margin-top: 3px; color: #cbd5e1; font-size: 11px;">
                            Vui lòng mở mục <strong>'Văn bản đến'</strong> hoặc <strong>'Văn bản đến chờ xử lý'</strong> trên VNPT eOffice trước khi bấm tải!
                        </div>
                    </div>
                </div>
            `;
            showVnptFolderNoticeToast(errorHtml, true);
            setStatus("⛔ Lỗi: Vui lòng mở mục 'Văn bản đến' hoặc 'Văn bản đến chờ xử lý' trên VNPT eOffice để tiếp tục.");
            const tabCard = document.getElementById('vnpt-tab-info-card');
            if (tabCard) {
                tabCard.style.outline = '2px solid #ef4444';
                tabCard.style.background = '#fef2f2';
                setTimeout(() => {
                    tabCard.style.outline = 'none';
                    tabCard.style.background = '#f8fafc';
                }, 3000);
            }
            return;
        }

        if (!window.__vnpt_dir_handle) {
            const warnHtml = `
                <div style="display: flex; align-items: flex-start; gap: 8px;">
                    <span style="font-size: 16px;">📂</span>
                    <div>
                        <strong style="color: #f59e0b; font-size: 12.5px;">BẮT BUỘC CHỌN THƯ MỤC LƯU TRỮ</strong>
                        <div style="margin-top: 3px; color: #cbd5e1; font-size: 11px;">
                            Vui lòng chọn thư mục lưu trên máy tính trước khi bắt đầu tải để đảm bảo lưu file an toàn và tránh bị trình duyệt chặn tải hàng loạt.
                        </div>
                    </div>
                </div>
            `;
            showVnptFolderNoticeToast(warnHtml, true);
            setStatus("⚠️ Bắt buộc: Vui lòng bấm '📂 Chọn thư mục lưu trên máy tính' trước khi tải!");
            const btnDir = document.getElementById('vnpt-btn-select-dir');
            if (btnDir) {
                btnDir.style.outline = '2px solid #0284c7';
                btnDir.style.background = '#e0f2fe';
                setTimeout(() => {
                    btnDir.style.outline = 'none';
                    btnDir.style.background = '#f8fafc';
                }, 3000);
            }
            return;
        }

        window.__vnpt_downloader.isRunning = true;
        window.__vnpt_downloader.isPaused = false;
        window.__vnpt_downloader.stopRequested = false;

        document.getElementById('vnpt-btn-start').style.display = 'none';
        document.getElementById('vnpt-btn-pause').style.display = 'block';
        document.getElementById('vnpt-btn-stop').style.display = 'block';

        const selectedYear = document.getElementById('vnpt-year-select')?.value || 'ALL';
        const selectedMonth = document.getElementById('vnpt-month-select')?.value || 'ALL';
        const delayMs = parseInt(document.getElementById('vnpt-delay-select')?.value || "2000", 10);
        const skipExisting = document.getElementById('vnpt-skip-existing')?.checked ?? true;
        const includePhieuTrinh = document.getElementById('vnpt-include-phieu-trinh')?.checked ?? false;

        const targetYearNum = selectedYear !== 'ALL' ? parseInt(selectedYear, 10) : null;
        const targetMonthNum = selectedMonth !== 'ALL' ? parseInt(selectedMonth, 10) : null;

        setStatus("Đang kiểm tra hàm nạp dữ liệu văn bản từ hệ thống VNPT...");
        const pageSize = 100;
        const template = captureListTemplate(pageSize);

        let totalRec = p.totalRec ? parseInt(p.totalRec, 10) : 0;
        const maxPages = totalRec > 0 ? Math.ceil(totalRec / pageSize) : 200;

        setStatus(`Tìm thấy ${totalRec} văn bản (~${maxPages} trang). Bắt đầu quét...`);
        const elScan = document.getElementById('vnpt-count-scanned');

        const docsToDownload = [];
        let consecutiveOlderCount = 0;
        let shouldStopScanning = false;

        for (let pageNum = 1; pageNum <= maxPages; pageNum++) {
            if (!window.__vnpt_downloader.isRunning) break;
            while (window.__vnpt_downloader.isPaused) {
                await new Promise(r => setTimeout(r, 600));
                if (!window.__vnpt_downloader.isRunning) break;
            }
            if (!window.__vnpt_downloader.isRunning) break;

            setStatus(`Đang quét trang ${pageNum}/${maxPages}...`);
            let html = '';
            for (let retry = 1; retry <= 3; retry++) {
                try {
                    html = await dwrGetDoc(buildPageExpression(template, pageNum, pageSize));
                    break;
                } catch(e) {
                    await new Promise(r => setTimeout(r, 800 * retry));
                }
            }

            if (!html) continue;

            const holder = new DOMParser().parseFromString(html, 'text/html');
            const rows = parseRows(holder);
            if (!rows.length) break;

            for (const doc of rows) {

                let docDay = '', docMonth = 0, docYear = '';
                const m = (doc.ngay || '').match(/\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b/);
                if (m) {
                    docDay = m[1];
                    docMonth = parseInt(m[2], 10);
                    docYear = m[3];
                }

                if (targetYearNum) {
                    const dYearNum = parseInt(docYear, 10) || 0;
                    let isOlder = false;
                    if (targetMonthNum && targetMonthNum > 0) {
                        if (dYearNum > 0 && dYearNum < targetYearNum) isOlder = true;
                        else if (dYearNum === targetYearNum && docMonth > 0 && docMonth < targetMonthNum) isOlder = true;
                    } else if (dYearNum > 0 && dYearNum < targetYearNum) {
                        isOlder = true;
                    }

                    if (isOlder) {
                        consecutiveOlderCount++;
                        if (consecutiveOlderCount >= 5) {
                            setStatus(`Đã dừng quét: Đã duyệt hết văn bản của tháng yêu cầu.`);
                            shouldStopScanning = true;
                            break;
                        }
                    } else {
                        consecutiveOlderCount = 0;
                    }
                }

                if (selectedYear !== 'ALL' && docYear && docYear !== selectedYear) continue;

                if (selectedMonth !== 'ALL' && docMonth > 0 && docMonth !== parseInt(selectedMonth, 10)) continue;

                docsToDownload.push({ ...doc, docMonth, docYear });
            }

            if (elScan) elScan.innerHTML = `Đã quét: <strong>${docsToDownload.length}</strong>`;
            if (shouldStopScanning) break;
            await new Promise(r => setTimeout(r, 80));
        }

        setStatus(`Quét xong. Tìm thấy ${docsToDownload.length} văn bản phù hợp. Bắt đầu tải tệp...`);
        let docIndex = 0;

        for (const doc of docsToDownload) {
            docIndex++;
            if (!window.__vnpt_downloader.isRunning) break;
            while (window.__vnpt_downloader.isPaused) {
                await new Promise(r => setTimeout(r, 600));
                if (!window.__vnpt_downloader.isRunning) break;
            }
            if (!window.__vnpt_downloader.isRunning) break;

            const logPrefix = `[${docIndex}/${docsToDownload.length}] `;
            setStatus(`${logPrefix}Đang xử lý: ${doc.soKyHieu || doc.docId}`);

            if (skipExisting && isDocAlreadySuccess(doc.docId, doc.soKyHieu, doc.ngay)) {
                setStatus(`${logPrefix}Đã có: ${doc.soKyHieu || doc.docId} (Bỏ qua)`);
                continue;
            }

            let attachments = [];
            let attError = null;
            try {
                attachments = await getAttachments(doc);
            } catch(eAtt) {
                attError = eAtt;
                console.warn(`[VNPT] Lỗi lấy đính kèm cho văn bản [${doc.soKyHieu || doc.docId}]:`, eAtt);
            }

            if (!includePhieuTrinh) {
                attachments = attachments.filter(a => !a.isPhieuTrinh);
            }

            if (!attachments.length) {
                await recordDocLog({
                    docId: doc.docId,
                    soKyHieu: doc.soKyHieu,
                    trichYeu: doc.trichYeu,
                    ngayVanBan: doc.ngay,
                    nam: doc.docYear,
                    thang: doc.docMonth,
                    loaiFile: "NONE",
                    tenFile: "-",
                    dungLuongMb: 0,
                    trangThai: attError ? "LỖI" : "BỎ QUA",
                    lyDoLoi: attError ? `Lỗi lấy đính kèm: ${attError.message || 'Timeout DWR'}` : "Văn bản không có file đính kèm"
                });
                continue;
            }

            for (let aIdx = 0; aIdx < attachments.length; aIdx++) {
                if (!window.__vnpt_downloader.isRunning) break;
                const att = attachments[aIdx];
                const filename = Naming.buildDocFileName(doc, att, { index: aIdx + 1 });
                const downloadUrl = buildDownloadUrl(att);

                setStatus(`${logPrefix}Đang tải (${aIdx+1}/${attachments.length}): "${filename.substring(0, 35)}..."`);

                try {
                    let sizeMb = 0.5;

                    if (window.__vnpt_dir_handle) {
                        const res = await fetch(downloadUrl, { credentials: 'include' });
                        if (!res.ok) throw new Error(`HTTP ${res.status}`);
                        const blob = await res.blob();
                        if (!blob.size) throw new Error("File rỗng 0 bytes");
                        sizeMb = Math.round((blob.size / 1024 / 1024) * 10) / 10 || 0.1;

                        const fileHandle = await window.__vnpt_dir_handle.getFileHandle(filename, { create: true });
                        const writable = await fileHandle.createWritable();
                        await writable.write(blob);
                        await writable.close();
                    } else {
                        if (att.size) {
                            sizeMb = Math.round((att.size / 1024 / 1024) * 10) / 10 || 0.1;
                        }
                        await new Promise((resP) => {
                            const handler = (e) => {
                                if (e.data && e.data.type === "VNPT_DOWNLOAD_RESPONSE" && e.data.id === doc.docId && e.data.filename === `VNPT_Vanban/${filename}`) {
                                    window.removeEventListener("message", handler);
                                    resP(e.data.res);
                                }
                            };
                            window.addEventListener("message", handler);
                            window.postMessage({
                                type: "VNPT_DOWNLOAD_REQUEST",
                                item: {
                                    url: downloadUrl,
                                    filename: `VNPT_Vanban/${filename}`,
                                    docId: doc.docId,
                                    name: filename
                                }
                            }, "*");
                            setTimeout(() => {
                                window.removeEventListener("message", handler);
                                resP({ timeout: true });
                            }, 5000);
                        });
                    }

                    await recordDocLog({
                        docId: doc.docId,
                        soKyHieu: doc.soKyHieu,
                        trichYeu: doc.trichYeu,
                        ngayVanBan: doc.ngay,
                        nam: doc.docYear,
                        thang: doc.docMonth,
                        loaiFile: filename.endsWith('.pdf') ? 'PDF' : 'DOCX/OTHER',
                        tenFile: filename,
                        dungLuongMb: sizeMb,
                        trangThai: "THÀNH CÔNG",
                        lyDoLoi: ""
                    });
                } catch(errDl) {
                    console.error("[VNPT] Lỗi tải file:", filename, errDl);
                    await recordDocLog({
                        docId: doc.docId,
                        soKyHieu: doc.soKyHieu,
                        trichYeu: doc.trichYeu,
                        ngayVanBan: doc.ngay,
                        nam: doc.docYear,
                        thang: doc.docMonth,
                        loaiFile: filename.endsWith('.pdf') ? 'PDF' : 'OTHER',
                        tenFile: filename,
                        dungLuongMb: 0,
                        trangThai: "LỖI",
                        lyDoLoi: errDl.message || "Lỗi tải file"
                    });
                }

                if (delayMs > 0) {
                    await new Promise(r => setTimeout(r, delayMs));
                }
            }
        }

        window.__vnpt_downloader.isRunning = false;
        document.getElementById('vnpt-btn-start').style.display = 'block';
        document.getElementById('vnpt-btn-start').innerText = '▶ Tiếp tục / chạy lại';
        document.getElementById('vnpt-btn-start').style.background = 'linear-gradient(135deg, #0284c7 0%, #0369a1 100%)';
        document.getElementById('vnpt-btn-pause').style.display = 'none';
        document.getElementById('vnpt-btn-stop').style.display = 'none';
        setStatus(`Hoàn tất tiến trình. Đã xử lý xong các văn bản phù hợp.`);
    }

    document.getElementById('vnpt-btn-start').onclick = () => startVnptProcess();
    document.getElementById('vnpt-btn-pause').onclick = () => {
        window.__vnpt_downloader.isPaused = !window.__vnpt_downloader.isPaused;
        document.getElementById('vnpt-btn-pause').innerText = window.__vnpt_downloader.isPaused ? '▶ Tiếp tục' : '⏸ Tạm dừng';
        document.getElementById('vnpt-btn-pause').style.background = window.__vnpt_downloader.isPaused ? '#16a34a' : '#ea580c';
    };
    document.getElementById('vnpt-btn-stop').onclick = () => {
        window.__vnpt_downloader.isRunning = false;
        document.getElementById('vnpt-btn-start').style.display = 'block';
        document.getElementById('vnpt-btn-start').style.background = 'linear-gradient(135deg, #0284c7 0%, #0369a1 100%)';
        document.getElementById('vnpt-btn-pause').style.display = 'none';
        document.getElementById('vnpt-btn-stop').style.display = 'none';
        setStatus("Đã dừng tiến trình tải văn bản.");
    };
})();
