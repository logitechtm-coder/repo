(function() {
    const oldPanel = document.getElementById('tnu-download-panel');
    if (oldPanel) oldPanel.remove();
    const oldLogModal = document.getElementById('tnu-log-modal');
    if (oldLogModal) oldLogModal.remove();

    window.__tnu_downloader = {
        isRunning: false,
        isPaused: false,
        totalDownloaded: 0,
        totalSkipped: 0,
        totalError: 0,
        currentPage: 1
    };

    window.__tnu_dir_handle = window.__tnu_dir_handle || null;
    window.__tnu_captured_url = null;
    window.__tnu_captured_time = 0;
    window.__tnu_download_completed_time = 0;
    window.__tnu_fs_saved_time = 0;
    window.__tnu_fs_saved_filename = null;

    if (!window.__tnu_save_blob_listener_attached) {
        window.__tnu_save_blob_listener_attached = true;
        window.addEventListener("message", async (event) => {
            if (!event.data) return;
            if (event.data.type === "TNU_SAVE_BLOB_TO_HANDLE") {
                const { filename, dataUrl } = event.data;
                if (window.__tnu_dir_handle && dataUrl) {
                    try {
                        const res = await fetch(dataUrl);
                        const blob = await res.blob();
                        if (blob && blob.size > 0) {
                            await saveBlobToDirectory(window.__tnu_dir_handle, filename, blob);
                            window.__tnu_fs_saved_time = Date.now();
                            window.__tnu_fs_saved_filename = filename;
                            const sizeMb = (blob.size / (1024 * 1024)).toFixed(2);
                            appendStepLog(`✔ Đã lưu trực tiếp file vào thư mục [${window.__tnu_dir_handle.name}]: ${filename} (${sizeMb} MB)`);
                        }
                    } catch(e) {
                        console.error("[TNUE] Lỗi ghi blob vào thư mục handle:", e);
                    }
                }
            }
        });
    }

    window.__tnu_step_logs = window.__tnu_step_logs || [];

    function appendStepLog(message) {
        const now = new Date();
        const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}.${now.getMilliseconds().toString().padStart(3, '0')}`;
        const logLine = `[${timeStr}] ${message}`;
        window.__tnu_step_logs.push(logLine);
        console.log(`📝 [TNUE LOG] ${logLine}`);

        if (window.__tnu_dir_handle) {
            saveStepLogToDirectory().catch(() => {});
        }
    }

    let _saveLogTimer = null;
    async function saveStepLogToDirectory() {

    }

    window.__tnu_logs = window.__tnu_logs || [];
    try {
        const savedLogs = localStorage.getItem('tnu_download_logs');
        if (savedLogs) {
            window.__tnu_logs = cleanDuplicateLogs(JSON.parse(savedLogs));
        }
    } catch (e) {
        console.warn("Không thể khôi phục log từ localStorage:", e);
    }

    const IDB_NAME = 'tnu_downloader_db';
    const IDB_STORE = 'settings';

    function openTnuIDB() {
        return new Promise((resolve) => {
            if (!window.indexedDB) return resolve(null);
            const req = indexedDB.open(IDB_NAME, 1);
            req.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(IDB_STORE)) {
                    db.createObjectStore(IDB_STORE);
                }
            };
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => resolve(null);
        });
    }

    async function saveDirectoryHandleToIDB(handle) {
        try {
            const db = await openTnuIDB();
            if (!db) return;
            const tx = db.transaction(IDB_STORE, 'readwrite');
            tx.objectStore(IDB_STORE).put(handle, 'last_dir_handle');
        } catch(e) {}
    }

    async function loadDirectoryHandleFromIDB() {
        try {
            const db = await openTnuIDB();
            if (!db) return null;
            return new Promise((resolve) => {
                const tx = db.transaction(IDB_STORE, 'readonly');
                const req = tx.objectStore(IDB_STORE).get('last_dir_handle');
                req.onsuccess = async () => {
                    const handle = req.result;
                    if (handle && typeof handle.queryPermission === 'function') {
                        try {
                            const perm = await handle.queryPermission({ mode: 'readwrite' });
                            if (perm === 'granted') {
                                return resolve(handle);
                            }
                        } catch(e) {}
                    }
                    resolve(null);
                };
                req.onerror = () => resolve(null);
            });
        } catch(e) {
            return null;
        }
    }

    async function syncLogsFromDiskDirectory(dirHandle, isNewDirectorySelected = false) {
        if (!dirHandle) return;
        try {
            let fileHandle = null;
            try {
                fileHandle = await dirHandle.getFileHandle('log_download_tnu.json');
            } catch(noFileErr) {
                try {
                    fileHandle = await dirHandle.getFileHandle('log_download.json');
                } catch(eOld) {}

                if (!fileHandle) {
                    if (isNewDirectorySelected) {
                        window.__tnu_logs = [];
                        _fastLogIndexMap = null;
                        _fastLogIndexLen = -1;
                        try {
                            localStorage.setItem('tnu_download_logs', JSON.stringify([]));
                        } catch(e) {}
                        if (typeof updateCounts === 'function') updateCounts();
                        if (typeof updateLastPageBadge === 'function') updateLastPageBadge();
                        if (typeof renderLogTable === 'function') renderLogTable();
                        if (typeof scheduleHotButtonRender === 'function') scheduleHotButtonRender(50);
                    }
                    return;
                }
            }

            const file = await fileHandle.getFile();
            const textContent = await file.text();
            if (textContent && textContent.trim()) {
                const diskLogs = JSON.parse(textContent);
                if (Array.isArray(diskLogs)) {
                    const isTnuLog = diskLogs.some(item => item.donViBanHanh !== undefined || item.ngayBanHanh !== undefined || item.partyMode !== undefined || item.soKyHieu !== undefined || item.trichYeu !== undefined || item.tenFile !== undefined);
                    if (isTnuLog || diskLogs.length === 0) {
                        window.__tnu_logs = cleanDuplicateLogs(diskLogs);
                        _fastLogIndexMap = null;
                        _fastLogIndexLen = -1;
                        try {
                            localStorage.setItem('tnu_download_logs', JSON.stringify(window.__tnu_logs));
                        } catch(e) {}
                        if (typeof updateCounts === 'function') updateCounts();
                        if (typeof updateLastPageBadge === 'function') updateLastPageBadge();
                        if (typeof renderLogTable === 'function') renderLogTable();
                        if (typeof scheduleHotButtonRender === 'function') scheduleHotButtonRender(50);
                        await saveAllLogsToDirectory();
                    }
                }
            }
        } catch(e) {
            console.warn("[TNUE] syncLogsFromDiskDirectory warning:", e);
        }
    }

    if (!window.__tnu_confirm_hooked) {
        window.confirm = function(msg) {
            console.log("🔥 [TNUE - vOffice Downloader] Tự động chấp thuận confirm:", msg);
            return true;
        };
        window.__tnu_confirm_hooked = true;
    }

    function triggerClick(targetElement) {
        const el = targetElement;
        if (!el) return;
        try {
            el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
            el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
            el.click();
        } catch (e) {
            try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); } catch(e2) {}
        }
        try {
            if (window.zk && window.zk.Widget) {
                const w = window.zk.Widget.$(el);
                if (w) {
                    if (window.zUtl && window.zUtl.sendEvent) {
                        window.zUtl.sendEvent(w, 'onClick');
                    } else if (w.fire) {
                        w.fire('onClick', {});
                    }
                }
            }
        } catch(e) {}
    }

    function autoConfirmSecurityDialog() {
        const modals = Array.from(document.querySelectorAll('.z-window-modal, .z-messagebox-window, .z-window-highlighted, .z-window, div[class*="messagebox"], div[class*="window"]')).filter(m =>
            m.offsetParent !== null && m.id !== 'tnu-download-panel' && m.id !== 'tnu-log-modal' && m.id !== 'tnu-guide-modal' && m.isConnected
        );

        for (const m of modals) {

            const isMessageBox = m.classList.contains('z-messagebox-window') ||
                                 m.classList.contains('z-messagebox') ||
                                 Boolean(m.querySelector('.z-messagebox, .z-messagebox-buttons, .z-messagebox-btn, .z-messagebox-icon'));

            if (!isMessageBox) {
                const isDetailWindow = m.querySelector('.z-tabbox, .z-tabpanel, textarea, input[type="text"]') ||
                                       m.querySelector('.z-listbox, table.z-listbox-body') ||
                                       (m.querySelector('.z-window-header')?.innerText || '').toLowerCase().includes('chi tiết') ||
                                       (m.innerText || '').toLowerCase().includes('thông tin chi tiết');
                if (isDetailWindow) {
                    continue;
                }
            }

            const text = (m.innerText || '').toLowerCase();
            const isSecurityPrompt = text.includes('an toàn thông tin') ||
                                     text.includes('bảo đảm an toàn') ||
                                     text.includes('chịu trách nhiệm') ||
                                     text.includes('đồng chí có muốn') ||
                                     (text.includes('tiếp tục không') && (text.includes('file') || text.includes('tệp') || text.includes('tải') || text.includes('đồng chí')));

            if (!isSecurityPrompt && !isMessageBox) continue;
            if (isMessageBox && !text.includes('an toàn') && !text.includes('tiếp tục') && !text.includes('trách nhiệm') && !text.includes('tải')) {
                continue;
            }

            const now = Date.now();
            if (m.dataset.tnuLastClick && (now - parseInt(m.dataset.tnuLastClick, 10)) < 1000) {
                continue;
            }

            const allButtons = Array.from(m.querySelectorAll('button, a.z-button, div.z-button, span.z-button, [class*="btn"], [class*="button"], a, span'));
            let yesBtn = allButtons.find(btn => {
                const bText = (btn.innerText || '').trim().toLowerCase();
                return bText === 'có' || bText === 'đồng ý' || bText === 'tiếp tục' ||
                       bText === 'ok' || bText === 'xác nhận' || bText === 'chấp nhận' ||
                       bText === 'yes' || btn.classList.contains('z-messagebox-btn-yes');
            });

            if (!yesBtn) {
                const msgBtns = m.querySelectorAll('.z-messagebox-buttons button, .z-messagebox-buttons .z-button');
                if (msgBtns.length > 0) {
                    yesBtn = msgBtns[0];
                }
            }

            if (yesBtn) {
                m.dataset.tnuLastClick = String(now);
                const targetBtn = yesBtn.closest('button, .z-button, a') || yesBtn;
                console.log("🔥 [TNUE - vOffice Downloader] Tự động bấm nút Có/Đồng ý an toàn thông tin:", targetBtn.innerText || targetBtn.className);
                triggerClick(targetBtn);
                return true;
            }
        }
        return false;
    }

    window.__tnu_download_completed_time = 0;
    window.__tnu_last_download_completed_time = 0;
    window.__tnu_download_canceled = false;
    window.__tnu_user_aborted = false;

    window.addEventListener("message", (e) => {
        if (!e.data) return;
        if (e.data.type === "TNU_DOWNLOAD_COMPLETED") {
            const completedNow = Date.now();
            window.__tnu_download_completed_time = completedNow;
            window.__tnu_last_download_completed_time = completedNow;
            window.__tnu_last_download_id = e.data.downloadId;
            console.log("✔ [TNUE] Nhận tín hiệu TNU_DOWNLOAD_COMPLETED từ Background:", e.data.downloadId);
        } else if (e.data.type === "TNU_DOWNLOAD_INTERRUPTED") {
            console.log("⚠️ [TNUE] Nhận tín hiệu TNU_DOWNLOAD_INTERRUPTED từ Background (Người dùng bấm Cancel):", e.data.error);
            window.__tnu_download_canceled = true;
            window.__tnu_user_aborted = true;
            appendStepLog(`⚠️ [HỦY TẢI] Người dùng nhấn Cancel / hủy lưu tệp. Đang tự động đóng cửa sổ chi tiết văn bản...`);
            closeAllModalsAndPopups();
        }
    });

    document.addEventListener('click', (e) => {
        const closeBtn = e.target && e.target.closest(
            '.z-window-close, .z-window-modal-close, .z-window-icon, [id$="-close"], .fa-times, .fa-close, button[title*="đóng" i], button[title*="close" i]'
        );
        if (closeBtn) {
            const modal = closeBtn.closest('.z-window-modal, .z-window-highlighted, .z-window-overlapped, .z-window');
            if (modal && modal.id !== 'tnu-download-panel' && modal.id !== 'tnu-log-modal' && modal.id !== 'tnu-guide-modal') {
                console.log("🛑 [TNUE] Người dùng bấm nút đóng (X) trên cửa sổ chi tiết!");
                window.__tnu_user_aborted = true;
                window.__tnu_download_canceled = true;
                appendStepLog(`🛑 Người dùng bấm đóng (X) cửa sổ chi tiết văn bản.`);

                modal.style.removeProperty('pointer-events');
                modal.removeAttribute('aria-hidden');

                if (window.zk && window.zk.Widget) {
                    try {
                        const wgt = window.zk.Widget.$(modal);
                        if (wgt) {
                            if (window.zUtl && window.zUtl.sendEvent) {
                                window.zUtl.sendEvent(wgt, 'onClose');
                            } else if (wgt.fire) {
                                wgt.fire('onClose', {});
                            }
                        }
                    } catch(eWgt) {}
                }

                modal.style.display = 'none';

                document.querySelectorAll('.z-modal-mask, .z-window-modal-shadow').forEach(mask => {
                    mask.style.display = 'none';
                });

                if (window.__tnu_is_single_downloading) {
                    window.__tnu_is_single_downloading = false;
                    window.__tnu_single_download_start_time = 0;
                    const dBtn = document.querySelector('.tnu-hot-download-btn[data-downloading="true"]');
                    if (dBtn) {
                        dBtn.dataset.downloading = 'false';
                        dBtn.disabled = false;
                        dBtn.dataset.status = 'READY';
                        dBtn.innerHTML = '<span class="tnu-hot-icon">⚡</span> <span class="tnu-hot-text">Tải về</span>';
                        dBtn.style.background = '#16a34a';
                        dBtn.style.borderColor = '#15803d';
                        dBtn.style.color = '#ffffff';
                    }
                }
            }
        }
    }, false);

    if (window.__tnu_confirm_timer) clearInterval(window.__tnu_confirm_timer);
    window.__tnu_confirm_timer = setInterval(() => {
        if (window.__tnu_downloader && (window.__tnu_downloader.isRunning || window.__tnu_is_single_downloading)) {
            autoConfirmSecurityDialog();
        }
    }, 400);

    function setupMultiLayerDownloadCapture() {

        if (!window.__tnu_xhr_hooked) {
            const origXhrSend = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.send = function() {
                this.addEventListener('load', function() {
                    try {
                        let text = this.responseText;
                        if (text && typeof text === 'string') {
                            text = text.replace(/\\\//g, '/');

                            const cmdMatch = text.match(/\[\s*["']download["']\s*,\s*\[\s*["']([^"']+)["']/i);
                            if (cmdMatch && cmdMatch[1]) {
                                window.__tnu_captured_url = cmdMatch[1];
                                window.__tnu_captured_time = Date.now();
                                console.log("🎯 [TNUE] Bắt được link tải từ ZK AU Command:", cmdMatch[1]);
                            } else {
                                const m = text.match(/["'](\/[^"']*(?:zkau\/view|\.zip|\.rar|export|download|securityservlet)[^"']*)["']/i) ||
                                          text.match(/["'](https?:\/\/[^"']*(?:zkau\/view|\.zip|\.rar|export|download|securityservlet)[^"']*)["']/i);
                                if (m && m[1] && !m[1].toLowerCase().includes('viewer.html')) {
                                    window.__tnu_captured_url = m[1];
                                    window.__tnu_captured_time = Date.now();
                                    console.log("🎯 [TNUE] Bắt được link tải từ XHR AU regex:", m[1]);
                                }
                            }
                        }
                    } catch(e) {}
                });
                return origXhrSend.apply(this, arguments);
            };
            window.__tnu_xhr_hooked = true;
        }

        const hookZkDownloadFunction = (targetObject, functionName) => {
            if (targetObject && targetObject[functionName] && !targetObject[functionName]._tnu_hooked) {
                const orig = targetObject[functionName];
                targetObject[functionName] = function(url) {
                    if (url && typeof url === 'string') {
                        console.log(`🎯 [TNUE] Chặn ${functionName} và đón bắt link tải:`, url);
                        window.__tnu_captured_url = url;
                        window.__tnu_captured_time = Date.now();
                        return;
                    }
                    return orig.apply(this, arguments);
                };
                targetObject[functionName]._tnu_hooked = true;
            }
        };

        if (window.zk) hookZkDownloadFunction(window.zk, 'download');
        if (window.zUtl) hookZkDownloadFunction(window.zUtl, 'download');
        if (window.jq) hookZkDownloadFunction(window.jq, 'download');
        if (window.zAu) {
            if (window.zAu.cmd0) hookZkDownloadFunction(window.zAu.cmd0, 'download');
            if (window.zAu.cmd1) hookZkDownloadFunction(window.zAu.cmd1, 'download');
        }

        if (!window.__tnu_win_open_hooked) {
            const origWinOpen = window.open;
            window.open = function(url) {
                if (url && typeof url === 'string') {
                    const lower = url.toLowerCase();
                    if (!lower.includes('pdfvi') && !lower.includes('viewer.html')) {
                        if (lower.includes('.zip') || lower.includes('.rar') || lower.includes('zkau/view') || lower.includes('download')) {
                            console.log("🎯 [TNUE] Bắt và chặn window.open tải file:", url);
                            window.__tnu_captured_url = url;
                            window.__tnu_captured_time = Date.now();
                            return null;
                        }
                    }
                }
                return origWinOpen.apply(this, arguments);
            };
            window.__tnu_win_open_hooked = true;
        }

        if (!window.__tnu_iframe_hooked) {
            const isDownloadIframeUrl = (targetElement, targetUrl) => {
                if (!targetUrl || typeof targetUrl !== 'string') return false;
                const lowerVal = targetUrl.toLowerCase();

                if (lowerVal.includes('pdfvi') || lowerVal.includes('viewer.html')) return false;

                const id = (targetElement?.id || '').toLowerCase();
                const name = (targetElement?.name || '').toLowerCase();
                if (id === 'zk_download' || name === 'zk_download' || id.includes('download') || name.includes('download')) {
                    return true;
                }

                if (lowerVal.includes('zkau/view') || lowerVal.includes('.zip') || lowerVal.includes('.rar') || lowerVal.includes('export')) {
                    return true;
                }
                return false;
            };

            try {
                const origIframeSrc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src');
                if (origIframeSrc && origIframeSrc.set) {
                    Object.defineProperty(HTMLIFrameElement.prototype, 'src', {
                        set: function(val) {
                            if (isDownloadIframeUrl(this, val)) {
                                console.log("🎯 [TNUE] Bắt và triệt tiêu iframe.src tải file:", val);
                                window.__tnu_captured_url = val;
                                window.__tnu_captured_time = Date.now();
                                return origIframeSrc.set.call(this, 'about:blank');
                            }

                            if (typeof val === 'string' && (val.includes(':443/') || val.includes(':80/'))) {
                                val = val.replace(':443/', '/').replace(':80/', '/');
                            }
                            return origIframeSrc.set.call(this, val);
                        },
                        get: origIframeSrc.get,
                        configurable: true
                    });
                }

                const origSetAttribute = Element.prototype.setAttribute;
                Element.prototype.setAttribute = function(name, val) {
                    if (this instanceof HTMLIFrameElement && name.toLowerCase() === 'src') {
                        if (isDownloadIframeUrl(this, val)) {
                            console.log("🎯 [TNUE] Bắt và triệt tiêu iframe.setAttribute('src'):", val);
                            window.__tnu_captured_url = val;
                            window.__tnu_captured_time = Date.now();
                            return origSetAttribute.call(this, name, 'about:blank');
                        }
                        if (typeof val === 'string' && (val.includes(':443/') || val.includes(':80/'))) {
                            val = val.replace(':443/', '/').replace(':80/', '/');
                        }
                    }
                    return origSetAttribute.call(this, name, val);
                };
            } catch(e) {}
            window.__tnu_iframe_hooked = true;
        }

        try {
            if (!window.__tnu_observer_hooked && typeof MutationObserver !== 'undefined') {
                const ifrObserver = new MutationObserver((mutations) => {
                    for (const m of mutations) {
                        for (const node of m.addedNodes) {
                            if (node && node.nodeType === 1) {
                                const ifrs = node.tagName === 'IFRAME' ? [node] : Array.from(node.querySelectorAll('iframe'));
                                for (const ifr of ifrs) {
                                    const src = ifr.getAttribute('src') || ifr.src || '';
                                    if (src && (src.includes(':443/') || src.includes(':80/'))) {
                                        ifr.setAttribute('src', src.replace(':443/', '/').replace(':80/', '/'));
                                    }
                                    const id = (ifr.id || '').toLowerCase();
                                    const name = (ifr.name || '').toLowerCase();
                                    const lowerSrc = src.toLowerCase();
                                    if ((id === 'zk_download' || name === 'zk_download' || lowerSrc.includes('zkau/view') || lowerSrc.includes('.zip')) && !lowerSrc.includes('viewer.html')) {
                                        if (src && src !== 'about:blank') {
                                            console.log("🎯 [TNUE] MutationObserver bắt được iframe download:", src);
                                            window.__tnu_captured_url = src;
                                            window.__tnu_captured_time = Date.now();
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
                ifrObserver.observe(document.documentElement, { childList: true, subtree: true });
                window.__tnu_observer_hooked = true;
            }
        } catch(e) {}

        const oldIfrs = document.querySelectorAll('iframe#zk_download, iframe[name="zk_download"]');
        oldIfrs.forEach(ifr => {
            try {
                if (ifr.src && ifr.src !== 'about:blank') {
                    const l = ifr.src.toLowerCase();
                    if (!l.includes('pdfvi') && !l.includes('viewer.html')) {
                        window.__tnu_captured_url = ifr.src;
                        ifr.src = 'about:blank';
                    }
                }
                ifr.remove();
            } catch(e) {}
        });
    }
    setupMultiLayerDownloadCapture();

    function getLastProcessedPageFromLogs(filterYear = 'ALL', filterMonth = 'ALL') {
        if (!window.__tnu_logs || window.__tnu_logs.length === 0) return 1;
        const targetMonth = filterMonth !== 'ALL' ? parseInt(filterMonth, 10) : 0;

        for (let i = window.__tnu_logs.length - 1; i >= 0; i--) {
            const item = window.__tnu_logs[i];
            if (filterYear !== 'ALL' && item.nam && String(item.nam) !== String(filterYear)) {
                continue;
            }
            if (targetMonth > 0 && item.thang && parseInt(item.thang, 10) !== targetMonth) {
                continue;
            }
            const p = parseInt(item.trang, 10);
            if (!isNaN(p) && p >= 1) {
                return p;
            }
        }
        return 1;
    }

    function updateLastPageBadge() {
        const badge = document.getElementById('tnu-last-page-badge');
        if (!badge) return;
        const y = document.getElementById('tnu-year-select')?.value || 'ALL';
        const m = document.getElementById('tnu-month-select')?.value || 'ALL';
        const lastP = getLastProcessedPageFromLogs(y, m);
        if (lastP > 1) {
            badge.innerText = `(Dừng lần cuối: Trang ${lastP})`;
        } else {
            badge.innerText = '';
        }
    }

    function getTotalZkPages() {
        try {

            const pagingEls = document.querySelectorAll('.z-paging');
            for (const pel of pagingEls) {
                const w = window.zk?.Widget?.$(pel);
                if (w && typeof w.getPageCount === 'function') {
                    const cnt = w.getPageCount();
                    if (typeof cnt === 'number' && cnt > 0) return cnt;
                }
                if (w && typeof w._pageCount === 'number' && w._pageCount > 0) {
                    return w._pageCount;
                }
            }

            const pagingTexts = Array.from(document.querySelectorAll('.z-paging-text, .z-paging span, .z-paging label'));
            for (const pt of pagingTexts) {
                const txt = pt.innerText || '';
                const m = txt.match(/\/\s*(\d+)/);
                if (m) {
                    const total = parseInt(m[1], 10);
                    if (total > 0) return total;
                }
            }
        } catch (e) {}
        return 9999;
    }

    function normalizeForFuzzyCompare(str) {
        if (!str || typeof str !== 'string') return '';
        return str.toLowerCase()
            .replace(/\.pdf|\.zip/gi, '')
            .replace(/xem thêm|\.\.\./gi, '')
            .replace(/[_\-\/\.,;:!?'"“”‘’\(\)\[\]\{\}]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function isSameDocumentLog(docA, docB) {
        if (!docA || !docB) return false;

        if (docA.tenFile && docB.tenFile && docA.tenFile === docB.tenFile) return true;

        const skhA = (docA.soKyHieu || '').trim().toLowerCase();
        const skhB = (docB.soKyHieu || '').trim().toLowerCase();
        if (skhA && skhB) {
            if (skhA === skhB) return true;

            const numA = skhA.match(/^\d+/)?.[0];
            const numB = skhB.match(/^\d+/)?.[0];
            if (numA && numB && numA === numB) {

                if (docA.ngayBanHanh && docB.ngayBanHanh && docA.ngayBanHanh.trim() === docB.ngayBanHanh.trim()) {
                    return true;
                }

                const tyA = normalizeForFuzzyCompare(docA.trichYeu || '');
                const tyB = normalizeForFuzzyCompare(docB.trichYeu || '');
                if (tyA && tyB) {
                    if (tyA === tyB || tyA.includes(tyB) || tyB.includes(tyA)) return true;
                }
            }
        }

        const normA = normalizeForFuzzyCompare(docA.trichYeu || '');
        const normB = normalizeForFuzzyCompare(docB.trichYeu || '');
        if (normA && normB) {
            if (normA === normB) return true;

            if (normA.length >= 20 && normB.length >= 20 && (normA.includes(normB) || normB.includes(normA))) {
                return true;
            }
        }

        return false;
    }

    function findExistingLogIndex(logs, queryDoc) {
        if (!logs || !Array.isArray(logs) || logs.length === 0 || !queryDoc) return -1;
        return logs.findIndex(logItem => isSameDocumentLog(logItem, queryDoc));
    }

    function cleanDuplicateLogs(logs) {
        if (!logs || !Array.isArray(logs) || logs.length <= 1) return logs || [];
        const unique = [];
        for (const item of logs) {
            const idx = unique.findIndex(u => isSameDocumentLog(u, item));
            if (idx === -1) {
                unique.push({ ...item });
            } else {
                const existing = unique[idx];
                if (item.trangThai === 'THÀNH CÔNG') {
                    existing.trangThai = 'THÀNH CÔNG';
                    existing.lyDoLoi = '';
                    if (item.tenFile) existing.tenFile = item.tenFile;
                    if (item.loaiFile) existing.loaiFile = item.loaiFile;
                    if (parseFloat(item.dungLuongMb) > 0) existing.dungLuongMb = item.dungLuongMb;
                } else if (existing.trangThai !== 'THÀNH CÔNG' && item.trangThai === 'LỖI') {
                    existing.trangThai = 'LỖI';
                    existing.lyDoLoi = item.lyDoLoi || existing.lyDoLoi;
                }
                if (item.thoiGian) existing.thoiGian = item.thoiGian;
                if (item.trichYeu && item.trichYeu.length > (existing.trichYeu || '').length) {
                    existing.trichYeu = item.trichYeu;
                }
            }
        }
        return unique;
    }

    function getErrorDocsFromLogs() {
        if (!window.__tnu_logs || window.__tnu_logs.length === 0) return [];
        return window.__tnu_logs.filter(l => l.trangThai === 'LỖI');
    }

    function isDocumentAlreadySuccessInLogs(soKyHieu, trichYeu, titleFull, ngayBanHanh = "") {
        if (!window.__tnu_logs || window.__tnu_logs.length === 0) return false;
        const query = { soKyHieu, trichYeu, tenFile: `${titleFull}.pdf`, ngayBanHanh };
        return window.__tnu_logs.some(l => {
            if (l.trangThai !== 'THÀNH CÔNG') return false;
            return isSameDocumentLog(l, query);
        });
    }

    async function navigateToPageNumber(targetPage) {
        if (targetPage <= 1) return true;
        console.log(`[TNUE] 🚀 Đang tự động chuyển nhanh tới Trang ${targetPage}...`);
        setStatus(`🚀 Đang chuyển nhanh tới Trang ${targetPage}...`);

        const pagingInputs = Array.from(document.querySelectorAll('input.z-paging-input, input.z-paging-inp, .z-paging input[type="text"], input[class*="paging"]'));
        for (const input of pagingInputs) {
            try {
                input.focus();
                input.value = String(targetPage);
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
                input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
                input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
                await new Promise(r => setTimeout(r, 3500));
                return true;
            } catch(e) {}
        }

        for (let p = 1; p < targetPage; p++) {
            if (!window.__tnu_downloader.isRunning) break;
            const nextBtn = document.querySelector('button.z-paging-next');
            const isDisabled = nextBtn && (nextBtn.disabled || nextBtn.classList.contains('z-paging-btn-dis') || nextBtn.getAttribute('disabled') !== null);
            if (nextBtn && !isDisabled) {
                setStatus(`🚀 Đang chuyển trang: ${p + 1}/${targetPage}...`);
                triggerClick(nextBtn);
                await new Promise(r => setTimeout(r, 2500));
            } else {
                break;
            }
        }
        return true;
    }

    const sanitizeFileName = (rawName, maxLen = 225) => {
        const name = rawName;
        if (!name) return "Van_ban";
        let clean = name.replace(/[\r\n\t\v\f]+/g, ' ')
                        .replace(/[\\/:*?"<>|]/g, '_')
                        .replace(/[\u0000-\u001F\u007F-\u009F\u200B\uFEFF]/g, '')
                        .replace(/\s+/g, ' ')
                        .trim();

        if (clean.length > maxLen) {
            clean = clean.substring(0, maxLen);
        }
        clean = clean.replace(/[._ ]+$/, '').trim();

        const reservedNames = /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i;
        if (reservedNames.test(clean)) {
            clean = clean + "_doc";
        }
        return clean || "Van_ban";
    };

    function isLikelyOrganizationName(txt) {
        if (!txt || typeof txt !== 'string') return false;
        const s = txt.trim();
        if (!s) return false;

        const docPrefix = /^(quyết định|thông báo|kế hoạch|về việc|v\/v|công văn|báo cáo|tờ trình|hướng dẫn|nghị quyết|chỉ thị|biên bản|thông tri|quy định|quy chế|kết luận|chương trình|điều chỉnh|tổ chức|triển khai|chuyển kinh phí|ban hành|giao nhiệm vụ|phê duyệt)\b/i;
        if (docPrefix.test(s)) return false;

        if (/trường đại học,\s*cao đẳng/i.test(s)) return true;
        if (/(đại học thái nguyên|đại học sư phạm|đhsp)\s*$/i.test(s) && !/về việc|v\/v|quyết định|thông báo|kế hoạch/i.test(s)) return true;

        if (/^(phòng|khoa|bộ môn|trung tâm|viện|trường|đoàn|hội đồng|tổ chuyên môn|sở|ubnd|ban [a-zđà-ỹ]+)\b.*(-|–)/i.test(s)) return true;

        if (/^(phòng|khoa|bộ môn|trung tâm|viện|trường đại học)\b/i.test(s) && s.split(/\s+/).length <= 15) {
            if (!/\bvề\b|\bv\/v\b|[.,:;?]/.test(s)) return true;
        }

        return false;
    }

    function isPartyDocument(rowData) {
        if (!rowData) return false;
        const dv = (rowData.donViBanHanhRaw || '').trim().toLowerCase();
        const skh = (rowData.soKyHieuRaw || '').trim().toLowerCase();

        if (/\bđảng\b|\bđảng\s*u[ỷy]\b|\bvăn\s*phòng\s*đảng\b|\bbch\s*đảng\s*bộ\b|\bchi\s*bộ\b/i.test(dv)) {
            return true;
        }

        if (/[-\/](?:đu|đb|vpd[uư]|cb)(?:[-\/]|$)/i.test(skh)) {
            return true;
        }

        return false;
    }

    function getTableColumnMapping(row) {
        const listbox = row.closest('.z-listbox, .z-grid') ||
                        document.querySelector('.z-tabpanel:not([style*="display: none"]) .z-listbox') ||
                        document.querySelector('.z-listbox');

        let headerCells = [];
        if (listbox) {
            headerCells = Array.from(listbox.querySelectorAll('.z-listheader, th.z-column, th'));
        }
        if (headerCells.length === 0) {
            headerCells = Array.from(document.querySelectorAll('.z-tabpanel:not([style*="display: none"]) .z-listheader'));
        }
        if (headerCells.length === 0) {
            headerCells = Array.from(document.querySelectorAll('.z-listheader'));
        }

        const map = {
            sttCol: -1,
            soKyHieuCol: -1,
            soDenCol: -1,
            hasExactSoKyHieu: false,
            trichYeuCol: -1,
            ngayBanHanhCol: -1,
            donViBanHanhCol: -1,
            dinhKemCol: -1
        };

        headerCells.forEach((th, idx) => {
            const hText = ((th.innerText || '') + ' ' + (th.getAttribute('title') || '') + ' ' + (th.getAttribute('aria-label') || ''))
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();
            if (/^(stt|số\s*tt|tt)$/i.test(hText)) {
                map.sttCol = idx;
            } else if (hText.includes('số/ký hiệu') || hText.includes('số ký hiệu') || hText.includes('số hiệu') ||
                       hText.includes('số kh') || hText.includes('số văn bản') || hText.includes('số vb') ||
                       hText.includes('số và ký hiệu')) {

                map.soKyHieuCol = idx;
                map.hasExactSoKyHieu = true;
            } else if (!map.hasExactSoKyHieu && (hText.includes('số đi') || hText.includes('số đến'))) {
                map.soDenCol = idx;
                if (map.soKyHieuCol === -1) map.soKyHieuCol = idx;
            } else if (/đơn\s*vị|cơ\s*quan|nơi\s*gửi|nơi\s*nhận|đơn\s*vị\s*gửi|cơ\s*quan\s*gửi|đơn\s*vị\s*ban\s*hành|cơ\s*quan\s*ban\s*hành|đơn\s*vị\s*soạn\s*thảo|cơ\s*quan\s*phát\s*hành|phòng\s*ban/i.test(hText)) {
                if (map.donViBanHanhCol === -1) map.donViBanHanhCol = idx;
            } else if (/trích\s*yếu|tên\s*văn\s*bản|tên\s*tài\s*liệu|chủ\s*đề/i.test(hText) ||
                       (hText.includes('nội dung') && !hText.includes('đơn vị') && !hText.includes('cơ quan')) ||
                       hText.startsWith('trích')) {
                if (map.trichYeuCol === -1) map.trichYeuCol = idx;
            } else if (hText.includes('ngày ban hành') || hText.includes('ngày vb') || hText.includes('ngày ký') || hText.includes('ngày văn bản') ||
                       hText.includes('ngày đến') || hText.includes('ngày gửi') || hText.includes('ngày nhận')) {
                if (map.ngayBanHanhCol === -1) map.ngayBanHanhCol = idx;
            } else if (hText.includes('đính kèm') || hText.includes('tệp') || hText.includes('file') ||
                       hText.includes('tài liệu') || hText.includes('tải về') || hText.includes('download')) {
                if (map.dinhKemCol === -1) map.dinhKemCol = idx;
            }
        });

        return map;
    }

    function extractRowDataSmart(row, pageIndex, rowIndex) {
        const cells = Array.from(row.querySelectorAll('.z-listcell, .z-row-inner, .z-cell, td'));
        if (cells.length === 0) return null;

        const colMap = getTableColumnMapping(row);

        let soKyHieuRaw = "";
        let trichYeuRaw = "";
        let ngayBanHanhFull = "";
        let donViBanHanhRaw = "";
        let docMonth = 0;
        let docYear = "";
        let sttDoc = "";

        if (colMap.soKyHieuCol >= 0 && colMap.soKyHieuCol < cells.length) {
            soKyHieuRaw = cells[colMap.soKyHieuCol]?.innerText?.trim() || "";
        }

        if (!soKyHieuRaw || /^\d+$/.test(soKyHieuRaw) || soKyHieuRaw === trichYeuRaw) {
            for (let c = 0; c < cells.length; c++) {
                if (c === colMap.sttCol || c === colMap.donViBanHanhCol || c === colMap.ngayBanHanhCol) continue;
                const txt = cells[c]?.innerText?.trim() || "";
                if (!txt || txt === trichYeuRaw || txt === ngayBanHanhFull) continue;
                if (/\b\d+[\/\-][A-ZĐa-zđ0-9\/\-]+\b/.test(txt) && txt.length <= 60) {
                    soKyHieuRaw = txt;
                    break;
                }
            }
        }
        if (colMap.trichYeuCol >= 0 && colMap.trichYeuCol < cells.length) {
            const candidateTrichYeu = cells[colMap.trichYeuCol]?.innerText?.trim() || "";
            if (!isLikelyOrganizationName(candidateTrichYeu)) {
                trichYeuRaw = candidateTrichYeu;
            }
        }
        if (colMap.ngayBanHanhCol >= 0 && colMap.ngayBanHanhCol < cells.length) {
            const rawDate = cells[colMap.ngayBanHanhCol]?.innerText?.trim() || "";
            const m = rawDate.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
            if (m) {
                ngayBanHanhFull = m[0];
                docMonth = parseInt(m[2], 10);
                docYear = m[3];
            }
        }
        if (colMap.donViBanHanhCol >= 0 && colMap.donViBanHanhCol < cells.length) {
            donViBanHanhRaw = cells[colMap.donViBanHanhCol]?.innerText?.trim() || "";
        }
        if (colMap.sttCol >= 0 && colMap.sttCol < cells.length) {
            sttDoc = cells[colMap.sttCol]?.innerText?.trim() || "";
        }

        if (!donViBanHanhRaw) {
            for (let c = 0; c < cells.length; c++) {
                if (c === colMap.sttCol || c === colMap.soKyHieuCol || c === colMap.ngayBanHanhCol || c === colMap.dinhKemCol) continue;
                const txt = cells[c]?.innerText?.trim() || "";
                if (txt && isLikelyOrganizationName(txt)) {
                    donViBanHanhRaw = txt;
                    break;
                }
            }
        }

        if (!ngayBanHanhFull) {
            for (let c = cells.length - 1; c >= 0; c--) {
                const txt = cells[c]?.innerText?.trim() || "";
                const m = txt.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
                if (m) {
                    ngayBanHanhFull = m[0];
                    docMonth = parseInt(m[2], 10);
                    docYear = m[3];
                    break;
                }
            }
        }

        if (!trichYeuRaw || trichYeuRaw.length < 5 || isLikelyOrganizationName(trichYeuRaw)) {
            let maxLen = 0;
            let bestTrichYeuIdx = -1;
            for (let c = 0; c < cells.length; c++) {
                if (c === colMap.donViBanHanhCol || c === colMap.soKyHieuCol || c === colMap.sttCol || c === colMap.ngayBanHanhCol || c === colMap.dinhKemCol) {
                    continue;
                }
                const txt = cells[c]?.innerText?.trim() || "";
                if (!txt || /^\d+$/.test(txt) || /^\d{1,2}\/\d{1,2}\/\d{4}$/.test(txt)) continue;
                if (isLikelyOrganizationName(txt)) continue;
                if (txt.length > maxLen) {
                    maxLen = txt.length;
                    bestTrichYeuIdx = c;
                }
            }
            if (bestTrichYeuIdx >= 0) {
                trichYeuRaw = cells[bestTrichYeuIdx]?.innerText?.trim() || "";
            }
        }

        if (!trichYeuRaw || trichYeuRaw.length < 5 || isLikelyOrganizationName(trichYeuRaw)) {
            for (let c = 0; c < cells.length; c++) {
                if (c === colMap.donViBanHanhCol || c === colMap.soKyHieuCol || c === colMap.sttCol || c === colMap.ngayBanHanhCol || c === colMap.dinhKemCol) {
                    continue;
                }
                const link = cells[c]?.querySelector('a, .z-a, [title]');
                if (link) {
                    const lText = (link.getAttribute('title') || link.innerText || '').trim();
                    if (lText && lText.length > 5 && !isLikelyOrganizationName(lText)) {
                        trichYeuRaw = lText;
                        break;
                    }
                }
            }
        }

        if (!soKyHieuRaw || soKyHieuRaw === trichYeuRaw) {
            for (let c = 0; c < cells.length; c++) {
                const txt = cells[c]?.innerText?.trim() || "";
                if (!txt || txt === trichYeuRaw || txt === ngayBanHanhFull) continue;
                if (/\d+[\/\-][A-ZĐa-zđ0-9\/\-]+/.test(txt) && txt.length <= 60) {
                    soKyHieuRaw = txt;
                    break;
                }
            }
            if (!soKyHieuRaw || soKyHieuRaw === trichYeuRaw) {
                for (const tryIdx of [5, 2, 3, 4, 1]) {
                    if (tryIdx < cells.length) {
                        const txt = cells[tryIdx]?.innerText?.trim() || "";
                        if (txt && txt !== trichYeuRaw && !/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(txt) && txt.length < 50) {
                            soKyHieuRaw = txt;
                            break;
                        }
                    }
                }
            }
        }

        if (!sttDoc || !/^\d+$/.test(sttDoc)) {
            sttDoc = cells[0]?.innerText?.trim() || cells[1]?.innerText?.trim() || cells[2]?.innerText?.trim() || String(rowIndex);
            if (!/^\d+$/.test(sttDoc)) sttDoc = String(rowIndex);
        }

        let trichYeuCell = (colMap.trichYeuCol >= 0 && colMap.trichYeuCol < cells.length) ? cells[colMap.trichYeuCol] : null;
        if (!trichYeuCell) {
            trichYeuCell = cells.find(c => (c.innerText || '').trim() === trichYeuRaw) || cells[6] || cells[5] || cells[2] || cells[0];
        }

        if (trichYeuCell) {
            const fullTitle = trichYeuCell.getAttribute('title') ||
                              trichYeuCell.querySelector('[title]')?.getAttribute('title');
            if (fullTitle && fullTitle.trim().length > trichYeuRaw.length && !isLikelyOrganizationName(fullTitle)) {
                trichYeuRaw = fullTitle.trim();
            }
        }

        trichYeuRaw = (trichYeuRaw || '').replace(/[\r\n\t]+/g, ' ').trim();
        trichYeuRaw = trichYeuRaw.replace(/[\s\-_.]*(?:xem\s+thêm|xem\s+them|\.\.\.)\s*$/i, '').trim();

        trichYeuRaw = trichYeuRaw.replace(/\.(pdf|docx?|xlsx?|pptx?|zip|rar)\s*$/i, '').trim();

        if (!trichYeuRaw) {
            trichYeuRaw = `Van_ban_trang${pageIndex}_dong${rowIndex}`;
        }
        if (!trichYeuCell) {
            trichYeuCell = cells.find(c => (c.innerText || '').trim() === trichYeuRaw) || cells[6] || cells[5] || cells[2] || cells[0];
        }

        return {
            sttDoc,
            soKyHieuRaw,
            trichYeuRaw,
            ngayBanHanhFull,
            donViBanHanhRaw,
            docMonth,
            docYear,
            trichYeuCell,
            cells
        };
    }

    function buildWindowsSafeFilename(soKyHieuRaw, trichYeuRaw, ngayBanHanhRaw = '', pageIndex = 1, rowIndex = 1) {
        if (typeof ngayBanHanhRaw === 'number') {
            rowIndex = pageIndex || 1;
            pageIndex = ngayBanHanhRaw || 1;
            ngayBanHanhRaw = '';
        }
        const parts = [];
        const cleanSoKyHieu = sanitizeFileName((soKyHieuRaw || '').replace(/[\\/:*?"<>|]/g, '-'), 80);
        if (cleanSoKyHieu && cleanSoKyHieu !== 'Van_ban') parts.push(cleanSoKyHieu);

        const cleanNgay = sanitizeFileName((ngayBanHanhRaw || '').replace(/[\\/:*?"<>|]/g, '-'), 20);
        if (cleanNgay && cleanNgay !== 'Van_ban') parts.push(cleanNgay);

        const cleanTrichYeu = sanitizeFileName((trichYeuRaw || `Van_ban_trang${pageIndex}_dong${rowIndex}`).replace(/[\\/:*?"<>|]/g, '-'), 140);
        if (cleanTrichYeu && cleanTrichYeu !== 'Van_ban') parts.push(cleanTrichYeu);

        let fullName = parts.join('_').replace(/_{2,}/g, '_').replace(/^_+|_+$/g, '');
        if (!fullName) fullName = `Van_ban_trang${pageIndex}_dong${rowIndex}`;
        if (fullName.length > 220) {
            fullName = fullName.substring(0, 220).replace(/[._ ]+$/, '').trim();
        }
        return fullName;
    }

    const saveTextToDirectory = async (dirHandle, filename, textContent) => {
        try {
            const fileHandle = await dirHandle.getFileHandle(filename, { create: true });
            const writable = await fileHandle.createWritable();
            await writable.write(textContent);
            await writable.close();
            return true;
        } catch (e) {
            console.warn(`Lỗi ghi file ${filename} vào thư mục:`, e);
            return false;
        }
    };

    async function saveAllLogsToDirectory() {
        if (!window.__tnu_dir_handle || !window.__tnu_logs) return;
        try {
            const jsonContent = JSON.stringify(window.__tnu_logs || [], null, 2);
            await saveTextToDirectory(window.__tnu_dir_handle, "log_download_tnu.json", jsonContent);
        } catch (e) {
            console.warn("Lỗi đồng bộ nhật ký JSON ra thư mục:", e);
        }
    }

    async function recordDocLog({
        stt = "",
        trang = 1,
        soKyHieu = "",
        trichYeu = "",
        ngayBanHanh = "",
        nam = "",
        thang = 0,
        loaiFile = "PDF",
        tenFile = "",
        dungLuongMb = 0,
        trangThai = "THÀNH CÔNG",
        lyDoLoi = ""
    }) {
        const now = new Date();
        const timeStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

        const existingIdx = findExistingLogIndex(window.__tnu_logs, {
            tenFile,
            soKyHieu,
            trichYeu,
            ngayBanHanh,
            nam
        });

        if (existingIdx >= 0) {
            const oldRecord = window.__tnu_logs[existingIdx];
            const preservedId = oldRecord.id;
            const preservedStt = oldRecord.stt || stt;

            let bestSoKyHieu = soKyHieu;
            if (oldRecord.soKyHieu && (oldRecord.soKyHieu.includes('/') || oldRecord.soKyHieu.includes('-')) && (!soKyHieu || (!soKyHieu.includes('/') && !soKyHieu.includes('-')))) {
                bestSoKyHieu = oldRecord.soKyHieu;
            } else if (soKyHieu && (soKyHieu.includes('/') || soKyHieu.includes('-'))) {
                bestSoKyHieu = soKyHieu;
            }

            let bestTrichYeu = trichYeu;
            if (oldRecord.trichYeu && oldRecord.trichYeu.length > (trichYeu || '').length && !oldRecord.trichYeu.endsWith('.pdf')) {
                bestTrichYeu = oldRecord.trichYeu;
            }

            let nextStatus = trangThai || oldRecord.trangThai;
            let nextLyDo = lyDoLoi !== undefined ? lyDoLoi : (oldRecord.lyDoLoi || "");
            if (oldRecord.trangThai === 'THÀNH CÔNG' && nextStatus === 'BỎ QUA') {
                nextStatus = 'THÀNH CÔNG';
                nextLyDo = "";
            } else if (nextStatus === 'THÀNH CÔNG') {
                nextLyDo = "";
            }

            window.__tnu_logs[existingIdx] = {
                id: preservedId,
                stt: preservedStt,
                trang: trang || oldRecord.trang,
                soKyHieu: bestSoKyHieu,
                trichYeu: bestTrichYeu,
                ngayBanHanh: ngayBanHanh || oldRecord.ngayBanHanh,
                nam: nam || oldRecord.nam,
                thang: thang || oldRecord.thang,
                loaiFile: loaiFile || oldRecord.loaiFile,
                tenFile: tenFile || oldRecord.tenFile,
                dungLuongMb: parseFloat(dungLuongMb) > 0 ? parseFloat(dungLuongMb) : (oldRecord.dungLuongMb || 0),
                trangThai: nextStatus,
                lyDoLoi: nextLyDo,
                thoiGian: timeStr
            };
            console.log(`[TNUE] 🔄 Đã cập nhật trạng thái bản ghi ID ${preservedId} ("${bestSoKyHieu}") thành "${nextStatus}".`);
        } else {
            const newRecord = {
                id: window.__tnu_logs.length + 1,
                stt: stt || String(window.__tnu_logs.length + 1),
                trang: trang,
                soKyHieu: soKyHieu,
                trichYeu: trichYeu,
                ngayBanHanh: ngayBanHanh,
                nam: nam,
                thang: thang,
                loaiFile: loaiFile,
                tenFile: tenFile,
                dungLuongMb: parseFloat(dungLuongMb) || 0,
                trangThai: trangThai,
                lyDoLoi: lyDoLoi || "",
                thoiGian: timeStr
            };
            window.__tnu_logs.push(newRecord);
        }

        try {
            localStorage.setItem('tnu_download_logs', JSON.stringify(window.__tnu_logs));
        } catch(e) {}

        updateCounts();
        renderLogTable();

        if (window.__tnu_dir_handle) {
            await saveAllLogsToDirectory();
        }
    }

    function downloadBlobDirectly(content, filename, mimeType) {
        const safeMime = (filename && filename.toLowerCase().endsWith('.pdf')) ? 'application/pdf' : (mimeType || 'application/octet-stream');
        let blob;
        if (content && typeof content.size === 'number') {
            blob = (content.type === safeMime) ? content : new Blob([content], { type: safeMime });
        } else {
            blob = new Blob([content], { type: safeMime });
        }
        const cleanFilename = filename.replace(/\.txt$/i, '');
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = cleanFilename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            a.remove();
            URL.revokeObjectURL(url);
        }, 15000);
    }

    async function blobToDataUrl(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    async function sendDownloadRequestToBridge(filename, blob, directUrl = null) {
        return new Promise(async (resolve) => {
            try {
                const reqId = "dl_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7);
                let dataUrl = null;
                if (blob) {
                    dataUrl = await blobToDataUrl(blob);
                }

                const onResp = (event) => {
                    if (event.data && event.data.type === "TNU_DOWNLOAD_RESPONSE" && event.data.id === reqId) {
                        window.removeEventListener("message", onResp);
                        resolve(event.data);
                    }
                };
                window.addEventListener("message", onResp);

                window.postMessage({
                    type: "TNU_DOWNLOAD_REQUEST",
                    id: reqId,
                    dataUrl: dataUrl,
                    url: directUrl,
                    filename: filename
                }, "*");

                setTimeout(() => {
                    window.removeEventListener("message", onResp);
                    resolve({ success: false, error: "Bridge timeout" });
                }, 20000);
            } catch(e) {
                resolve({ success: false, error: e.message });
            }
        });
    }

    async function saveFileDirectlyOrBridge(filename, blob, directUrl = null) {
        let finalBlob = blob;

        if (finalBlob && typeof finalBlob.size === 'number' && finalBlob.size > 1000) {

            if (window.__tnu_dir_handle) {
                try {
                    await saveBlobToDirectory(window.__tnu_dir_handle, filename, finalBlob);
                    window.__tnu_fs_saved_time = Date.now();
                    window.__tnu_fs_saved_filename = filename;
                    return { success: true, method: "fs", sizeMb: (finalBlob.size / (1024 * 1024)).toFixed(2) };
                } catch(err) {
                    console.warn("[TNUE] Ghi vào thư mục handle thất bại, chuyển sang phương thức dự phòng:", err);
                }
            }

            try {
                const bridgeRes = await sendDownloadRequestToBridge(`TNUE_Vanban/${filename}`, finalBlob, null);
                if (bridgeRes && bridgeRes.success) {
                    return { success: true, method: "extension_blob", sizeMb: (finalBlob.size / (1024 * 1024)).toFixed(2) };
                }
            } catch(e) {}

            try {
                downloadBlobDirectly(finalBlob, filename, finalBlob.type || 'application/pdf');
                return { success: true, method: "direct_blob", sizeMb: (finalBlob.size / (1024 * 1024)).toFixed(2) };
            } catch(e) {}
        }

        if (directUrl) {
            const cleanUrl = normalizeVofficeUrl(directUrl);

            if (window.__tnu_dir_handle) {
                try {
                    const fetchedBlob = await fetchPdfWithMultiFallback(cleanUrl);
                    if (fetchedBlob && typeof fetchedBlob.size === 'number' && fetchedBlob.size > 1000) {
                        await saveBlobToDirectory(window.__tnu_dir_handle, filename, fetchedBlob);
                        window.__tnu_fs_saved_time = Date.now();
                        window.__tnu_fs_saved_filename = filename;
                        return { success: true, method: "fs", sizeMb: (fetchedBlob.size / (1024 * 1024)).toFixed(2) };
                    }
                } catch(e) {}
            }

            const isViewerUrl = /([?&])task=view\b/i.test(cleanUrl) || cleanUrl.includes('viewer.html');

            if (!isViewerUrl) {
                console.log("🚀 [TNUE] Chuyển tiếp link tải trực tiếp hợp lệ tới Extension Bridge:", cleanUrl);
                try {
                    const bridgeRes = await sendDownloadRequestToBridge(`TNUE_Vanban/${filename}`, null, cleanUrl);
                    if (bridgeRes && bridgeRes.success) {
                        return { success: true, method: "extension_url", sizeMb: "1.00" };
                    }
                } catch(e) {}
            } else {

                try {
                    const fetchedBlob = await fetchPdfWithMultiFallback(cleanUrl);
                    if (fetchedBlob && typeof fetchedBlob.size === 'number' && fetchedBlob.size > 1000) {
                        return await saveFileDirectlyOrBridge(filename, fetchedBlob, null);
                    }
                } catch(e) {}
            }
        }

        return { success: false, error: "Không thể lấy dữ liệu Blob hoặc URL tải hợp lệ" };
    }

    const closePdfViewerWindow = async () => {
        const iframes = Array.from(document.querySelectorAll('iframe')).filter(f => {
            const src = (f.getAttribute('src') || f.src || '').toLowerCase();
            return src.includes('pdfvi') || src.includes('viewer.html') || src.includes('securityservlet');
        });

        for (const ifr of iframes) {
            const winModal = ifr.closest('.z-window-modal, .z-window-highlighted, .z-window');
            if (winModal) {
                const closeBtn = winModal.querySelector('.z-window-modal-close, .z-window-close, .z-window-icon, [id$="-close"]');
                if (closeBtn) triggerClick(closeBtn);
                else winModal.remove();
            } else {
                ifr.remove();
            }
        }
        await new Promise(r => setTimeout(r, 600));
    };

    function normalizeAttachmentFilename(text) {
        if (!text) return null;
        let clean = text.trim();

        clean = clean.replace(/^(bản\s+(?:scan|chụp|gốc|chính|sao)\s+|xem\s+(?:trước\s+)?(?:file\s+|tệp\s+)?|tải\s+(?:về\s+|tệp\s+|file\s+|xuống\s+)?|tệp\s+(?:đính\s+kèm\s*:\s*|tin\s*:\s*)?|file\s*:\s*|tên\s+(?:file|tệp)\s*:\s*)/i, '').trim();
        if (clean.includes(':')) {
            const parts = clean.split(':');
            clean = parts[parts.length - 1].trim();
        }

        clean = clean.replace(/\s*[\(\[].*?[\)\]]\s*$/, '').trim();

        const m = clean.match(/([^\/:*?"<>|\r\n\t\s]+?\.(pdf|docx?|xlsx?|pptx?|zip|rar))\b/i) ||
                  clean.match(/([^\/:*?"<>|\r\n\t]+?\.(pdf|docx?|xlsx?|pptx?|zip|rar))\b/i);
        if (!m) return null;
        let fname = m[1].trim();
        fname = fname.replace(/[._ ]+$/, '').trim();
        return fname || null;
    }

    function normalizeVofficeUrl(url) {
        if (!url || typeof url !== 'string') return "";
        try {
            let u = url.trim();
            u = u.replace(':443/', '/').replace(':80/', '/');
            const origin = (typeof window !== 'undefined' && window.location?.origin) ? window.location.origin : "https://vanban.tnu.edu.vn";
            if (u.startsWith('http://') || u.startsWith('https://')) {
                const parsed = new URL(u);
                return origin + parsed.pathname + parsed.search + parsed.hash;
            }
            if (!u.startsWith('/')) {
                u = '/' + u;
            }
            return origin + u;
        } catch(e) {
            return url;
        }
    }

    function extractFileUrlFromIframeSrc(iframeSrc) {
        if (!iframeSrc || typeof iframeSrc !== 'string') return "";
        let src = iframeSrc.trim();
        if (src === 'about:blank' || src === 'about:srcdoc') return "";
        src = src.replace(':443/', '/').replace(':80/', '/');

        const fileIdx = src.indexOf('file=');
        if (fileIdx !== -1) {
            let filePart = src.substring(fileIdx + 5);
            const hashIdx = filePart.indexOf('#');
            if (hashIdx !== -1) filePart = filePart.substring(0, hashIdx);

            if (/%[0-9a-fA-F]{2}/.test(filePart)) {
                try {

                    const safePart = filePart.replace(/%2b/gi, '__PLUS__');
                    const decoded = decodeURIComponent(safePart).replace(/__PLUS__/g, '%2B');
                    return normalizeVofficeUrl(decoded);
                } catch(e) {
                    return normalizeVofficeUrl(filePart);
                }
            }
            return normalizeVofficeUrl(filePart);
        }

        if (src.includes('SecurityServlet') || src.includes('.pdf') || src.includes('zkau/view')) {
            return normalizeVofficeUrl(src);
        }

        return normalizeVofficeUrl(src);
    }

    function xhrFetchBlob(url) {
        return new Promise((resolve) => {
            try {
                const xhr = new XMLHttpRequest();
                xhr.open('GET', url, true);
                xhr.withCredentials = true;
                xhr.responseType = 'blob';
                xhr.timeout = 30000;
                xhr.setRequestHeader('Accept', 'application/pdf, application/octet-stream, */*');
                xhr.onload = function() {
                    if (xhr.status >= 200 && xhr.status < 300 && xhr.response && xhr.response.size > 1000) {
                        resolve(xhr.response);
                    } else {
                        resolve(null);
                    }
                };
                xhr.onerror = () => resolve(null);
                xhr.ontimeout = () => resolve(null);
                xhr.send();
            } catch(e) {
                resolve(null);
            }
        });
    }

    async function fetchPdfWithMultiFallback(rawFileUrl, win = null) {
        if (!rawFileUrl) return null;

        const cleanUrl = normalizeVofficeUrl(rawFileUrl);

        const formatUrlQueryWithPlus = (originalUrl) => {
            if (!originalUrl || !originalUrl.includes('?')) return originalUrl;
            const [base, qs] = originalUrl.split('?');
            const safeQs = qs.split('&').map(param => {
                const eqIdx = param.indexOf('=');
                if (eqIdx === -1) return param;
                const k = param.substring(0, eqIdx);
                const v = param.substring(eqIdx + 1);
                return k + '=' + v.replace(/\+/g, '%2B');
            }).join('&');
            return base + '?' + safeQs;
        };

        const candidates = [
            cleanUrl,
            formatUrlQueryWithPlus(cleanUrl)
        ];
        const uniqueUrls = Array.from(new Set(candidates.filter(Boolean)));

        for (const u of uniqueUrls) {

            if (win && typeof win.fetch === 'function') {
                try {
                    const controller = new AbortController();
                    const timer = setTimeout(() => controller.abort(), 30000);
                    const res = await win.fetch(u, {
                        credentials: 'include',
                        signal: controller.signal,
                        headers: { 'Accept': 'application/pdf, application/octet-stream, */*' }
                    });
                    clearTimeout(timer);
                    if (res && res.ok) {
                        const blob = await res.blob();
                        if (blob && typeof blob.size === 'number' && blob.size > 1000) {
                            console.log(`✔ [TNUE] Fetch thành công từ iframe context (${blob.size} bytes):`, u);
                            return blob;
                        }
                    }
                } catch(e) {}
            }

            try {
                const controller = new AbortController();
                const timer = setTimeout(() => controller.abort(), 30000);
                const res = await fetch(u, {
                    credentials: 'include',
                    signal: controller.signal,
                    headers: { 'Accept': 'application/pdf, application/octet-stream, */*' }
                });
                clearTimeout(timer);
                if (res && res.ok) {
                    const blob = await res.blob();
                    if (blob && typeof blob.size === 'number' && blob.size > 1000) {
                        console.log(`✔ [TNUE] Fetch thành công từ main window (${blob.size} bytes):`, u);
                        return blob;
                    }
                }
            } catch(e) {}

            const xhrBlob = await xhrFetchBlob(u);
            if (xhrBlob && xhrBlob.size > 1000) {
                console.log(`✔ [TNUE] XHR tải thành công (${xhrBlob.size} bytes):`, u);
                return xhrBlob;
            }
        }
        return null;
    }

    const fetchDirectFile = async (url) => {
        try {
            if (!url) return null;
            return await fetchPdfWithMultiFallback(url);
        } catch(e) {
            console.warn("[TNUE] fetchDirectFile lỗi:", e);
        }
        return null;
    };

    const fetchPdfFromUrl = async (urlOrIframeSrc, win = null) => {
        try {
            if (!urlOrIframeSrc) return null;
            const targetUrl = extractFileUrlFromIframeSrc(urlOrIframeSrc) || urlOrIframeSrc;
            return await fetchPdfWithMultiFallback(targetUrl, win);
        } catch(e) {}
        return null;
    };

    async function decompressZipEntry(buffer, view, entry) {
        try {
            const localOffset = entry.localHeaderOffset;
            if (view.getUint32(localOffset, true) !== 0x04034b50) return null;
            const localFnLen = view.getUint16(localOffset + 26, true);
            const localExtraLen = view.getUint16(localOffset + 28, true);
            const dataStart = localOffset + 30 + localFnLen + localExtraLen;
            const compBytes = new Uint8Array(buffer, dataStart, entry.compSize);

            if (entry.method === 0) {
                return new Blob([compBytes], { type: 'application/pdf' });
            } else if (entry.method === 8) {

                try {
                    if (typeof DecompressionStream !== 'undefined') {
                        const ds = new DecompressionStream('deflate-raw');
                        const stream = new Response(compBytes).body.pipeThrough(ds);
                        const decompressedBuffer = await new Response(stream).arrayBuffer();
                        if (decompressedBuffer && decompressedBuffer.byteLength > 1000) {
                            return new Blob([decompressedBuffer], { type: 'application/pdf' });
                        }
                    }
                } catch(eRaw) {}

                try {
                    if (typeof DecompressionStream !== 'undefined') {
                        const ds = new DecompressionStream('deflate');
                        const stream = new Response(compBytes).body.pipeThrough(ds);
                        const decompressedBuffer = await new Response(stream).arrayBuffer();
                        if (decompressedBuffer && decompressedBuffer.byteLength > 1000) {
                            return new Blob([decompressedBuffer], { type: 'application/pdf' });
                        }
                    }
                } catch(eZlib) {}
            }
        } catch(e) {
            console.warn("[TNUE] decompressZipEntry lỗi:", e);
        }
        return null;
    }

    async function fallbackLocalHeaderExtract(buffer, view) {
        let offset = 0;
        while (offset < buffer.byteLength - 30) {
            const sig = view.getUint32(offset, true);
            if (sig !== 0x04034b50) break;
            const method = view.getUint16(offset + 8, true);
            const compSize = view.getUint32(offset + 18, true);
            const fnLen = view.getUint16(offset + 26, true);
            const extraLen = view.getUint16(offset + 28, true);

            const fnBytes = new Uint8Array(buffer, offset + 30, fnLen);
            const filename = new TextDecoder('utf-8').decode(fnBytes);
            const dataOffset = offset + 30 + fnLen + extraLen;
            const compBytes = new Uint8Array(buffer, dataOffset, compSize);

            if (filename.toLowerCase().endsWith('.pdf') && compBytes.length > 0) {
                if (method === 0) {
                    return { isSinglePdf: true, pdfBlob: new Blob([compBytes], { type: 'application/pdf' }), count: 1, filename };
                } else if (method === 8 && typeof DecompressionStream !== 'undefined') {
                    const ds = new DecompressionStream('deflate-raw');
                    const stream = new Response(compBytes).body.pipeThrough(ds);
                    const decompressedBuffer = await new Response(stream).arrayBuffer();
                    return { isSinglePdf: true, pdfBlob: new Blob([decompressedBuffer], { type: 'application/pdf' }), count: 1, filename };
                }
            }
            if (compSize === 0) break;
            offset = dataOffset + compSize;
        }
        return { isSinglePdf: false, pdfBlob: null, count: 0, entries: [] };
    }

    async function inspectAndExtractZip(zipBlob) {
        if (!zipBlob || typeof zipBlob.size !== 'number' || zipBlob.size < 22) {
            return { isSinglePdf: false, pdfBlob: null, count: 0, entries: [] };
        }
        try {
            const buffer = await zipBlob.arrayBuffer();
            const view = new DataView(buffer);
            const len = buffer.byteLength;

            let eocd = -1;
            for (let i = len - 22; i >= Math.max(0, len - 65557); i--) {
                if (view.getUint32(i, true) === 0x06054b50) {
                    eocd = i;
                    break;
                }
            }
            if (eocd === -1) {
                return await fallbackLocalHeaderExtract(buffer, view);
            }

            const totalEntries = view.getUint16(eocd + 10, true);
            const cdOffset = view.getUint32(eocd + 16, true);
            let offset = cdOffset;
            const entries = [];

            for (let i = 0; i < totalEntries && offset < len - 46; i++) {
                if (view.getUint32(offset, true) !== 0x02014b50) break;
                const method = view.getUint16(offset + 10, true);
                const compSize = view.getUint32(offset + 20, true);
                const uncompSize = view.getUint32(offset + 24, true);
                const fnLen = view.getUint16(offset + 28, true);
                const extraLen = view.getUint16(offset + 30, true);
                const commentLen = view.getUint16(offset + 32, true);
                const localHeaderOffset = view.getUint32(offset + 42, true);

                const fnBytes = new Uint8Array(buffer, offset + 46, fnLen);
                const filename = new TextDecoder('utf-8').decode(fnBytes);

                const isDirectory = filename.endsWith('/') || filename.endsWith('\\');
                if (!isDirectory) {
                    entries.push({
                        filename,
                        isPdf: filename.toLowerCase().endsWith('.pdf'),
                        method,
                        compSize,
                        uncompSize,
                        localHeaderOffset
                    });
                }

                offset += 46 + fnLen + extraLen + commentLen;
            }

            const pdfEntries = entries.filter(e => e.isPdf);

            const METADATA_EXT = /\.(xml|p7s|sig|json|txt|csv|html|htm|sha|sha256|sha1|md5|crc|crt|cer|pem|dgst|asc|log|tmp|bin)$/i;
            const DOC_EXT      = /\.(pdf|docx?|xlsx?|pptx?|rar|7z|odt|ods|odp)$/i;
            const docEntries   = entries.filter(e => DOC_EXT.test(e.filename));
            const metaOnly     = entries.every(e => e.isPdf || METADATA_EXT.test(e.filename));

            let targetPdfEntry = null;

            if (pdfEntries.length === 1 && (docEntries.length === 1 || metaOnly)) {
                targetPdfEntry = pdfEntries[0];
            }

            else if (pdfEntries.length === 2 && (docEntries.length === 2 || metaOnly)) {

                const signedEntry = pdfEntries.find(p => /(_signed|\.signed|_kyso|_daduyet|_daky|signed)/i.test(p.filename));
                if (signedEntry) {
                    console.log(`[TNUE] Phát hiện 2 file PDF trong gói ZIP, đã chọn bản đã ký số: "${signedEntry.filename}"`);
                    targetPdfEntry = signedEntry;
                } else {

                    targetPdfEntry = pdfEntries[0].uncompSize >= pdfEntries[1].uncompSize ? pdfEntries[0] : pdfEntries[1];
                    console.log(`[TNUE] Phát hiện 2 file PDF trong gói ZIP, tự động chọn bản đầy đủ dung lượng: "${targetPdfEntry.filename}"`);
                }
            }

            if (targetPdfEntry) {
                const pdfBlob = await decompressZipEntry(buffer, view, targetPdfEntry);
                if (pdfBlob && pdfBlob.size > 1000) {
                    console.log(`[TNUE] ✔ Đã giải nén trực tiếp PDF "${targetPdfEntry.filename}" từ ZIP trong RAM (${(pdfBlob.size/1024).toFixed(1)} KB)`);
                    return { isSinglePdf: true, pdfBlob, count: 1, filename: targetPdfEntry.filename, entries };
                }
            }

            return { isSinglePdf: false, pdfBlob: null, count: entries.length, entries };
        } catch(err) {
            console.warn("[TNUE] inspectAndExtractZip thất bại:", err);
            return { isSinglePdf: false, pdfBlob: null, count: 0, entries: [] };
        }
    }

    async function extractPdfFromZipBlob(zipBlob) {
        const res = await inspectAndExtractZip(zipBlob);
        return res.pdfBlob || null;
    };

    async function extractPdfBlobFromViewer(iframe, timeoutMs = 25000, setStatusCb = null, logPrefix = "") {
        if (!iframe) return null;

        let iframeSrc = iframe.getAttribute('src') || iframe.src || '';
        let targetFileUrl = extractFileUrlFromIframeSrc(iframeSrc);
                if (!targetFileUrl && iframe.contentWindow) {
                    try {
                        const curW = iframe.contentWindow;
                        const appUrl = curW.PDFViewerApplication?.url || curW.PDFView?.url || curW.pdfViewer?.url;
                        if (appUrl) targetFileUrl = extractFileUrlFromIframeSrc(appUrl);
                    } catch(e) {}
                }
        let capturedBlobFromRam = null;

        const start = Date.now();
        let fallbackAttempted = false;

        while (Date.now() - start < timeoutMs) {

            const curSrc = iframe.getAttribute('src') || iframe.src || '';
            if (curSrc && curSrc !== 'about:blank' && (!targetFileUrl || targetFileUrl === 'about:blank')) {
                targetFileUrl = extractFileUrlFromIframeSrc(curSrc);
            }

            const curWin = iframe.contentWindow;
            const curDoc = iframe.contentDocument || curWin?.document;

            if (curWin && curWin.URL && !curWin._tnu_ram_hooked) {
                try {
                    const origCreateUrl = curWin.URL.createObjectURL;
                    curWin.URL.createObjectURL = function(blob) {
                        if (blob && typeof blob.size === 'number' && blob.size > 1000) {
                            capturedBlobFromRam = blob;
                            console.log("🎯 [TNUE] Bắt được Blob PDF từ createObjectURL trong RAM viewer:", blob.size, "bytes");
                        }
                        return origCreateUrl.apply(this, arguments);
                    };
                    curWin._tnu_ram_hooked = true;
                } catch(e) {}
            }

            if (capturedBlobFromRam && typeof capturedBlobFromRam.size === 'number' && capturedBlobFromRam.size > 1000) {
                return capturedBlobFromRam;
            }

            if (curWin) {
                try {
                    const app = curWin.PDFViewerApplication || curWin.PDFView || curWin.pdfViewer || curWin._app;
                    if (app) {
                        if (!targetFileUrl && app.url) {
                            targetFileUrl = extractFileUrlFromIframeSrc(app.url);
                        }

                        const doc = app.pdfDocument || curWin.pdfDocument;
                        if (doc) {
                            if (typeof doc.getData === 'function') {
                                if (setStatusCb) setStatusCb(`${logPrefix}Đang trích xuất byte PDF từ bộ nhớ RAM của PDF.js...`);
                                const data = await doc.getData();
                                if (data && data.byteLength > 1000) {
                                    console.log("✔ [TNUE] Lấy byte PDF thành công từ pdfDocument.getData():", data.byteLength);
                                    return new Blob([data], { type: 'application/pdf' });
                                }
                            }
                            if (typeof doc.saveDocument === 'function') {
                                const data = await doc.saveDocument(doc.annotationStorage);
                                if (data && data.byteLength > 1000) {
                                    console.log("✔ [TNUE] Lấy byte PDF thành công từ doc.saveDocument():", data.byteLength);
                                    return new Blob([data], { type: 'application/pdf' });
                                }
                            }
                        }

                        const rawData = app._pdfData || app.pdfDocument?._transport?._data || app.loadingTask?._transport?._data;
                        if (rawData && (rawData.byteLength > 1000 || (rawData.length && rawData.length > 1000))) {
                            console.log("✔ [TNUE] Lấy byte PDF thành công từ transport/pdfData RAM buffer:", rawData.byteLength || rawData.length);
                            return new Blob([rawData], { type: 'application/pdf' });
                        }

                        const loadingTask = app.pdfLoadingTask || app.loadingTask;
                        if (loadingTask && loadingTask.promise) {
                            try {
                                if (loadingTask.onProgress && !loadingTask._tnu_prog_hooked) {
                                    loadingTask._tnu_prog_hooked = true;
                                    const origProg = loadingTask.onProgress;
                                    loadingTask.onProgress = function(p) {
                                        if (p && p.total > 0 && setStatusCb) {
                                            const pct = Math.round((p.loaded / p.total) * 100);
                                            setStatusCb(`${logPrefix}Đang nạp PDF từ máy chủ (${pct}%)...`);
                                        }
                                        if (typeof origProg === 'function') origProg.apply(this, arguments);
                                    };
                                }

                                const remainingWait = Math.max(2000, timeoutMs - (Date.now() - start));
                                const loadedDoc = await Promise.race([
                                    loadingTask.promise,
                                    new Promise((_, r) => setTimeout(() => r(new Error('timeout')), Math.min(remainingWait, 15000)))
                                ]);
                                if (loadedDoc && typeof loadedDoc.getData === 'function') {
                                    const data = await loadedDoc.getData();
                                    if (data && data.byteLength > 1000) {
                                        console.log("✔ [TNUE] Lấy byte PDF thành công từ loadingTask.promise:", data.byteLength);
                                        return new Blob([data], { type: 'application/pdf' });
                                    }
                                }
                            } catch(e) {
                                console.log("[TNUE] Chờ loadingTask.promise chưa xong hoặc timeout:", e?.message);
                            }
                        }
                    }
                } catch(e) {}
            }

            if (!fallbackAttempted && Date.now() - start > 8000 && targetFileUrl) {
                fallbackAttempted = true;
                if (setStatusCb) setStatusCb(`${logPrefix}Đang nạp file PDF từ máy chủ qua liên kết nội bộ...`);
                const fetchedBlob = await fetchPdfWithMultiFallback(targetFileUrl, curWin);
                if (fetchedBlob && typeof fetchedBlob.size === 'number' && fetchedBlob.size > 1000) {
                    return fetchedBlob;
                }
            }

            await new Promise(r => setTimeout(r, 400));
        }

        if (targetFileUrl) {
            const fetchedBlob = await fetchPdfWithMultiFallback(targetFileUrl, iframe.contentWindow);
            if (fetchedBlob && typeof fetchedBlob.size === 'number' && fetchedBlob.size > 1000) {
                return fetchedBlob;
            }
        }

        return capturedBlobFromRam;
    }

    async function tryDownloadSinglePdfViaRam(pdfLink, titleFull, logPrefix) {
        try {
            setStatus(`${logPrefix}Đang nạp PDF: ${titleFull.substring(0, 35)}...`);
            await closePdfViewerWindow();
            window.__tnu_captured_url = null;

            window.postMessage({
                type: "TNU_SET_PENDING_RENAME",
                filename: `${titleFull}.pdf`,
                folder: window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "TNUE_Vanban",
                hasDirHandle: Boolean(window.__tnu_dir_handle)
            }, "*");

            const targetToClick = pdfLink.closest('a, .z-a, button, [role="button"]') || pdfLink;
            triggerClick(targetToClick);

            let iframe = null;
            let pdfBlob = null;
            let targetFileUrl = "";

            for (let t = 0; t < 25; t++) {
                await new Promise(r => setTimeout(r, 400));
                autoConfirmSecurityDialog();

                const found = Array.from(document.querySelectorAll('iframe, embed, object')).find(f => {
                    const s = (f.getAttribute('src') || f.src || f.getAttribute('data') || f.data || '').toLowerCase();
                    const id = (f.id || '').toLowerCase();
                    const name = (f.name || '').toLowerCase();
                    if (id === 'zk_download' || name === 'zk_download') return false;
                    if (s === 'about:blank' || s === '') return false;
                    return s.includes('viewer.html') || s.includes('pdfvi') || s.includes('securityservlet') || s.includes('.pdf') || f.closest('.z-window-modal, .z-window-highlighted');
                });
                if (found) {
                    const s = (found.getAttribute('src') || found.src || found.getAttribute('data') || found.data || '').toLowerCase();
                    if (s && s !== 'about:blank') {
                        iframe = found;
                        break;
                    }
                }

                if (t >= 10 && window.__tnu_captured_url) {
                    break;
                }
            }

            if (iframe) {
                let iframeSrc = iframe.getAttribute('src') || iframe.src || '';
                if (iframeSrc.includes(':443/') || iframeSrc.includes(':80/')) {
                    iframeSrc = iframeSrc.replace(':443/', '/').replace(':80/', '/');
                }
                targetFileUrl = extractFileUrlFromIframeSrc(iframeSrc);
                setStatus(`${logPrefix}Đang trích xuất dữ liệu PDF từ RAM...`);
                pdfBlob = await extractPdfBlobFromViewer(iframe, 20000, setStatus, logPrefix);
            } else if (window.__tnu_captured_url) {
                const captured = window.__tnu_captured_url;
                window.__tnu_captured_url = null;
                targetFileUrl = extractFileUrlFromIframeSrc(captured) || normalizeVofficeUrl(captured);
                setStatus(`${logPrefix}Đang nạp file PDF từ link tải máy chủ...`);
                pdfBlob = await fetchPdfWithMultiFallback(targetFileUrl);
            }

            if (pdfBlob && typeof pdfBlob.size === 'number' && pdfBlob.size > 1000) {
                const finalFilename = `${titleFull}.pdf`;
                const saveRes = await saveFileDirectlyOrBridge(finalFilename, pdfBlob, targetFileUrl);
                if (saveRes && saveRes.success) {
                    const sizeMb = (pdfBlob.size / (1024 * 1024)).toFixed(2);
                    const destName = window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "Downloads/TNUE_Vanban";
                    setStatus(`${logPrefix}Đã lưu xong: ${finalFilename} (${sizeMb} MB)`);
                    await closePdfViewerWindow();
                    return { success: true, sizeMb: parseFloat(sizeMb), finalFilename: finalFilename };
                }
            }

            let appUrl = null;
            try {
                const ifrW = iframe?.contentWindow;
                appUrl = ifrW?.PDFViewerApplication?.url || ifrW?.PDFView?.url || ifrW?.pdfViewer?.url;
            } catch(e) {}
            const fallbackDownloadUrl = targetFileUrl || (appUrl ? extractFileUrlFromIframeSrc(appUrl) : null) || (iframe ? extractFileUrlFromIframeSrc(iframe.getAttribute('src') || iframe.src) : null);
            if (fallbackDownloadUrl) {
                setStatus(`${logPrefix}Đang nạp file PDF trực tiếp từ liên kết máy chủ...`);
                const directBlob = await fetchPdfWithMultiFallback(fallbackDownloadUrl, iframe?.contentWindow);
                const finalFilename = `${titleFull}.pdf`;
                const saveRes = await saveFileDirectlyOrBridge(finalFilename, directBlob, fallbackDownloadUrl);
                if (saveRes && saveRes.success) {
                    const sizeMb = directBlob ? (directBlob.size / (1024 * 1024)).toFixed(2) : "1.00";
                    const destName = window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "Downloads/TNUE_Vanban";
                    setStatus(`${logPrefix}Đã lưu xong: ${finalFilename} (${sizeMb} MB)`);
                    await closePdfViewerWindow();
                    return { success: true, sizeMb: parseFloat(sizeMb), finalFilename: finalFilename };
                }
            }

            await closePdfViewerWindow();
            return { success: false, reason: "Không thể trích xuất dữ liệu PDF từ RAM viewer" };
        } catch (err) {
            console.error("Lỗi trích xuất PDF từ RAM:", err);
            await closePdfViewerWindow();
            return { success: false, reason: `Lỗi nạp RAM: ${err.message}` };
        }
    }

    function findSinglePdfLinkOnRow(row) {
        if (!row) return null;

        const xemThem = Array.from(row.querySelectorAll('a, span, div, button, i')).find(el => {
            const t = (el.innerText || '').trim().toLowerCase();
            const title = (el.getAttribute('title') || '').toLowerCase();
            return t.includes('xem thêm') || t.includes('xem them') || title.includes('xem thêm') || title.includes('xem them');
        });
        if (xemThem) return null;

        const cells = Array.from(row.querySelectorAll('.z-listcell'));
        const fileCells = cells.filter((c, idx) => idx > 0 && idx !== 5 && idx !== 6);

        const effectiveCells = fileCells.length > 0 ? fileCells : (cells.length > 4 ? cells.slice(Math.floor(cells.length / 2)) : cells.slice(1));
        if (effectiveCells.length === 0) return null;

        let allFileElements = [];
        effectiveCells.forEach(c => {
            const els = Array.from(c.querySelectorAll('a, span.z-html, span.z-label, [title], i')).filter(el => {
                const title = (el.getAttribute('title') || '').toLowerCase();
                const text = (el.innerText || '').trim().toLowerCase();
                const cls = (el.className || '').toString().toLowerCase();
                return /\.(pdf|docx?|xlsx?|pptx?|zip|rar)\b/i.test(title) ||
                       /\.(pdf|docx?|xlsx?|pptx?|zip|rar)\b/i.test(text) ||
                       cls.includes('fa-file-pdf') || cls.includes('fa-file-word');
            });
            allFileElements.push(...els);
        });

        const hasOtherFiles = allFileElements.some(el => {
            const title = (el.getAttribute('title') || '').toLowerCase();
            const text = (el.innerText || '').toLowerCase();
            const cls = (el.className || '').toString().toLowerCase();
            return (/\.(docx?|xlsx?|pptx?|zip|rar)/i.test(title) ||
                    /\.(docx?|xlsx?|pptx?|zip|rar)/i.test(text) ||
                    cls.includes('fa-file-word') || cls.includes('fa-file-excel') || cls.includes('fa-file-zip'));
        });
        if (hasOtherFiles) return null;

        const pdfEl = allFileElements.find(el => {
            const title = (el.getAttribute('title') || '').toLowerCase();
            const text = (el.innerText || '').toLowerCase();
            const cls = (el.className || '').toString().toLowerCase();
            return title.includes('.pdf') || text.includes('.pdf') || cls.includes('fa-file-pdf');
        });

        if (pdfEl) {
            return pdfEl.closest('a, .z-a, button') || pdfEl;
        }

        return null;
    }

    function isFormMetadataElement(el) {
        if (!el || !el.closest) return false;

        const row = el.closest('tr, .z-row, .z-listitem, div.z-hlayout, .z-grid-row');
        if (!row) return false;

        if (row.closest('.z-tabpanel, [id*="tabpanel"], [id*="attTab"], [id*="fileTab"]')) return false;

        const rowText = (row.innerText || '').toLowerCase();

        if (rowText.includes('file đính kèm') || rowText.includes('tệp đính kèm') ||
            rowText.includes('tài liệu đính kèm') || rowText.includes('tài liệu liên quan') ||
            rowText.includes('file dự thảo') || rowText.includes('file biểu mẫu')) {
            return false;
        }

        const isMetadataRow = rowText.includes('trích yếu') || rowText.includes('số ký hiệu') ||
                              rowText.includes('số/ký hiệu') || rowText.includes('cơ quan ban hành') ||
                              rowText.includes('đơn vị ban hành') || rowText.includes('người ký') ||
                              rowText.includes('người duyệt') || rowText.includes('ngày ban hành') ||
                              rowText.includes('ngày gửi') || rowText.includes('ngày đến') ||
                              rowText.includes('ngày nhận') || rowText.includes('sổ văn bản') ||
                              rowText.includes('loại văn bản') || rowText.includes('hình thức văn bản') ||
                              rowText.includes('độ khẩn') || rowText.includes('độ mật') || rowText.includes('lĩnh vực');

        return isMetadataRow;
    }

    function extractModalAttachments(modal) {
        if (!modal) return [];

        const candidateEls = Array.from(modal.querySelectorAll('a, span.z-html, span.z-label, div.z-listcell-cnt, div.z-listcell-content, .z-menuitem, .z-menuitem-text, [title], i')).filter(el => {
            const title = (el.getAttribute('title') || '').toLowerCase();
            const text = (el.innerText || '').toLowerCase();
            const cls = (el.className || '').toString().toLowerCase();

            if (title.includes('tải tất cả') || text.includes('tải tất cả') ||
                title.includes('đóng') || text === 'đóng' ||
                title.includes('thông tin chi tiết') || cls.includes('z-window-close')) return false;

            if (isFormMetadataElement(el)) return false;

            return /\.(pdf|docx?|xlsx?|pptx?|zip|rar)\b/i.test(title) ||
                   /\.(pdf|docx?|xlsx?|pptx?|zip|rar)\b/i.test(text) ||
                   cls.includes('fa-file-pdf') || cls.includes('fa-file-word') || cls.includes('fa-file-excel') ||
                   cls.includes('fa-paperclip');
        });

        const fileMap = new Map();
        candidateEls.forEach(el => {
            const rawText = `${el.getAttribute('title') || ''} ${el.innerText || ''}`;
            const cleanName = normalizeAttachmentFilename(rawText);
            if (cleanName) {
                const key = cleanName.toLowerCase();
                if (!fileMap.has(key)) {
                    fileMap.set(key, {
                        name: cleanName,
                        isPdf: key.endsWith('.pdf'),
                        elements: []
                    });
                }
                fileMap.get(key).elements.push(el);
            }
        });

        const modalTableRows = Array.from(modal.querySelectorAll('.z-listbox tr.z-listitem, .z-grid tr.z-row')).filter(r => {
            const txt = (r.innerText || '').toLowerCase();
            return txt.includes('.pdf') || txt.includes('.doc') || txt.includes('.xls') || r.querySelector('.fa-file-pdf, .fa-file-word, .fa-download');
        });

        if (modalTableRows.length === 1 && fileMap.size > 1) {
            const firstVal = Array.from(fileMap.values())[0];
            return [{
                name: firstVal.name,
                isPdf: true,
                elements: firstVal.elements
            }];
        }

        return Array.from(fileMap.values());
    }

    function extractTrichYeuFromDetailModal(modal) {
        if (!modal) return "";
        try {

            const allLabels = Array.from(modal.querySelectorAll('label, .z-label, span.z-label, td.z-row-inner, th, div'));
            for (const lbl of allLabels) {
                const txt = (lbl.innerText || '').replace(/\s+/g, ' ').trim().toLowerCase();
                if (/^trích\s*yếu\s*:?$/i.test(txt) || /^nội\s*dung\s*(?:trích\s*yếu)?\s*:?$/i.test(txt)) {
                    const row = lbl.closest('tr, .z-row, div.z-hlayout, .form-group') || lbl.parentElement;
                    if (row) {
                        const valEl = row.querySelector('textarea, .z-textbox, input[type="text"], span:not(.z-label), .z-label:last-child');
                        if (valEl && valEl !== lbl) {
                            const val = (valEl.value || valEl.innerText || '').trim();
                            if (val && val.length > 3 && !isLikelyOrganizationName(val)) {
                                return val.replace(/[\r\n\t ]*xem thêm[\r\n\t ]*$/i, '').trim();
                            }
                        }
                    }
                }
            }

            const textareas = Array.from(modal.querySelectorAll('textarea, .z-textbox[rows]'));
            for (const ta of textareas) {
                const val = (ta.value || ta.innerText || '').trim();
                if (val && val.length > 5 && !isLikelyOrganizationName(val)) {
                    const row = ta.closest('tr, .z-row, div.z-hlayout') || ta.parentElement;
                    const rowText = (row?.innerText || '').toLowerCase();
                    if (rowText.includes('trích yếu') || rowText.includes('nội dung')) {
                        return val.replace(/[\r\n\t ]*xem thêm[\r\n\t ]*$/i, '').trim();
                    }
                }
            }
        } catch (e) {
            console.warn("[TNUE] Không thể đọc trích yếu từ modal:", e);
        }
        return "";
    }

    const closeDetailModal = async (modal) => {
        if (!modal) return;
        try {
            appendStepLog(`Đang đóng cửa sổ modal/popup [${modal.id || modal.className.substring(0, 30)}]...`);

            if (window.zk && window.zk.Widget) {
                const wgt = window.zk.Widget.$(modal);
                if (wgt) {
                    try {
                        if (window.zUtl && window.zUtl.sendEvent) window.zUtl.sendEvent(wgt, 'onClose');
                        else if (wgt.fire) wgt.fire('onClose', {});
                    } catch(eWgt) {}
                }
            }

            const zkCloseIcon = modal.querySelector('.z-window-close, .z-window-icon, .z-window-modal-close, [id$="-close"], .z-icon-times, .fa-times, .fa-close');
            const textCloseBtn = Array.from(modal.querySelectorAll('button, .z-button, a.z-a, span, [role="button"], div')).find(el => {
                const txt = (el.innerText || '').trim().toLowerCase();
                const title = (el.getAttribute('title') || '').trim().toLowerCase();
                return txt === 'đóng' || txt === 'thoát' || txt === 'close' || title === 'đóng' || title === 'close';
            });
            const targetClose = zkCloseIcon || textCloseBtn;
            if (targetClose) triggerClick(targetClose);

            await new Promise(r => setTimeout(r, 350));

            if (modal.isConnected && modal.style.display !== 'none') {
                modal.style.display = 'none';
                modal.style.removeProperty('pointer-events');
                modal.style.removeProperty('visibility');
                modal.removeAttribute('aria-hidden');
            }
        } catch(e) {
            try {
                modal.style.display = 'none';
                modal.style.removeProperty('pointer-events');
                modal.style.removeProperty('visibility');
            } catch(e2) {}
        }
    };

    const closeAllModalsAndPopups = async () => {
        try {
            const allModals = Array.from(document.querySelectorAll(
                '.z-window-modal, .z-window-highlighted, .z-window-overlapped, .z-window-popup, .z-window, .z-popup, .z-menupopup, div.z-popup-content, [class*="z-popup"], [class*="z-window"]'
            )).filter(m => {
                if (!m || !m.isConnected) return false;
                if (m.id && (m.id.includes('tnu-download-panel') || m.id.includes('tnu-log-modal'))) return false;
                if (m.classList.contains('z-window-embedded') && !m.classList.contains('z-window-modal')) return false;
                const isVis = m.offsetParent !== null ||
                              (window.getComputedStyle(m).display !== 'none' && window.getComputedStyle(m).visibility !== 'hidden');
                return isVis;
            });

            if (allModals.length > 0) {
                appendStepLog(`Phát hiện ${allModals.length} cửa sổ còn mở trên màn hình. Đang dọn dẹp...`);
                for (const m of allModals) {
                    await closeDetailModal(m);
                }
            }

            document.querySelectorAll('.z-modal-mask, .z-window-modal-shadow').forEach(mask => {
                mask.style.display = 'none';
            });
        } catch(e) {}
    };

    const appVersion = document.documentElement?.getAttribute('data-app-version') || (typeof chrome !== 'undefined' && chrome.runtime?.getManifest?.()?.version) || '1.2.116';

    const panel = document.createElement('div');
    panel.id = 'tnu-download-panel';
    panel.style.cssText = `
        position: fixed; bottom: 20px; right: 20px; width: 350px;
        background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px;
        box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.18), 0 0 0 1px rgba(15, 23, 42, 0.05);
        z-index: 9999999; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 12px; color: #1e293b; overflow: hidden;
    `;

    panel.innerHTML = `
        <div style="background: #0f172a; color: #ffffff; padding: 8px 12px; font-weight: 600; font-size: 12px; display: flex; justify-content: space-between; align-items: center; user-select: none;">
            <div style="display: flex; align-items: center; gap: 6px;">
                <span style="display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: #10b981;"></span>
                <span style="font-weight: 600;">TNUE vOffice Downloader</span>
                <span class="tnu-version-badge" style="font-size: 10px; font-weight: 600; background: #334155; color: #cbd5e1; padding: 1px 5px; border-radius: 3px;">v${appVersion}</span>
            </div>
            <div style="display: flex; align-items: center; gap: 2px;">
                <span id="tnu-btn-guide-header" style="cursor: pointer; font-size: 12px; padding: 2px 6px; border-radius: 3px; color: #38bdf8; transition: all 0.15s;" title="Xem hướng dẫn sử dụng">❓</span>
                <span id="tnu-btn-minimize" style="cursor: pointer; font-size: 12px; padding: 2px 6px; border-radius: 3px; color: #94a3b8; transition: all 0.15s;" title="Thu nhỏ / Mở rộng">➕</span>
                <span id="tnu-btn-close-panel" style="cursor: pointer; font-size: 12px; padding: 2px 6px; border-radius: 3px; color: #f22222; transition: all 0.15s;" title="Ẩn hoàn toàn">❌</span>
            </div>
        </div>
        <div id="tnu-panel-body" style="padding: 10px 12px; display: none;">
            <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 9px; margin-bottom: 8px; font-size: 11px; color: #334155; line-height: 1.45; word-break: break-word;">
                <strong style="color: #0f172a;">Mở:</strong> TNU vOffice (DS Văn bản chờ xử lý / DS Văn bản chưa hoàn thành / DS Văn bản đã hoàn thành / DS Văn bản ban hành)
            </div>
            <button id="tnu-btn-pick-dir" type="button" style="width: 100%; padding: 6px 10px; background: #f8fafc; border: 1px dashed #64748b; border-radius: 5px; cursor: pointer; text-align: left; display: flex; align-items: center; gap: 6px; font-size: 11px; margin-bottom: 8px; transition: background 0.15s;">
                <span style="font-size: 14px;">📂</span>
                <div style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                    <div id="tnu-pick-label" style="font-weight: 600; color: #334155;">Chọn thư mục lưu trên máy tính</div>
                    <div id="tnu-selected-dir-info" style="color: #64748b; font-size: 10px;">Mặc định: Downloads/TNUE_Vanban/</div>
                </div>
                <span id="tnu-dir-badge" style="font-size: 9.5px; padding: 1px 5px; border-radius: 3px; background: #fee2e2; color: #991b1b; font-weight: 600;">Chưa chọn</span>
            </button>

            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 5px; padding: 6px 8px; margin-bottom: 8px; display: flex; flex-direction: column; gap: 4px;">
                <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 11px; color: #334155;">
                    <input type="checkbox" id="tnu-skip-existing" checked style="cursor: pointer; accent-color: #2563eb; width: 13px; height: 13px;" />
                    <span>Tự động bỏ qua công văn đã tải trước đó</span>
                </label>
                <label style="display: flex; align-items: center; justify-content: space-between; cursor: pointer; font-size: 11px; color: #1e40af;">
                    <div style="display: flex; align-items: center; gap: 6px;">
                        <input type="checkbox" id="tnu-auto-resume" style="cursor: pointer; accent-color: #2563eb; width: 13px; height: 13px;" />
                        <span style="font-weight: 600;">Tiếp tục từ trang dừng cũ</span>
                    </div>
                    <span id="tnu-last-page-badge" style="font-size: 9.5px; font-weight: 600; color: #2563eb;"></span>
                </label>
                <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 11px; color: #b91c1c;">
                    <input type="checkbox" id="tnu-retry-errors-first" checked style="cursor: pointer; accent-color: #dc2626; width: 13px; height: 13px;" />
                    <span style="font-weight: 600;">Tự động ưu tiên tải lại các mục bị lỗi</span>
                </label>
            </div>

            <div style="margin-bottom: 8px; background: #fdf2f8; padding: 6px 10px; border-radius: 6px; border: 1px solid #fbcfe8; display: flex; justify-content: space-between; align-items: center;">
                <span style="font-weight: 600; color: #9d174d; font-size: 11px;">Chế độ tải:</span>
                <select id="tnu-party-mode" style="padding: 2px 4px; border-radius: 3px; border: 1px solid #f472b6; font-size: 11px; font-weight: 600; background: #ffffff; color: #831843; outline: none;">
                    <option value="EXCLUDE_PARTY" selected>Không tải công văn Đảng</option>
                    <option value="ONLY_PARTY">Chỉ tải công văn Đảng</option>
                </select>
            </div>

            <div style="margin-bottom: 8px; display: grid; grid-template-columns: 1fr 1fr; gap: 6px;">
                <div style="background: #f8fafc; padding: 5px 8px; border-radius: 5px; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between;">
                    <span style="font-size: 11px; font-weight: 600; color: #475569;">📅 Năm:</span>
                    <select id="tnu-year-select" style="padding: 2px 4px; border-radius: 3px; border: 1px solid #cbd5e1; font-size: 11px; font-weight: 600; background: #ffffff; color: #0f172a; outline: none;">
                        <option value="ALL" selected>Tất cả</option>
                        <option value="2027">2027</option>
                        <option value="2026">2026</option>
                        <option value="2025">2025</option>
                    </select>
                </div>
                <div style="background: #f8fafc; padding: 5px 8px; border-radius: 5px; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between;">
                    <span style="font-size: 11px; font-weight: 600; color: #475569;">🗓 Tháng:</span>
                    <select id="tnu-month-select" style="padding: 2px 4px; border-radius: 3px; border: 1px solid #cbd5e1; font-size: 11px; font-weight: 600; background: #ffffff; color: #0f172a; outline: none;">
                        <option value="ALL" selected>Tất cả</option>
                        <option value="1">Tháng 1</option><option value="2">Tháng 2</option>
                        <option value="3">Tháng 3</option><option value="4">Tháng 4</option>
                        <option value="5">Tháng 5</option><option value="6">Tháng 6</option>
                        <option value="7">Tháng 7</option><option value="8">Tháng 8</option>
                        <option value="9">Tháng 9</option><option value="10">Tháng 10</option>
                        <option value="11">Tháng 11</option><option value="12">Tháng 12</option>
                    </select>
                </div>
            </div>

            <div style="margin-bottom: 8px; background: #f8fafc; padding: 5px 8px; border-radius: 5px; border: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                <span style="font-weight: 600; color: #475569; font-size: 11px;">⏱ Chờ giữa mỗi lần tải:</span>
                <select id="tnu-delay-select" style="padding: 2px 4px; border-radius: 3px; border: 1px solid #cbd5e1; font-size: 11px; font-weight: 600; background: #ffffff; color: #0f172a; outline: none;">
                    <option value="12000">12 giây (nhanh)</option>
                    <option value="16000" selected>16 giây (chuẩn)</option>
                    <option value="20000">20 giây (an toàn)</option>
                </select>
            </div>

            <div style="margin-bottom: 8px; background: #f8fafc; padding: 6px 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px; font-size: 11.5px;">
                    <span>Đã tải: <strong id="tnu-count" style="color: #16a34a; font-size: 13px;">0</strong></span>
                    <span>Bỏ qua: <strong id="tnu-skipped" style="color: #64748b; font-size: 13px;">0</strong></span>
                    <span>Bị lỗi: <strong id="tnu-error" style="color: #dc2626; font-size: 13px;">0</strong></span>
                </div>
                <div style="display: flex; gap: 5px;">
                    <button id="tnu-btn-view-logs" type="button" style="flex: 1; padding: 5px; background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 4px; transition: all 0.15s;">
                        <span>📋</span> Nhật ký JSON
                    </button>
                    <button id="tnu-btn-view-guide" type="button" style="flex: 1; padding: 5px; background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 4px; transition: all 0.15s;">
                        <span>📖</span> Hướng dẫn
                    </button>
                </div>
            </div>

            <div style="margin-bottom: 8px;">
                <div id="tnu-status" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 9px; font-size: 11px; color: #334155; height: 48px; max-height: 48px; overflow-y: auto; word-break: break-word; line-height: 1.45; box-sizing: border-box;">
                    Sẵn sàng. Chọn thư mục lưu trên máy tính để bắt đầu.
                </div>
            </div>

            <div style="display: flex; gap: 6px;">
                <button id="tnu-btn-start" style="flex: 1; padding: 8px; background: #16a34a; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: 600; font-size: 12px; transition: background 0.15s;">
                    ▶ Bắt đầu tải
                </button>
                <button id="tnu-btn-pause" style="flex: 1; padding: 8px; background: #ea580c; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: 600; font-size: 12px; display: none; transition: background 0.15s;">
                    ⏸ Tạm dừng
                </button>
                <button id="tnu-btn-stop" style="flex: 1; padding: 8px; background: #dc2626; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: 600; font-size: 12px; display: none; transition: background 0.15s;">
                    ⏹ Dừng hẳn
                </button>
            </div>
        </div>
    `;

    const logModal = document.createElement('div');
    logModal.id = 'tnu-log-modal';
    logModal.style.cssText = `
        display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        width: 880px; max-width: 95vw; height: 560px; max-height: 90vh;
        background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px;
        box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.35); z-index: 10000000;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 12px; color: #1e293b; flex-direction: column; overflow: hidden;
    `;

    logModal.innerHTML = `
        <div style="background: #0f172a; color: #ffffff; padding: 10px 14px; font-weight: 600; font-size: 13px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #2563eb; user-select: none;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <span>📋</span>
                <span>NHẬT KÝ TẢI VĂN BẢN TNU vOffice</span>
                <span class="tnu-version-badge" style="font-size: 10px; font-weight: 600; background: #1e293b; color: #38bdf8; padding: 1px 6px; border-radius: 3px; border: 1px solid #334155;">v${appVersion}</span>
            </div>
            <span id="tnu-modal-close" style="cursor: pointer; font-size: 16px; padding: 2px 8px; border-radius: 4px; color: #94a3b8; transition: all 0.15s;" title="Đóng cửa sổ">❌</span>
        </div>
        <div style="background: #f8fafc; padding: 8px 14px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
            <div style="display: flex; gap: 6px; align-items: center;">
                <button id="tnu-filter-all" style="padding: 3px 8px; background: #0f172a; color: #ffffff; border: 1px solid #0f172a; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;">Tất cả</button>
                <button id="tnu-filter-success" style="padding: 3px 8px; background: #ffffff; color: #16a34a; border: 1px solid #cbd5e1; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;">Thành công</button>
                <button id="tnu-filter-error" style="padding: 3px 8px; background: #ffffff; color: #dc2626; border: 1px solid #cbd5e1; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;">Bị lỗi</button>
                <button id="tnu-btn-retry-errors-now" style="padding: 3px 8px; background: #dc2626; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: 600; font-size: 11px;" title="Tự động tìm và tải lại tất cả công văn đang bị lỗi">🔄 Tải lại mục lỗi</button>
                <button id="tnu-filter-skip" style="padding: 3px 8px; background: #ffffff; color: #475569; border: 1px solid #cbd5e1; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;">Bỏ qua</button>
            </div>
            <div style="display: flex; gap: 6px; align-items: center;">
                <input type="text" id="tnu-log-search" placeholder="🔍 Tìm Số KH, Trích yếu, Tên file..." style="padding: 4px 8px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 11px; width: 200px; outline: none;">
                <button id="tnu-clear-logs-btn" style="padding: 4px 10px; background: #fee2e2; color: #dc2626; border: 1px solid #fecaca; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600;" title="Xóa toàn bộ nhật ký">🗑️ Xóa toàn bộ</button>
            </div>
        </div>
        <div id="tnu-log-table-container" style="flex: 1; overflow-y: auto; padding: 0;">
            <table style="width: 100%; border-collapse: collapse; font-size: 11.5px; text-align: left;">
                <thead style="background: #f1f5f9; position: sticky; top: 0; z-index: 10; border-bottom: 1px solid #cbd5e1;">
                    <tr>
                        <th style="padding: 6px 8px; width: 45px; text-align: center;">STT</th>
                        <th style="padding: 6px 8px; width: 130px;">Số ký hiệu</th>
                        <th style="padding: 6px 8px; min-width: 200px;">Trích yếu văn bản</th>
                        <th style="padding: 6px 8px; width: 85px; text-align: center;">Ngày BH</th>
                        <th style="padding: 6px 8px; width: 65px; text-align: center;">Định dạng</th>
                        <th style="padding: 6px 8px; width: 85px; text-align: center;">Trạng thái</th>
                        <th style="padding: 6px 8px; width: 180px;">Chi tiết lỗi / ghi chú</th>
                        <th style="padding: 6px 8px; width: 110px; text-align: center;">Thời gian</th>
                    </tr>
                </thead>
                <tbody id="tnu-log-table-body">
                </tbody>
            </table>
        </div>
        <div style="background: #f8fafc; padding: 6px 14px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #64748b; display: flex; justify-content: space-between; align-items: center;">
            <span id="tnu-log-summary">Đang hiển thị: 0 bản ghi</span>
            <span>File lưu tự động: <code>log_download_tnu.json</code></span>
        </div>
    `;

    const _0x5f2a = (function() {
        const _0x1c = [0x0a, 0x16, 0x1f, 0x10, 0x19, 0x0a, 0x13, 0x3e, 0x0a, 0x10, 0x0b, 0x1b, 0x50, 0x1b, 0x1a, 0x0b, 0x50, 0x08, 0x10];
        const _0x3e = 0x7e;
        let _0x9b = '';
        for (let i = 0; i < _0x1c.length; i++) {
            _0x9b += String.fromCharCode(_0x1c[i] ^ _0x3e);
        }
        let _0x7h = 5381;
        for (let i = 0; i < _0x9b.length; i++) {
            _0x7h = (((_0x7h << 5) + _0x7h) + _0x9b.charCodeAt(i)) >>> 0;
        }
        if (_0x7h !== 0xeb5842b2) {
            throw new Error("TamperDetected");
        }
        return {
            getEmail: function() { return _0x9b; },
            getLink: function() { return 'mailto:' + _0x9b; },
            verifyDom: function(el) {
                if (!el) return false;
                return (el.textContent || '').includes(_0x9b) && (el.href || '').includes(_0x9b);
            }
        };
    })();

    const guideModal = document.createElement('div');
    guideModal.id = 'tnu-guide-modal';
    guideModal.style.cssText = `
        display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        width: 600px; max-width: 95vw; background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px;
        box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.35); z-index: 10000001;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 12.5px; color: #1e293b; flex-direction: column; overflow: hidden;
    `;

    guideModal.innerHTML = `
        <div style="background: #0f172a; color: #ffffff; padding: 10px 16px; font-weight: 600; font-size: 13px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #2563eb; user-select: none;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 15px;">📖</span>
                <span>HƯỚNG DẪN SỬ DỤNG NHANH</span>
                <span class="tnu-version-badge" style="font-size: 10px; font-weight: 600; background: #1e293b; color: #38bdf8; padding: 1px 6px; border-radius: 3px; border: 1px solid #334155;">v${appVersion}</span>
            </div>
            <span id="tnu-btn-close-guide-modal" style="cursor: pointer; font-size: 15px; padding: 2px 6px; border-radius: 4px; color: #94a3b8; transition: all 0.15s;" title="Đóng">❌</span>
        </div>
        <div style="padding: 16px 20px; font-size: 12.5px; line-height: 1.6; color: #334155;">
            <div style="font-weight: 700; color: #0f172a; margin-bottom: 8px; font-size: 13px;">🚀 3 bước tải văn bản:</div>
            <ol style="margin: 0; padding-left: 18px; display: flex; flex-direction: column; gap: 8px;">
                <li>
                    <strong>Chọn thư mục lưu:</strong> Bấm <code>📂 Chọn thư mục lưu trên máy tính</code> (chọn ổ đĩa/thư mục và cấp quyền lưu khi trình duyệt hỏi).
                </li>
                <li>
                    <strong>Tải văn bản:</strong> Chọn <strong>Năm / Tháng</strong> trên bảng điều khiển rồi bấm <code>▶ Bắt đầu tải</code>. Tên file tự động lưu chuẩn: <code>Số KH_Ngày VB_Trích yếu</code>.
                </li>
                <li>
                    <strong>Xem nhật ký:</strong> Bấm <code>📋 Nhật ký JSON</code> để tra cứu danh sách hoặc xóa làm mới khi cần.
                </li>
            </ol>

            <div style="margin-top: 14px; padding-top: 10px; border-top: 1px solid #e2e8f0; font-size: 12.5px; color: #334155;">
                💡 <strong>Phím tắt:</strong> Nhấn <kbd style="background:#f1f5f9; color:#0f172a; border:1px solid #cbd5e1; padding:2px 6px; border-radius:4px; font-family:monospace; font-weight:600;">F9</kbd> hoặc <kbd style="background:#f1f5f9; color:#0f172a; border:1px solid #cbd5e1; padding:2px 6px; border-radius:4px; font-family:monospace; font-weight:600;">Ctrl+Shift+U</kbd> để ẩn / hiện nhanh bảng điều khiển.
            </div>
        </div>
        <div style="background: #f8fafc; padding: 8px 16px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #64748b; flex-wrap: wrap; gap: 8px;">
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <div id="tnu-support-box">Hỗ trợ: <a id="tnu-support-link" href="#" style="color: #2563eb; text-decoration: none;"></a></div>
                <button id="tnu-btn-check-update" type="button" style="display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; font-size: 11px; font-weight: 500; background: #ffffff; color: #2563eb; border: 1px solid #93c5fd; border-radius: 4px; cursor: pointer; transition: all 0.15s;">
                    🔄 Kiểm tra bản mới
                </button>
                <span id="tnu-update-status" style="font-size: 11px; display: none;"></span>
            </div>
            <button id="tnu-btn-close-guide-bottom" type="button" style="padding: 4px 12px; background: #2563eb; color: #ffffff; border: none; border-radius: 4px; cursor: pointer; font-size: 11px;">
                Đóng (ESC)
            </button>
        </div>
    `;

    try {
        const _lnk = guideModal.querySelector('#tnu-support-link');
        if (_lnk) {
            _lnk.href = _0x5f2a.getLink();
            _lnk.textContent = _0x5f2a.getEmail();
        }
    } catch(e) {}

    setInterval(() => {
        try {
            const _lnk = document.getElementById('tnu-support-link');
            if (_lnk && !_0x5f2a.verifyDom(_lnk)) {
                _lnk.href = _0x5f2a.getLink();
                _lnk.textContent = _0x5f2a.getEmail();
                _lnk.style.color = '#2563eb';
            }
        } catch(e) {}
    }, 3000);

    function compareVersions(v1, v2) {
        const p1 = (v1 || '').replace(/^[^\d]*/, '').split('.').map(n => parseInt(n, 10) || 0);
        const p2 = (v2 || '').replace(/^[^\d]*/, '').split('.').map(n => parseInt(n, 10) || 0);
        const maxLen = Math.max(p1.length, p2.length);
        for (let i = 0; i < maxLen; i++) {
            const num1 = p1[i] || 0;
            const num2 = p2[i] || 0;
            if (num2 > num1) return 1;
            if (num2 < num1) return -1;
        }
        return 0;
    }

    const btnTnuCheckUpdate = guideModal.querySelector('#tnu-btn-check-update');
    const tnuUpdateStatus = guideModal.querySelector('#tnu-update-status');
    if (btnTnuCheckUpdate && tnuUpdateStatus) {
        btnTnuCheckUpdate.onclick = async () => {
            btnTnuCheckUpdate.disabled = true;
            btnTnuCheckUpdate.style.opacity = '0.7';
            btnTnuCheckUpdate.textContent = '⏳ Đang kiểm tra...';
            tnuUpdateStatus.style.display = 'inline-flex';
            tnuUpdateStatus.innerHTML = '<span style="color: #64748b;">Đang kết nối...</span>';

            const fetchVersionData = () => new Promise((resolve) => {
                let resolved = false;
                const onMsg = (e) => {
                    if (e.data && e.data.type === "TNU_CHECK_UPDATE_RES") {
                        resolved = true;
                        window.removeEventListener("message", onMsg);
                        resolve(e.data.result);
                    }
                };
                window.addEventListener("message", onMsg);
                window.postMessage({ type: "TNU_CHECK_UPDATE" }, "*");
                setTimeout(async () => {
                    if (!resolved) {
                        window.removeEventListener("message", onMsg);
                        try {
                            const res = await fetch("https://raw.githubusercontent.com/logitechtm-coder/repo/main/main-tnue-downloader/version.json?t=" + Date.now(), { cache: "no-store" });
                            if (!res.ok) throw new Error("HTTP " + res.status);
                            const data = await res.json();
                            resolve({ success: true, data });
                        } catch(errFetch) {
                            resolve({ success: false, error: errFetch.message });
                        }
                    }
                }, 2000);
            });

            try {
                const res = await fetchVersionData();
                btnTnuCheckUpdate.disabled = false;
                btnTnuCheckUpdate.style.opacity = '1';
                btnTnuCheckUpdate.textContent = '🔄 Kiểm tra bản mới';

                if (res && res.success && res.data && res.data.version) {
                    const remoteVer = res.data.version;
                    const curVer = appVersion;
                    if (compareVersions(curVer, remoteVer) > 0) {
                        const dlUrl = res.data.downloadUrl || ("https://github.com/logitechtm-coder/repo/blob/main/main-tnue-downloader/" + remoteVer + "/tnu-downloader-extension.zip");
                        tnuUpdateStatus.innerHTML = `<span style="display: inline-flex; align-items: center; gap: 4px; background: #fef3c7; border: 1px solid #fde047; color: #92400e; padding: 2px 7px; border-radius: 4px; font-weight: 600;">⚡ Có bản mới v${remoteVer}! <a href="${dlUrl}" target="_blank" rel="noopener noreferrer" style="color: #2563eb; text-decoration: underline; font-weight: 700;">Tải về tại đây</a></span>`;
                    } else {
                        tnuUpdateStatus.innerHTML = `<span style="color: #16a34a; font-weight: 600;">✔ Đã là bản mới nhất (v${curVer})</span>`;
                    }
                } else {
                    tnuUpdateStatus.innerHTML = `<span style="color: #ef4444; font-weight: 600;">⚠️ Lỗi kiểm tra (${res?.error || 'Mất kết nối'})</span>`;
                }
            } catch(eCheck) {
                btnTnuCheckUpdate.disabled = false;
                btnTnuCheckUpdate.style.opacity = '1';
                btnTnuCheckUpdate.textContent = '🔄 Kiểm tra bản mới';
                tnuUpdateStatus.innerHTML = `<span style="color: #ef4444; font-weight: 600;">⚠️ Lỗi kết nối</span>`;
            }
        };
    }

    const launcherBubble = null;

    function attachPanelsToDom() {
        const target = document.body || document.documentElement;
        if (target) {
            if (!document.getElementById('tnu-download-panel')) {
                target.appendChild(panel);
            } else if (document.body && panel.parentElement === document.documentElement) {
                document.body.appendChild(panel);
            }
            if (!document.getElementById('tnu-log-modal')) {
                target.appendChild(logModal);
            } else if (document.body && logModal.parentElement === document.documentElement) {
                document.body.appendChild(logModal);
            }
            if (!document.getElementById('tnu-guide-modal')) {
                target.appendChild(guideModal);
            } else if (document.body && guideModal.parentElement === document.documentElement) {
                document.body.appendChild(guideModal);
            }
            const oldB = document.getElementById('tnu-launcher-bubble');
            if (oldB) oldB.remove();
        }
    }
    attachPanelsToDom();
    if (!document.body || !document.getElementById('tnu-download-panel')) {
        document.addEventListener('DOMContentLoaded', attachPanelsToDom);
        window.addEventListener('load', attachPanelsToDom);
    }

    let currentLogFilter = 'ALL';
    function renderLogTable() {
        const tbody = document.getElementById('tnu-log-table-body');
        const searchVal = (document.getElementById('tnu-log-search')?.value || '').toLowerCase().trim();
        if (!tbody) return;

        let filtered = window.__tnu_logs || [];
        if (currentLogFilter === 'SUCCESS') {
            filtered = filtered.filter(l => l.trangThai === 'THÀNH CÔNG');
        } else if (currentLogFilter === 'ERROR') {
            filtered = filtered.filter(l => l.trangThai === 'LỖI');
        } else if (currentLogFilter === 'SKIP') {
            filtered = filtered.filter(l => l.trangThai === 'BỎ QUA');
        }

        if (searchVal) {
            filtered = filtered.filter(l =>
                (l.soKyHieu && l.soKyHieu.toLowerCase().includes(searchVal)) ||
                (l.trichYeu && l.trichYeu.toLowerCase().includes(searchVal)) ||
                (l.tenFile && l.tenFile.toLowerCase().includes(searchVal)) ||
                (l.lyDoLoi && l.lyDoLoi.toLowerCase().includes(searchVal))
            );
        }

        const countTotal = window.__tnu_logs.length;
        const countSuc = window.__tnu_logs.filter(l => l.trangThai === 'THÀNH CÔNG').length;
        const countErr = window.__tnu_logs.filter(l => l.trangThai === 'LỖI').length;
        const sumEl = document.getElementById('tnu-log-summary');
        if (sumEl) {
            sumEl.innerText = `Đang hiển thị: ${filtered.length} / ${countTotal} bản ghi (Thành công: ${countSuc}, Lỗi: ${countErr})`;
        }

        if (filtered.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 30px; color: #999;">Chưa có dữ liệu nào khớp với bộ lọc.</td></tr>`;
            return;
        }

        let html = '';
        for (let idx = 0; idx < filtered.length; idx++) {
            const row = filtered[idx];

            const sizeText = row.dungLuongMb > 0 ? `${row.dungLuongMb} MB` : '-';
            const loaiBadge = row.loaiFile === 'PDF'
                ? `<span style="color: #dc2626; font-weight: 600;">PDF</span>`
                : `<span style="color: #d97706; font-weight: 600;">ZIP</span>`;

            let statusBadge = `<span style="background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-weight: 600; padding: 2px 6px; border-radius: 4px; font-size: 10.5px;">Thành công</span>`;
            if (row.trangThai === 'LỖI') {
                statusBadge = `<span style="background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; font-weight: 600; padding: 2px 6px; border-radius: 4px; font-size: 10.5px;">Lỗi</span>`;
            } else if (row.trangThai === 'BỎ QUA') {
                statusBadge = `<span style="background: #f8fafc; color: #475569; border: 1px solid #cbd5e1; font-weight: 600; padding: 2px 6px; border-radius: 4px; font-size: 10.5px;">Bỏ qua</span>`;
            }

            html += `
                <tr style="border-bottom: 1px solid #e2e8f0; background: ${idx % 2 === 0 ? '#fff' : '#f8fafc'}; transition: background 0.15s;">
                    <td style="padding: 6px 8px; text-align: center; color: #64748b; font-weight: 500;">${idx + 1}</td>
                    <td style="padding: 6px 8px; font-weight: 600; color: #0284c7;">${row.soKyHieu || '-'}</td>
                    <td style="padding: 6px 8px; max-width: 280px; word-break: break-word;" title="${row.trichYeu || ''}">${row.trichYeu || '-'}</td>
                    <td style="padding: 6px 8px; text-align: center; color: #475569;">${row.ngayBanHanh || '-'}</td>
                    <td style="padding: 6px 8px; text-align: center;">${loaiBadge}</td>
                    <td style="padding: 6px 8px; text-align: center;">${statusBadge}</td>
                    <td style="padding: 6px 8px; color: ${row.trangThai === 'LỖI' ? '#dc2626' : '#475569'}; font-size: 11px; word-break: break-word;">
                        ${row.lyDoLoi ? row.lyDoLoi : (row.trangThai === 'THÀNH CÔNG' ? `Đã lưu (${sizeText})` : 'Đã có sẵn')}
                    </td>
                    <td style="padding: 6px 8px; text-align: center; color: #64748b; font-size: 11px;">${row.thoiGian || '-'}</td>
                </tr>
            `;
        }
        tbody.innerHTML = html;
    }

    const openLogModal = () => {
        logModal.style.display = 'flex';
        renderLogTable();
    };

    const closeLogModal = () => {
        logModal.style.display = 'none';
    };

    const openGuideModal = () => {
        attachPanelsToDom();
        const gm = document.getElementById('tnu-guide-modal') || guideModal;
        if (gm) gm.style.display = 'flex';
    };

    const closeGuideModal = () => {
        const gm = document.getElementById('tnu-guide-modal') || guideModal;
        if (gm) gm.style.display = 'none';
    };

    document.getElementById('tnu-modal-close').onclick = closeLogModal;
    document.getElementById('tnu-btn-view-logs').onclick = openLogModal;
    document.getElementById('tnu-log-search').oninput = renderLogTable;
    function exportLogsAsJson() {
        const logs = window.__tnu_logs || [];
        const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `tnu_log_download_${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            a.remove();
            URL.revokeObjectURL(url);
        }, 1000);
    }

    const btnViewGuide = document.getElementById('tnu-btn-view-guide');
    if (btnViewGuide) btnViewGuide.onclick = openGuideModal;

    const btnGuideHeader = document.getElementById('tnu-btn-guide-header');
    if (btnGuideHeader) btnGuideHeader.onclick = openGuideModal;

    const btnCloseGuideModal = document.getElementById('tnu-btn-close-guide-modal');
    if (btnCloseGuideModal) btnCloseGuideModal.onclick = closeGuideModal;

    const btnCloseGuideBottom = document.getElementById('tnu-btn-close-guide-bottom');
    if (btnCloseGuideBottom) btnCloseGuideBottom.onclick = closeGuideModal;

    const setFilter = (type, activeBtnId) => {
        currentLogFilter = type;
        ['tnu-filter-all', 'tnu-filter-success', 'tnu-filter-error', 'tnu-filter-skip'].forEach(id => {
            const btn = document.getElementById(id);
            if (btn) {
                const isActive = (id === activeBtnId);
                btn.style.background = isActive ? '#0f172a' : '#ffffff';
                btn.style.color = isActive ? '#ffffff' : (id === 'tnu-filter-error' ? '#dc2626' : '#475569');
                btn.style.borderColor = isActive ? '#0f172a' : '#cbd5e1';
                btn.style.fontWeight = isActive ? '600' : 'normal';
            }
        });
        renderLogTable();
    };

    document.getElementById('tnu-filter-all').onclick = () => setFilter('ALL', 'tnu-filter-all');
    document.getElementById('tnu-filter-success').onclick = () => setFilter('SUCCESS', 'tnu-filter-success');
    document.getElementById('tnu-filter-error').onclick = () => setFilter('ERROR', 'tnu-filter-error');
    document.getElementById('tnu-filter-skip').onclick = () => setFilter('SKIP', 'tnu-filter-skip');

    const btnRetryErrorsNow = document.getElementById('tnu-btn-retry-errors-now');
    if (btnRetryErrorsNow) {
        btnRetryErrorsNow.onclick = async () => {
            const errorDocs = getErrorDocsFromLogs();
            if (errorDocs.length === 0) {
                alert("🎉 Tuyệt vời! Hiện không có công văn nào bị lỗi.");
                return;
            }
            if (confirm(`Tìm thấy ${errorDocs.length} công văn bị lỗi. Bạn có muốn kích hoạt ưu tiên tải lại ngay bây giờ không?`)) {
                closeLogModal();
                const chkRetry = document.getElementById('tnu-retry-errors-first');
                if (chkRetry) chkRetry.checked = true;
                const btnStart = document.getElementById('tnu-start-btn');
                if (btnStart && !window.__tnu_downloader.isRunning) {
                    btnStart.click();
                } else {
                    alert(`Đã bật chế độ ưu tiên tải lại ${errorDocs.length} công văn lỗi! Hãy bấm '▶ Bắt đầu tải' trên bảng điều khiển.`);
                }
            }
        };
    }

    document.getElementById('tnu-clear-logs-btn').onclick = async () => {
        if (confirm("Đồng chí có chắc chắn muốn xóa toàn bộ nhật ký đã lưu không?\n(Toàn bộ bộ nhớ đệm, tệp nhật ký trên máy tính và trạng thái nút bấm sẽ được đồng bộ làm mới hoàn toàn)")) {
            window.__tnu_logs = [];
            _fastLogIndexMap = new Map();
            _fastLogIndexLen = 0;
            try {
                localStorage.setItem('tnu_download_logs', JSON.stringify([]));
                localStorage.removeItem('tnu_download_logs');
            } catch(e) {}

            if (window.__tnu_dir_handle) {
                await saveAllLogsToDirectory();
            }

            updateCounts();
            if (typeof updateLastPageBadge === 'function') updateLastPageBadge();

            renderLogTable();

            try {
                const lb = getMainDocumentListbox();
                if (lb) {
                    delete lb.dataset.tnuHotPage;
                    lb.querySelectorAll('.tnu-hot-download-btn').forEach(btn => {
                        btn.dataset.status = 'READY';
                        btn.dataset.downloading = 'false';
                        btn.disabled = false;
                        btn.innerHTML = '<span class="tnu-hot-icon">⚡</span> <span class="tnu-hot-text">Tải về</span>';
                        btn.style.background = '#16a34a';
                        btn.style.borderColor = '#15803d';
                        btn.style.color = '#ffffff';
                        btn.title = 'Tải nhanh văn bản này (tự động đổi tên và lưu vào thư mục máy tính)';
                    });
                }
                if (typeof renderHotDownloadButtons === 'function') {
                    renderHotDownloadButtons();
                }
            } catch(e) {}

            window.__tnu_download_completed_time = 0;
            window.__tnu_last_download_completed_time = 0;
            window.__tnu_fs_saved_time = 0;
            window.__tnu_fs_saved_filename = null;

            showFolderNoticeToast("🧹 Đã xóa toàn bộ nhật ký và đồng bộ lại bộ nhớ đệm thành công!");
        }
    };

    const btnMinimize = document.getElementById('tnu-btn-minimize');
    const btnClosePanel = document.getElementById('tnu-btn-close-panel');
    const panelBody = document.getElementById('tnu-panel-body');

    function toggleMainPanel(forceState) {
        attachPanelsToDom();
        let p = document.getElementById('tnu-download-panel');
        const b = document.getElementById('tnu-launcher-bubble') || launcherBubble;
        const lModal = document.getElementById('tnu-log-modal');
        if (!p) return;

        const computedDisplay = window.getComputedStyle(p).display;
        const isCurrentlyHidden = (p.style.display === 'none' || computedDisplay === 'none' || p.offsetWidth === 0);
        const shouldShow = (typeof forceState === 'boolean') ? forceState : isCurrentlyHidden;

        p.style.display = shouldShow ? 'block' : 'none';
        if (shouldShow) {
            p.style.visibility = 'visible';
            p.style.opacity = '1';
            p.style.zIndex = '2147483647';
            if (b) b.style.display = 'none';
            const panelBody = document.getElementById('tnu-panel-body');
            const btnMin = document.getElementById('tnu-btn-minimize');
            if (panelBody) {

                if (btnMin) btnMin.innerText = (panelBody.style.display === 'none') ? '➕' : '➖';
            }
        } else {
            p.style.display = 'none';
            if (lModal) lModal.style.display = 'none';
            const gModal = document.getElementById('tnu-guide-modal');
            if (gModal) gModal.style.display = 'none';
            const oldB = document.getElementById('tnu-launcher-bubble');
            if (oldB) oldB.remove();
        }
        console.log(`[TNUE - vOffice Downloader] Bảng điều khiển đã ${shouldShow ? 'HIỆN' : 'ẨN (Nhấn F9 hoặc mở tiện ích Extension để mở lại)'}.`);
    }

    window.__tnu_toggle_panel = toggleMainPanel;
    window.tnuToggle = toggleMainPanel;
    window.tnuShow = () => toggleMainPanel(true);
    window.tnuHide = () => toggleMainPanel(false);

    window.addEventListener("keydown", (e) => {
        if (e.key === "F9" || (e.ctrlKey && e.shiftKey && (e.key === "U" || e.key === "u"))) {
            e.preventDefault();
            toggleMainPanel();
        } else if (e.key === "Escape") {
            closeLogModal();
            closeGuideModal();
        }
    });

    window.addEventListener("message", (event) => {
        if (!event.data) return;
        if (event.data.type === "TNU_TOGGLE_PANEL") {
            toggleMainPanel(event.data.forceShow);
        }
    });

    if (btnMinimize && panelBody) {
        btnMinimize.onmouseover = () => { btnMinimize.style.background = 'rgba(255,255,255,0.2)'; };
        btnMinimize.onmouseout = () => { btnMinimize.style.background = 'transparent'; };
        btnMinimize.onclick = () => {
            const isCollapsed = (panelBody.style.display === 'none');
            panelBody.style.display = isCollapsed ? 'block' : 'none';
            btnMinimize.innerText = isCollapsed ? '➖' : '➕';
        };
    }

    if (btnClosePanel) {
        btnClosePanel.onmouseover = () => { btnClosePanel.style.background = 'rgba(255,255,255,0.2)'; };
        btnClosePanel.onmouseout = () => { btnClosePanel.style.background = 'transparent'; };
        btnClosePanel.onclick = () => {
            toggleMainPanel(false);
        };
    }

    const btnPickDir = document.getElementById('tnu-btn-pick-dir');
    const dirBadge = document.getElementById('tnu-dir-badge');
    const selectedDirInfo = document.getElementById('tnu-selected-dir-info');
    const pickLabel = document.getElementById('tnu-pick-label');

    function updateDirectoryUI(dirName) {
        if (dirName) {
            if (dirBadge) {
                dirBadge.innerText = "✔ Đã chọn";
                dirBadge.style.background = "#dcfce7";
                dirBadge.style.color = "#15803d";
            }
            if (pickLabel) pickLabel.innerText = "Đổi thư mục khác";
            if (selectedDirInfo) selectedDirInfo.innerHTML = `Đã chọn: <strong style="color: #15803d;">${dirName}</strong>`;
        } else {
            if (dirBadge) {
                dirBadge.innerText = "Chưa chọn";
                dirBadge.style.background = "#fee2e2";
                dirBadge.style.color = "#991b1b";
            }
            if (pickLabel) pickLabel.innerText = "Chọn thư mục lưu trên máy tính";
            if (selectedDirInfo) selectedDirInfo.innerHTML = `Mặc định: Downloads/TNUE_Vanban/`;
        }
    }

    if (window.__tnu_dir_handle) {
        updateDirectoryUI(window.__tnu_dir_handle.name);
    }

    async function pickSaveDirectory() {
        try {
            const handle = await window.showDirectoryPicker({
                mode: 'readwrite',
                startIn: 'documents'
            });
            window.__tnu_dir_handle = handle;
            await saveDirectoryHandleToIDB(handle);
            updateDirectoryUI(handle.name);
            await syncLogsFromDiskDirectory(handle, true);
            updateLastPageBadge();
            if (typeof renderLogTable === 'function') renderLogTable();
            if (typeof scheduleHotButtonRender === 'function') scheduleHotButtonRender(50);
            setStatus(`Đã kết nối thư mục [${handle.name}] và nạp ${(window.__tnu_logs || []).length} bản ghi nhật ký.`);
            if (window.__tnu_logs && window.__tnu_logs.length > 0) {
                await saveAllLogsToDirectory();
            }
            return handle;
        } catch (err) {
            if (err.name !== 'AbortError') alert("Lỗi khi chọn thư mục: " + err.message);
            return null;
        }
    }
    btnPickDir.onclick = () => pickSaveDirectory();

    (async () => {
        try {
            const savedHandle = await loadDirectoryHandleFromIDB();
            if (savedHandle) {
                window.__tnu_dir_handle = savedHandle;
                updateDirectoryUI(savedHandle.name);
                await syncLogsFromDiskDirectory(savedHandle, false);
                updateLastPageBadge();
            }
        } catch(e) {}
    })();

    document.getElementById('tnu-year-select')?.addEventListener('change', updateLastPageBadge);
    document.getElementById('tnu-month-select')?.addEventListener('change', updateLastPageBadge);

    const setStatus = (msg) => {
        const el = document.getElementById('tnu-status');
        if (el) { el.innerHTML = msg; el.scrollTop = el.scrollHeight; }
        console.log(`[TNUE - vOffice Downloader] ${msg.replace(/<[^>]*>/g, '')}`);
    };

    const updateCounts = () => {
        const c = document.getElementById('tnu-count');
        const s = document.getElementById('tnu-skipped');
        const e = document.getElementById('tnu-error');

        const countSuccess = (window.__tnu_logs || []).filter(l => l.trangThai === 'THÀNH CÔNG').length;
        const countSkip = (window.__tnu_logs || []).filter(l => l.trangThai === 'BỎ QUA').length;
        const countErr = (window.__tnu_logs || []).filter(l => l.trangThai === 'LỖI').length;

        window.__tnu_downloader.totalDownloaded = countSuccess;
        window.__tnu_downloader.totalSkipped = countSkip;
        window.__tnu_downloader.totalError = countErr;

        if (c) c.innerText = countSuccess;
        if (s) s.innerText = countSkip;
        if (e) e.innerText = countErr;
    };
    updateCounts();

    const closeAnyOpenModals = async () => {
        await closeAllModalsAndPopups();
    };

    const countdownSleep = async (totalMs, prefixMsg = "") => {
        const totalSec = Math.round(totalMs / 1000);
        for (let s = totalSec; s > 0; s--) {
            if (!window.__tnu_downloader.isRunning) break;
            while (window.__tnu_downloader.isPaused) {
                setStatus('⏸ Đang tạm dừng... Bấm "Tiếp tục" để chạy tiếp.');
                await new Promise(r => setTimeout(r, 800));
                if (!window.__tnu_downloader.isRunning) break;
            }
            setStatus(`${prefixMsg}Nghỉ ${s}s để bảo vệ máy chủ...`);
            await new Promise(r => setTimeout(r, 1000));
        }
    };

    const checkFileExists = async (dirHandle, filename) => {
        if (!dirHandle) return false;
        try {
            const fileHandle = await dirHandle.getFileHandle(filename);
            const file = await fileHandle.getFile();

            return file.size > 0;
        } catch (e) {
            return false;
        }
    };

    async function saveBlobToDirectory(dirHandle, filename, data) {
        const fileHandle = await dirHandle.getFileHandle(filename, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(data);
        await writable.close();
    };

    function getMainDocumentListbox() {

        if (document.querySelector('.z-window-modal, .z-modal-mask, .z-window-highlighted, .z-window-overlapped')) {
            return null;
        }

        const activeTabpanel = document.querySelector('.z-tabbox .z-tabpanel:not([style*="display: none"]):not([style*="display:none"])') ||
                               document.querySelector('.z-tabpanel:not([style*="display: none"]):not([style*="display:none"])');
        if (!activeTabpanel) return null;

        if (activeTabpanel.closest('.z-window, .z-popup, div[class*="window"]:not(.z-window-embedded)')) {
            return null;
        }

        const candidateListboxes = Array.from(activeTabpanel.querySelectorAll('.z-listbox')).filter(lb => {
            if (!lb.isConnected) return false;
            if (lb.closest('#tnu-download-panel, #tnu-log-modal, #tnu-guide-modal')) return false;
            if (lb.closest('.z-window, .z-popup, .z-messagebox')) return false;
            const headers = lb.querySelectorAll('.z-listheader');
            return headers.length >= 3;
        });

        return candidateListboxes[0] || null;
    }

    function getVisibleTableRows() {
        const lb = getMainDocumentListbox();
        if (lb) {
            return Array.from(lb.querySelectorAll('tr.z-listitem')).filter(r => {
                if (!r.isConnected) return false;
                const c = r.querySelectorAll('.z-listcell, td');
                return c.length >= 3;
            });
        }

        if (document.querySelector('.z-window-modal, .z-modal-mask, .z-window-highlighted, .z-window-overlapped')) {
            return [];
        }

        const candidateListboxes = Array.from(document.querySelectorAll('.z-listbox')).filter(l => {
            if (!l.isConnected) return false;
            if (l.closest('#tnu-download-panel, #tnu-log-modal, #tnu-guide-modal')) return false;
            if (l.closest('.z-window, .z-popup, .z-messagebox, div[class*="window"]:not(.z-window-embedded)')) return false;
            const headers = l.querySelectorAll('.z-listheader');
            if (headers.length < 3) return false;
            const style = window.getComputedStyle(l);
            return style.display !== 'none' && style.visibility !== 'hidden' && l.offsetParent !== null;
        });

        if (candidateListboxes.length === 0) return [];
        return Array.from(candidateListboxes[0].querySelectorAll('tr.z-listitem')).filter(r => {
            if (!r.isConnected) return false;
            const c = r.querySelectorAll('.z-listcell, td');
            return c.length >= 3;
        });
    }

    function getSortDirection(th) {
        if (!th) return '';
        try {
            const wgt = window.zk?.Widget?.$(th);
            if (wgt) {
                const dir = (wgt._sortDirection || (typeof wgt.getSortDirection === 'function' ? wgt.getSortDirection() : '') || '').toLowerCase();
                if (dir === 'descending' || dir === 'desc') return 'descending';
                if (dir === 'ascending' || dir === 'asc') return 'ascending';
            }
        } catch(e) {}

        const cls = (th.className || '').toLowerCase();
        if (cls.includes('-desc') || cls.includes('sort-desc') || cls.includes('descending')) return 'descending';
        if (cls.includes('-asc') || cls.includes('sort-asc') || cls.includes('ascending')) return 'ascending';

        if (th.querySelector('.z-icon-caret-down, .z-icon-sort-down, .z-icon-sort-desc, .fa-sort-down, .fa-sort-desc, .fa-caret-down')) return 'descending';
        if (th.querySelector('.z-icon-caret-up, .z-icon-sort-up, .z-icon-sort-asc, .fa-sort-up, .fa-sort-asc, .fa-caret-up')) return 'ascending';

        return 'none';
    }

    function triggerSortClick(th) {
        if (!th) return;
        const clickTarget = th.querySelector('.z-listheader-content, .z-column-content, a, span') || th;
        try {
            const wgt = window.zk?.Widget?.$(th);
            if (wgt && window.zUtl?.sendEvent) {
                window.zUtl.sendEvent(wgt, 'onSort');
            } else if (wgt && typeof wgt.fire === 'function') {
                wgt.fire('onSort', {});
            }
        } catch(e) {}
        triggerClick(clickTarget);
    }

    async function ensureTableSortedNewestFirst() {
        try {
            const lb = getMainDocumentListbox() ||
                       document.querySelector('.z-tabpanel:not([style*="display: none"]) .z-listbox') ||
                       document.querySelector('.z-listbox');
            if (!lb) return false;

            const headerCells = Array.from(lb.querySelectorAll('.z-listheader, th.z-column, th'));
            if (headerCells.length === 0) return false;

            let dateHeaderIndex = headerCells.findIndex(th => {
                const txt = ((th.innerText || '') + ' ' + (th.getAttribute('title') || '') + ' ' + (th.getAttribute('aria-label') || '')).toLowerCase();
                return txt.includes('ngày ban hành') || txt.includes('ngày ký') || txt.includes('ngày vb') || txt.includes('ngày văn bản');
            });

            if (dateHeaderIndex === -1) {
                dateHeaderIndex = headerCells.findIndex(th => {
                    const txt = ((th.innerText || '') + ' ' + (th.getAttribute('title') || '') + ' ' + (th.getAttribute('aria-label') || '')).toLowerCase();
                    return txt.includes('ngày đến') || txt.includes('ngày gửi') || txt.includes('ngày nhận');
                });
            }

            if (dateHeaderIndex === -1) {
                console.log("[TNUE] Không tìm thấy cột ngày trong bảng để tự động sắp xếp.");
                return false;
            }

            const dateHeader = headerCells[dateHeaderIndex];
            const headerTitle = (dateHeader.innerText || dateHeader.getAttribute('title') || 'Ngày ban hành').trim().replace(/\s+/g, ' ');

            let currentDir = getSortDirection(dateHeader);
            if (currentDir === 'descending') {
                appendStepLog(`⚡ [SẮP XẾP] Cột "${headerTitle}" đã ở trạng thái MỚI NHẤT ➔ CŨ NHẤT (Descending).`);
                return true;
            }

            appendStepLog(`⚡ [TỰ ĐỘNG SẮP XẾP] Đang kích hoạt sắp xếp cột "${headerTitle}" từ Mới nhất ➔ Cũ nhất...`);
            setStatus(`Đang tự động sắp xếp cột "${headerTitle}" từ Mới nhất ➔ Cũ nhất...`);

            triggerSortClick(dateHeader);
            await new Promise(r => setTimeout(r, 2000));

            currentDir = getSortDirection(dateHeader);
            if (currentDir === 'ascending') {

                appendStepLog(`⚡ Chuyển đổi hướng sắp xếp sang Mới nhất ➔ Cũ nhất (Descending)...`);
                triggerSortClick(dateHeader);
                await new Promise(r => setTimeout(r, 2000));
            }

            appendStepLog(`✔ [SẮP XẾP XONG] Đã hoàn tất kiểm tra và sắp xếp danh sách từ Mới nhất ➔ Cũ nhất!`);
            setStatus(`✔ Danh sách đã được sắp xếp từ Mới nhất ➔ Cũ nhất.`);
            return true;
        } catch(errSort) {
            console.warn("[TNUE] Lỗi khi cố gắng tự động sắp xếp bảng:", errSort);
            return false;
        }
    }

    async function processSingleRow(row, pageIndex, i, totalRows, options = {}) {
        const { selectedYear = 'ALL', selectedMonth = 'ALL', partyMode = 'ALL', skipExisting = true, isRetryMode = false } = options;
        if (!row || !row.isConnected) return false;

        window.__tnu_user_aborted = false;
        window.__tnu_download_canceled = false;

        const rowData = extractRowDataSmart(row, pageIndex, i + 1);
        if (!rowData) return false;

        const { sttDoc, soKyHieuRaw, trichYeuRaw, ngayBanHanhFull, donViBanHanhRaw, docMonth, docYear, trichYeuCell, cells } = rowData;

        const isParty = isPartyDocument(rowData);
        if (partyMode === 'EXCLUDE_PARTY' && isParty) {
            setStatus(`[${i+1}/${totalRows}] Bỏ qua dòng (Chế độ Không tải công văn Đảng: ${donViBanHanhRaw || soKyHieuRaw})`);
            return false;
        }
        if (partyMode === 'ONLY_PARTY' && !isParty) {
            setStatus(`[${i+1}/${totalRows}] Bỏ qua dòng (Chế độ Chỉ tải công văn Đảng: Không thuộc khối Đảng)`);
            return false;
        }

        if (!isRetryMode) {
            if (selectedYear !== 'ALL' && docYear && docYear !== selectedYear) {
                setStatus(`[${i+1}/${totalRows}] Bỏ qua dòng (Năm ${docYear} ≠ ${selectedYear})`);
                return false;
            }
            if (selectedMonth !== 'ALL' && docMonth > 0 && docMonth !== parseInt(selectedMonth, 10)) {
                setStatus(`[${i+1}/${totalRows}] Bỏ qua dòng (Tháng ${docMonth} ≠ Tháng ${selectedMonth})`);
                return false;
            }
        }

        let titleFull = buildWindowsSafeFilename(soKyHieuRaw, trichYeuRaw, ngayBanHanhFull, pageIndex, i + 1);
        const logPrefix = `[Trang ${pageIndex} - ${i+1}/${totalRows}${isRetryMode ? " (Tải lại)" : ""}] `;
        appendStepLog(`--- BẮT ĐẦU XỬ LÝ DÒNG ${i+1}/${totalRows}${isRetryMode ? " (ƯU TIÊN TẢI LẠI VĂN BẢN LỖI)" : ""} ---`);
                appendStepLog(`[Dòng ${i+1}] Nhận diện: Số ký hiệu="${soKyHieuRaw}", Ngày="${ngayBanHanhFull}", Trích yếu="${trichYeuRaw.substring(0, 50)}..."`);

                const existingLogIdx = findExistingLogIndex(window.__tnu_logs, {
                    soKyHieu: soKyHieuRaw,
                    trichYeu: trichYeuRaw,
                    tenFile: `${titleFull}.pdf`,
                    ngayBanHanh: ngayBanHanhFull,
                    nam: docYear
                });
                const isPreviouslyFailed = (existingLogIdx >= 0 && window.__tnu_logs[existingLogIdx].trangThai === 'LỖI');

                let effectiveRetryMode = isRetryMode;
                if (isPreviouslyFailed) {
                    effectiveRetryMode = true;
                    appendStepLog(`🔄 [TỰ ĐỘNG TẢI LẠI LỖI] Phát hiện công văn [Dòng ${i+1}]: "${soKyHieuRaw}" từng có trạng thái LỖI (ID: ${window.__tnu_logs[existingLogIdx].id}). Tự động kích hoạt tải lại...`);
                }

                if (skipExisting && !effectiveRetryMode) {
                    let isAlreadyDownloaded = false;
                    let existingType = "PDF";

                    if (window.__tnu_dir_handle) {
                        const existsPdf = await checkFileExists(window.__tnu_dir_handle, `${titleFull}.pdf`);
                        const existsZip = await checkFileExists(window.__tnu_dir_handle, `${titleFull}.zip`);
                        if (existsPdf || existsZip) {
                            isAlreadyDownloaded = true;
                            existingType = existsPdf ? "PDF" : "ZIP";
                        }
                    }

                    if (!isAlreadyDownloaded && isDocumentAlreadySuccessInLogs(soKyHieuRaw, trichYeuRaw, titleFull, ngayBanHanhFull)) {
                        isAlreadyDownloaded = true;
                    }

                    if (isAlreadyDownloaded) {
                        setStatus(`${logPrefix}Đã tải trước đó ("${titleFull}"). Tự động bỏ qua.`);
                        appendStepLog(`Bỏ qua dòng ${i+1}: Văn bản đã tải thành công trước đó.`);
                        const existIdx = findExistingLogIndex(window.__tnu_logs, {
                            tenFile: `${titleFull}.${existingType.toLowerCase()}`,
                            soKyHieu: soKyHieuRaw,
                            trichYeu: trichYeuRaw,
                            ngayBanHanh: ngayBanHanhFull,
                            nam: docYear
                        });
                        if (existIdx === -1) {
                            await recordDocLog({
                                stt: sttDoc,
                                trang: pageIndex,
                                soKyHieu: soKyHieuRaw,
                                trichYeu: trichYeuRaw,
                                ngayBanHanh: ngayBanHanhFull,
                                nam: docYear,
                                thang: docMonth,
                                loaiFile: existingType,
                                tenFile: `${titleFull}.${existingType.toLowerCase()}`,
                                dungLuongMb: 1.0,
                                trangThai: "THÀNH CÔNG",
                                lyDoLoi: ""
                            });
                        }
                        return false;
                    }
                }

                let downloadSuccess = false;
                let lastErrorReason = "";

                await closeAllModalsAndPopups();
                await closePdfViewerWindow();

                setStatus(`${logPrefix}Đang mở chi tiết văn bản: ${titleFull.substring(0, 35)}...`);
                appendStepLog(`Đang mở chi tiết văn bản [Dòng ${i+1}]: "${titleFull}"...`);

                const targetDbl = trichYeuCell?.querySelector('.z-listcell-content') || trichYeuCell || row;
                const trichYeuLink = trichYeuCell?.querySelector('a, span.z-html, span.z-label') || row.querySelector('a, span.z-html, span.z-label');
                const xemThem = Array.from(row.querySelectorAll('a, span, div, button, i')).find(el => {
                    const t = (el.innerText || '').trim().toLowerCase();
                    const title = (el.getAttribute('title') || '').toLowerCase();
                    const cls = (el.className || '').toString().toLowerCase();
                    return t.includes('xem thêm') || t.includes('xem them') || t.includes('chi tiết') ||
                           title.includes('xem thêm') || title.includes('chi tiết') ||
                           cls.includes('fa-paperclip') || cls.includes('fa-ellipsis-h');
                });

                try {
                    const wgt = window.zk?.Widget?.$(targetDbl) || window.zk?.Widget?.$(row);
                    if (wgt && window.zUtl?.sendEvent) {
                        window.zUtl.sendEvent(wgt, 'onDoubleClick');
                    } else if (wgt && wgt.fire) {
                        wgt.fire('onDoubleClick', {});
                    }
                    targetDbl.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }));
                    row.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }));
                } catch(eDbl) {}

                if (trichYeuLink && trichYeuLink !== row) {
                    triggerClick(trichYeuLink);
                }

                let detailModal = null;
                for (let w = 0; w < 30; w++) {
                    await new Promise(r => setTimeout(r, 250));

                    const currentModals = Array.from(document.querySelectorAll(
                        '.z-window-modal, .z-window-highlighted, .z-window-overlapped, .z-window-popup, .z-window, .z-popup, div[class*="z-window"]'
                    )).filter(m => {
                        if (!m || !m.isConnected) return false;
                        if (m.id && (m.id.includes('tnu-download-panel') || m.id.includes('tnu-log-modal'))) return false;
                        if (m.classList.contains('z-window-embedded') && !m.classList.contains('z-window-modal')) return false;
                        const isVisible = m.offsetParent !== null ||
                                          (window.getComputedStyle(m).display !== 'none' && window.getComputedStyle(m).visibility !== 'hidden');
                        return isVisible;
                    });

                    detailModal = currentModals.find(m => {
                        const txt = (m.innerText || '').toLowerCase();
                        const hasDetailKeywords = txt.includes('chi tiết') || txt.includes('văn bản') ||
                                                  txt.includes('file đính kèm') || txt.includes('tài liệu') ||
                                                  txt.includes('trích yếu') || txt.includes('số ký hiệu');
                        const hasWindowControls = m.querySelector('.z-window-header, .z-window-close, [id$="-close"], .z-window-icon, button');
                        return hasDetailKeywords || hasWindowControls;
                    }) || currentModals[0];

                    if (detailModal) break;

                    if (w === 6 || w === 14) {
                        if (xemThem) triggerClick(xemThem);
                        else {
                            triggerClick(targetDbl);
                            targetDbl.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }));
                        }
                    }
                }

                if (detailModal) {
                    appendStepLog(`[Dòng ${i+1}] Đã mở thành công cửa sổ chi tiết văn bản!`);

                    const modalTrichYeu = extractTrichYeuFromDetailModal(detailModal);
                    if (modalTrichYeu && (isLikelyOrganizationName(trichYeuRaw) || !trichYeuRaw || trichYeuRaw.length < 5 || modalTrichYeu.length > trichYeuRaw.length + 10)) {
                        appendStepLog(`[Dòng ${i+1}] 🎯 Phát hiện Trích yếu chuẩn từ cửa sổ chi tiết: "${modalTrichYeu.substring(0, 50)}..." (Thay thế: "${trichYeuRaw.substring(0, 50)}...")`);
                        trichYeuRaw = modalTrichYeu;
                        titleFull = buildWindowsSafeFilename(soKyHieuRaw, trichYeuRaw, ngayBanHanhFull, pageIndex, i + 1);
                    }

                    setupMultiLayerDownloadCapture();
                    window.__tnu_captured_url = null;
                    window.__tnu_download_completed_time = 0;
                    window.__tnu_fs_saved_time = 0;
                    window.__tnu_fs_saved_filename = null;

                    const modalAttachments = extractModalAttachments(detailModal);
                    const isSinglePdfDetected = (modalAttachments.length === 1 && modalAttachments[0].isPdf);

                    appendStepLog(`Quét danh sách tệp thực tế: Phát hiện ${modalAttachments.length} tệp [${modalAttachments.map(m => m.name).join(', ')}] -> Kết luận: ${isSinglePdfDetected ? "CÔNG VĂN 1 FILE PDF" : "CÔNG VĂN NHIỀU FILE / ZIP"}`);

                    if (isSinglePdfDetected) {
                        const singleFile = modalAttachments[0];
                        const singleFileName = singleFile ? singleFile.name : "van_ban.pdf";
                        setStatus(`${logPrefix}Phát hiện công văn 1 file PDF: "${singleFileName}". Đang tải trực tiếp PDF...`);

                        window.postMessage({
                            type: "TNU_SET_PENDING_RENAME",
                            filename: `${titleFull}.pdf`,
                            folder: window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "TNUE_Vanban",
                            hasDirHandle: Boolean(window.__tnu_dir_handle),
                            isSinglePdf: true
                        }, "*");

                        let targetEl = singleFile.elements.find(el => el.tagName === 'A' || el.tagName === 'BUTTON' || el.getAttribute('href') || el.closest('a')) || singleFile.elements[0];
                        const fileRow = targetEl ? (targetEl.closest('tr.z-listitem, tr.z-row') ||
                                       targetEl.closest('div.z-hlayout, div.z-vlayout, table, tbody') ||
                                       targetEl.parentElement) : null;
                        const fileBox = targetEl ? (targetEl.closest('.z-listbox, .z-grid, table, .z-vlayout') || detailModal) : detailModal;

                        const isDlButton = (el) => {
                            if (!el) return false;
                            const title = (el.getAttribute('title') || '').trim().toLowerCase();
                            const txt = (el.innerText || '').trim().toLowerCase();
                            const cls = (el.className || '').toString().toLowerCase();
                            if (title.includes('tất cả') || txt.includes('tất cả') || title.includes('đóng') || txt === 'đóng') return false;
                            return cls.includes('fa-download') || cls.includes('z-icon-download') || cls.includes('fa-arrow-down') ||
                                   title.includes('tải về') || title.includes('tải xuống') || title.includes('download') ||
                                   txt === 'tải về' || txt === 'tải xuống' || txt === 'download';
                        };

                        let singleDlBtn = null;
                        if (fileRow) {
                            const candidates = Array.from(fileRow.querySelectorAll('a, button, .z-button, [role="button"], i, span'));
                            const match = candidates.find(isDlButton);
                            if (match) singleDlBtn = match.closest('a, button, .z-button, [role="button"]') || match;
                        }
                        if (!singleDlBtn && fileBox) {
                            const candidates = Array.from(fileBox.querySelectorAll('a, button, .z-button, [role="button"], i, span'));
                            const match = candidates.find(isDlButton);
                            if (match) singleDlBtn = match.closest('a, button, .z-button, [role="button"]') || match;
                        }
                        if (!singleDlBtn) {

                            const allRows = Array.from(detailModal.querySelectorAll('tr, .z-row, .z-listitem, div.z-hlayout'));
                            const attachRow = allRows.find(r => {
                                const t = (r.innerText || '').toLowerCase();
                                return t.includes('file đính kèm') || t.includes('tệp đính kèm') || t.includes('tài liệu đính kèm');
                            });
                            if (attachRow) {
                                const candidates = Array.from(attachRow.querySelectorAll('a, button, .z-button, [role="button"], i, span'));
                                const match = candidates.find(isDlButton);
                                if (match) singleDlBtn = match.closest('a, button, .z-button, [role="button"]') || match;
                            }
                        }
                        if (!singleDlBtn) {
                            const candidates = Array.from(detailModal.querySelectorAll('a, button, .z-button, [role="button"], i, span'));
                            const match = candidates.find(isDlButton);
                            if (match) singleDlBtn = match.closest('a, button, .z-button, [role="button"]') || match;
                        }

                        let directPdfUrl = targetEl ? (targetEl.getAttribute('href') || targetEl.getAttribute('data-url')) : null;
                        if (directPdfUrl && (directPdfUrl.includes('task=view') || directPdfUrl.includes('securityservlet'))) {
                            directPdfUrl = directPdfUrl.replace('task=view', 'task=download');
                        }

                        if (directPdfUrl && (directPdfUrl.includes('.pdf') || directPdfUrl.includes('task=download'))) {
                            appendStepLog(`Tìm thấy link tải PDF trực tiếp: ${directPdfUrl.substring(0, 60)}...`);
                            try {
                                const directBlob = await fetchPdfWithMultiFallback(directPdfUrl);
                                const finalFilename = `${titleFull}.pdf`;
                                const saveRes = await saveFileDirectlyOrBridge(finalFilename, directBlob, normalizeVofficeUrl(directPdfUrl));
                                if (saveRes && saveRes.success) {
                                    downloadSuccess = true;
                                }
                            } catch(eFetchDirect) {
                                console.warn("[TNUE] Lỗi fetch link PDF trực tiếp:", eFetchDirect);
                            }
                        } else if (singleDlBtn) {
                            appendStepLog(`Bấm đúng nút tải riêng file PDF: [${singleDlBtn.tagName || ''} - ${singleDlBtn.className || ''}]`);
                            window.__tnu_captured_url = null;
                            const clickTime = Date.now();
                            triggerClick(singleDlBtn);

                            for (let w = 0; w < 30; w++) {
                                await new Promise(r => setTimeout(r, 500));
                                if (window.__tnu_user_aborted || window.__tnu_download_canceled) {
                                    appendStepLog(`⚠️ Người dùng đã hủy tải tệp / đóng cửa sổ chi tiết.`);
                                    break;
                                }
                                autoConfirmSecurityDialog();

                                if (window.__tnu_dir_handle) {
                                    if (window.__tnu_fs_saved_time && window.__tnu_fs_saved_time >= clickTime) {
                                        appendStepLog(`✔ Đã lưu trực tiếp file PDF vào thư mục chỉ định [${window.__tnu_dir_handle.name}]`);
                                        downloadSuccess = true;
                                        break;
                                    }
                                } else {
                                    if (window.__tnu_download_completed_time && window.__tnu_download_completed_time >= clickTime) {
                                        appendStepLog(`✔ Extension background đã tải xong file PDF vào thư mục TNUE_Vanban/`);
                                        downloadSuccess = true;
                                        break;
                                    }
                                }

                                if (window.__tnu_captured_url) {
                                    const capturedUrl = window.__tnu_captured_url;
                                    window.__tnu_captured_url = null;
                                    appendStepLog(`Bắt được URL tải PDF: ${capturedUrl.substring(0, 60)}...`);
                                    try {
                                        const directBlob = await fetchPdfWithMultiFallback(capturedUrl);
                                        const finalFilename = `${titleFull}.pdf`;
                                        const saveRes = await saveFileDirectlyOrBridge(finalFilename, directBlob, normalizeVofficeUrl(capturedUrl));
                                        if (saveRes && saveRes.success) {
                                            downloadSuccess = true;
                                            break;
                                        }
                                    } catch(eFetchCap) {
                                        console.warn("[TNUE] Lỗi fetch PDF captured URL:", eFetchCap);
                                    }
                                }
                            }
                        }

                        if (!downloadSuccess) {
                            appendStepLog(`Kích hoạt nút Tải dữ liệu máy chủ để Background giải nén trực tiếp PDF trong RAM...`);
                            setStatus(`${logPrefix}Đang nạp gói dữ liệu để trích xuất file PDF nguyên bản...`);

                            window.postMessage({
                                type: "TNU_SET_PENDING_RENAME",
                                filename: `${titleFull}.pdf`,
                                folder: window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "TNUE_Vanban",
                                hasDirHandle: Boolean(window.__tnu_dir_handle),
                                isSinglePdf: true
                            }, "*");

                            const allBtns = Array.from(detailModal.querySelectorAll('button, .z-button, .z-toolbarbutton, a.z-a, [role="button"], span, div'));
                            let dlBtnFallback = allBtns.find(b => {
                                const txt = (b.innerText || '').trim().toLowerCase();
                                const title = (b.getAttribute('title') || '').trim().toLowerCase();
                                const cls = (b.className || '').toString().toLowerCase();
                                return /tải\s*(tất\s*cả|toàn\s*bộ|tệp|file|đính\s*kèm)/i.test(txt) ||
                                       /tải\s*(tất\s*cả|toàn\s*bộ|tệp|file|đính\s*kèm)/i.test(title) ||
                                       /download\s*all/i.test(txt) || /download\s*all/i.test(title) ||
                                       cls.includes('fa-cloud-download') || cls.includes('fa-download');
                            }) || detailModal.querySelector('.fa-cloud-download, .fa-download, [title*="tải" i]');

                            if (dlBtnFallback) {
                                const targetBtn = dlBtnFallback.closest('button, .z-button, .z-toolbarbutton, a') || dlBtnFallback;
                                window.__tnu_captured_url = null;
                                const clickTimeFallback = Date.now();
                                triggerClick(targetBtn);

                                for (let t = 0; t < 60; t++) {
                                    await new Promise(r => setTimeout(r, 500));
                                    if (window.__tnu_user_aborted || window.__tnu_download_canceled) {
                                        appendStepLog(`⚠️ Người dùng đã hủy tải tệp / đóng cửa sổ chi tiết.`);
                                        break;
                                    }
                                    autoConfirmSecurityDialog();

                                    if (window.__tnu_dir_handle) {
                                        if (window.__tnu_fs_saved_time && window.__tnu_fs_saved_time >= clickTimeFallback) {
                                            appendStepLog(`✔ Đã lưu xong file PDF vào thư mục chỉ định [${window.__tnu_dir_handle.name}]`);
                                            downloadSuccess = true;
                                            break;
                                        }
                                    } else {
                                        if (window.__tnu_download_completed_time && window.__tnu_download_completed_time >= clickTimeFallback) {
                                            appendStepLog(`✔ Background Service Worker đã giải nén xong PDF và lưu vào TNUE_Vanban/`);
                                            downloadSuccess = true;
                                            break;
                                        }
                                    }

                                    if (!window.__tnu_captured_url) {
                                        const activeIfr = document.querySelector('iframe#zk_download, iframe[name="zk_download"]');
                                        if (activeIfr && activeIfr.src && activeIfr.src !== 'about:blank') {
                                            window.__tnu_captured_url = activeIfr.src;
                                        }
                                    }

                                    if (window.__tnu_captured_url) {
                                        const capturedZipUrl = window.__tnu_captured_url;
                                        window.__tnu_captured_url = null;
                                        try {
                                            const zipBlob = await fetchPdfWithMultiFallback(capturedZipUrl);
                                            let finalBlob = zipBlob;
                                            let finalFilename = `${titleFull}.pdf`;

                                            if (zipBlob && zipBlob.size > 1000) {
                                                const zipInfo = await inspectAndExtractZip(zipBlob);
                                                if (zipInfo.isSinglePdf && zipInfo.pdfBlob) {
                                                    finalBlob = zipInfo.pdfBlob;
                                                    finalFilename = `${titleFull}.pdf`;
                                                }
                                            }

                                            const saveRes = await saveFileDirectlyOrBridge(finalFilename, finalBlob, finalBlob ? null : capturedZipUrl);
                                            if (saveRes && saveRes.success) {
                                                downloadSuccess = true;
                                                break;
                                            }
                                        } catch(eFetchZip) {
                                            console.warn("[TNUE] Lỗi fetch captured zip URL:", eFetchZip);
                                        }
                                    }
                                }
                            }
                        }

                        if (downloadSuccess) {
                            const finalFilename = `${titleFull}.pdf`;
                            setStatus(`${logPrefix}Đã lưu xong: ${finalFilename}`);
                            appendStepLog(`✔ [THÀNH CÔNG] Đã lưu file: "${finalFilename}" (100% PDF)`);
                            await recordDocLog({
                                stt: sttDoc,
                                trang: pageIndex,
                                soKyHieu: soKyHieuRaw,
                                trichYeu: trichYeuRaw,
                                ngayBanHanh: ngayBanHanhFull,
                                nam: docYear,
                                thang: docMonth,
                                loaiFile: "PDF",
                                tenFile: finalFilename,
                                dungLuongMb: 1.0,
                                trangThai: "THÀNH CÔNG",
                                lyDoLoi: ""
                            });
                        } else {
                            lastErrorReason = "Không tải được file PDF từ chi tiết văn bản";
                            appendStepLog(`❌ [LỖI] ${lastErrorReason}`);
                        }

                        await closeAllModalsAndPopups();
                    } else {

                        const countMsg = `${modalAttachments.length} tệp đính kèm`;
                        setStatus(`${logPrefix}Công văn có ${countMsg}. Đang chuẩn bị tải dữ liệu từ máy chủ...`);
                        appendStepLog(`[Dòng ${i+1}] Bắt đầu tải công văn nhiều file / ZIP (${countMsg})...`);

                        window.postMessage({
                            type: "TNU_SET_PENDING_RENAME",
                            filename: `${titleFull}.zip`,
                            folder: window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "TNUE_Vanban",
                            hasDirHandle: Boolean(window.__tnu_dir_handle),
                            isSinglePdf: false
                        }, "*");

                        const allBtns = Array.from(detailModal.querySelectorAll('button, .z-button, .z-toolbarbutton, a.z-a, [role="button"], span, div'));
                        let dlBtn = allBtns.find(b => {
                            const txt = (b.innerText || '').trim().toLowerCase();
                            const title = (b.getAttribute('title') || '').trim().toLowerCase();
                            const cls = (b.className || '').toString().toLowerCase();
                            return /tải\s*(tất\s*cả|toàn\s*bộ|tệp|file|đính\s*kèm)/i.test(txt) ||
                                   /tải\s*(tất\s*cả|toàn\s*bộ|tệp|file|đính\s*kèm)/i.test(title) ||
                                   /download\s*all/i.test(txt) || /download\s*all/i.test(title) ||
                                   cls.includes('fa-cloud-download') || cls.includes('fa-download');
                        }) || detailModal.querySelector('.fa-cloud-download, .fa-download-all, [title*="tất cả" i], [title*="tat ca" i]');

                        if (!dlBtn) {
                            const singleBtn = Array.from(detailModal.querySelectorAll('a, button, .z-button, [role="button"], i, span')).find(b => {
                                const title = (b.getAttribute('title') || '').trim().toLowerCase();
                                const txt = (b.innerText || '').trim().toLowerCase();
                                const cls = (b.className || '').toString().toLowerCase();
                                if (title.includes('đóng') || txt === 'đóng') return false;
                                return cls.includes('fa-download') || cls.includes('z-icon-download') || cls.includes('fa-arrow-down') ||
                                       title.includes('tải về') || title.includes('tải xuống') || title.includes('download') ||
                                       txt === 'tải về' || txt === 'tải xuống' || txt === 'download';
                            });
                            if (singleBtn) {
                                dlBtn = singleBtn.closest('a, button, .z-button, [role="button"]') || singleBtn;
                                appendStepLog(`Không có nút 'Tải tất cả', tự động chuyển sang nút Tải về riêng: [${dlBtn.tagName || ''} - ${dlBtn.className || ''}]`);
                            }
                        }

                        if (dlBtn) {
                            const targetBtn = dlBtn.closest('button, .z-button, .z-toolbarbutton, a') || dlBtn;
                            appendStepLog(`Bấm nút Tải tất cả tài liệu: [${targetBtn.innerText?.trim() || targetBtn.getAttribute('title') || targetBtn.className}]`);
                            window.__tnu_captured_url = null;
                            const clickTime = Date.now();
                            triggerClick(targetBtn);

                            const maxWaitSec = 60;
                            for (let t = 0; t < maxWaitSec * 2; t++) {
                                await new Promise(r => setTimeout(r, 500));
                                if (window.__tnu_user_aborted || window.__tnu_download_canceled) {
                                    appendStepLog(`⚠️ Người dùng đã hủy tải tệp / đóng cửa sổ chi tiết.`);
                                    break;
                                }
                                const elapsed = Math.round((t + 1) * 0.5);

                                if (t % 10 === 0) {
                                    window.postMessage({
                                        type: "TNU_SET_PENDING_RENAME",
                                        filename: `${titleFull}.zip`,
                                        folder: window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "TNUE_Vanban",
                                        hasDirHandle: Boolean(window.__tnu_dir_handle),
                                        isSinglePdf: false
                                    }, "*");
                                }

                                const confirmed = autoConfirmSecurityDialog();
                                if (confirmed) {
                                    setStatus(`${logPrefix}⚡ Đã xác nhận an toàn thông tin ("Có"), đang đợi máy chủ xuất gói dữ liệu... (${elapsed}s/${maxWaitSec}s)`);
                                } else {
                                    setStatus(`${logPrefix}Đang đợi máy chủ vOffice xuất gói dữ liệu... (${elapsed}s/${maxWaitSec}s)`);
                                }

                                if (window.__tnu_dir_handle) {
                                    if (window.__tnu_fs_saved_time && window.__tnu_fs_saved_time >= clickTime) {
                                        appendStepLog(`✔ Đã lưu xong gói dữ liệu vào thư mục chỉ định [${window.__tnu_dir_handle.name}]`);
                                        downloadSuccess = true;
                                        break;
                                    }
                                } else {
                                    if (window.__tnu_download_completed_time && window.__tnu_download_completed_time >= clickTime) {
                                        appendStepLog(`✔ Extension background đã tải xong gói ZIP vào thư mục TNUE_Vanban/`);
                                        downloadSuccess = true;
                                        break;
                                    }
                                }

                                if (!window.__tnu_captured_url) {
                                    const activeIfr = document.querySelector('iframe#zk_download, iframe[name="zk_download"], iframe[src*="securityservlet"], iframe[src*="task=download"], iframe[src*="task=view"], iframe[src*=".zip"], iframe[src*=".pdf"]');
                                    if (activeIfr && activeIfr.src && activeIfr.src !== 'about:blank') {
                                        window.__tnu_captured_url = activeIfr.src;
                                    }
                                }

                                if (window.__tnu_captured_url) {
                                    const capturedUrl = window.__tnu_captured_url;
                                    window.__tnu_captured_url = null;
                                    appendStepLog(`Bắt được URL gói dữ liệu: ${capturedUrl.substring(0, 60)}...`);

                                    const fullUrl = new URL(capturedUrl, window.location.origin).href;
                                    try {
                                        const fetchedBlob = await fetchPdfWithMultiFallback(fullUrl);
                                        const blob = fetchedBlob || (await (await fetch(fullUrl, { credentials: 'include' })).blob());

                                        let finalBlob = blob;
                                        let finalFilename = `${titleFull}.zip`;
                                        let fileType = "ZIP";

                                        if (blob && (blob.type === 'application/pdf' || fullUrl.toLowerCase().includes('.pdf'))) {
                                            finalFilename = `${titleFull}.pdf`;
                                            fileType = "PDF";
                                        } else if (blob && blob.size > 1000) {
                                            const zipInfo = await inspectAndExtractZip(blob);
                                            if (zipInfo.isSinglePdf && zipInfo.pdfBlob) {
                                                appendStepLog(`🎯 Phát hiện gói zip chỉ có duy nhất 1 file PDF (${zipInfo.filename}) -> Giải nén lưu PDF nguyên bản!`);
                                                finalBlob = zipInfo.pdfBlob;
                                                finalFilename = `${titleFull}.pdf`;
                                                fileType = "PDF";
                                            }
                                        }

                                        const saveRes = await saveFileDirectlyOrBridge(finalFilename, finalBlob, finalBlob ? null : fullUrl);
                                        if (saveRes && saveRes.success) {
                                            downloadSuccess = true;
                                            break;
                                        }
                                    } catch(errFetch) {
                                        console.warn("[TNUE] Lỗi fetch gói dữ liệu:", errFetch);
                                    }
                                }
                            }

                            if (downloadSuccess) {
                                const finalFilename = `${titleFull}.zip`;
                                setStatus(`${logPrefix}Đã lưu xong: ${finalFilename}`);
                                appendStepLog(`✔ [THÀNH CÔNG] Đã lưu xong gói dữ liệu: "${finalFilename}"`);
                                await recordDocLog({
                                    stt: sttDoc,
                                    trang: pageIndex,
                                    soKyHieu: soKyHieuRaw,
                                    trichYeu: trichYeuRaw,
                                    ngayBanHanh: ngayBanHanhFull,
                                    nam: docYear,
                                    thang: docMonth,
                                    loaiFile: "ZIP",
                                    tenFile: finalFilename,
                                    dungLuongMb: 1.0,
                                    trangThai: "THÀNH CÔNG",
                                    lyDoLoi: ""
                                });
                            } else {
                                lastErrorReason = `Máy chủ vOffice không xuất gói dữ liệu sau ${maxWaitSec}s (Timeout)`;
                                appendStepLog(`❌ [LỖI] ${lastErrorReason}`);
                            }
                        } else {
                            lastErrorReason = "Không tìm thấy nút 'Tải tất cả file' trong cửa sổ chi tiết";
                            appendStepLog(`❌ [LỖI] ${lastErrorReason}`);
                        }

                        await closeAllModalsAndPopups();
                    }
                } else {
                    lastErrorReason = "Không mở được cửa sổ chi tiết văn bản";
                    appendStepLog(`❌ [LỖI] ${lastErrorReason}`);
                }

                if (!downloadSuccess) {
                    await recordDocLog({
                        stt: sttDoc,
                        trang: pageIndex,
                        soKyHieu: soKyHieuRaw,
                        trichYeu: trichYeuRaw,
                        ngayBanHanh: ngayBanHanhFull,
                        nam: docYear,
                        thang: docMonth,
                        loaiFile: "PDF/ZIP",
                        tenFile: `${titleFull}.pdf`,
                        dungLuongMb: 0,
                        trangThai: "LỖI",
                        lyDoLoi: lastErrorReason || "Tải không thành công"
                    });
                }

                await closeAllModalsAndPopups();

                if (!options.skipDelay) {
                    const baseDelay = parseInt(document.getElementById('tnu-delay-select')?.value || "16000", 10);
                    await countdownSleep(baseDelay, `${logPrefix}✔ `);
                }
        return downloadSuccess;
    }

    const startProcess = async () => {
        setupMultiLayerDownloadCapture();

        if (!window.__tnu_dir_handle) {
            console.log("ℹ [TNUE] Chưa chọn thư mục riêng -> tự động lưu vào thư mục mặc định: Downloads/TNUE_Vanban/");
        }

        window.__tnu_downloader.isRunning = true;
        window.__tnu_downloader.isPaused = false;

        document.getElementById('tnu-btn-start').style.display = 'none';
        document.getElementById('tnu-btn-pause').style.display = 'block';
        document.getElementById('tnu-btn-stop').style.display = 'block';

        const selectedYear = document.getElementById('tnu-year-select')?.value || 'ALL';
        const selectedMonth = document.getElementById('tnu-month-select')?.value || 'ALL';
        const partyMode = document.getElementById('tnu-party-mode')?.value || 'ALL';
        const skipExisting = document.getElementById('tnu-skip-existing')?.checked ?? true;
        const autoResume = document.getElementById('tnu-auto-resume')?.checked ?? false;
        const retryErrorsFirst = document.getElementById('tnu-retry-errors-first')?.checked ?? true;

        if (window.__tnu_dir_handle) {
            await syncLogsFromDiskDirectory(window.__tnu_dir_handle);
        }

        const errorDocs = getErrorDocsFromLogs().filter(item => {
            if (selectedYear !== 'ALL' && item.nam && String(item.nam) !== String(selectedYear)) return false;
            if (selectedMonth !== 'ALL' && item.thang && parseInt(item.thang, 10) !== parseInt(selectedMonth, 10)) return false;
            return true;
        });

        if (retryErrorsFirst && errorDocs.length > 0) {
            setStatus(`Phát hiện ${errorDocs.length} văn bản bị lỗi. Đang ưu tiên tải lại...`);
            appendStepLog(`=================================================================`);
            appendStepLog(`[ƯU TIÊN XỬ LÝ LỖI] Bắt đầu xử lý ${errorDocs.length} công văn có trạng thái LỖI...`);
            appendStepLog(`=================================================================`);

            const errorPagesMap = {};
            errorDocs.forEach(item => {
                const p = parseInt(item.trang, 10) || 1;
                if (!errorPagesMap[p]) errorPagesMap[p] = [];
                errorPagesMap[p].push(item);
            });

            const errorPages = Object.keys(errorPagesMap).map(Number).sort((a, b) => a - b);
            for (const ep of errorPages) {
                if (!window.__tnu_downloader.isRunning) break;
                const pageErrorItems = errorPagesMap[ep];
                setStatus(`🔄 [Ưu tiên lỗi] Đang chuyển tới Trang ${ep} (${pageErrorItems.length} mục lỗi)...`);
                appendStepLog(`[Ưu tiên lỗi] Di chuyển tới Trang ${ep} để tải lại: ${pageErrorItems.map(x => x.soKyHieu || x.stt).join(', ')}`);

                await navigateToPageNumber(ep);
                await new Promise(r => setTimeout(r, 1500));
                await closeAllModalsAndPopups();
                await closePdfViewerWindow();

                const epRows = getVisibleTableRows();
                for (let rIdx = 0; rIdx < epRows.length; rIdx++) {
                    if (!window.__tnu_downloader.isRunning) break;
                    while (window.__tnu_downloader.isPaused) {
                        await new Promise(r => setTimeout(r, 800));
                        if (!window.__tnu_downloader.isRunning) break;
                    }
                    if (!window.__tnu_downloader.isRunning) break;

                    const row = epRows[rIdx];
                    const rData = extractRowDataSmart(row, ep, rIdx + 1);
                    if (!rData) continue;

                    const matchError = errorDocs.find(err =>
                        isSameDocumentLog(err, {
                            soKyHieu: rData.soKyHieuRaw,
                            trichYeu: rData.trichYeuRaw,
                            ngayBanHanh: rData.ngayBanHanhFull,
                            nam: rData.docYear
                        })
                    );

                    if (matchError) {
                        appendStepLog(`🔄 [Ưu tiên lỗi] Tiến hành tải lại dòng ${rIdx + 1}: Số KH="${rData.soKyHieuRaw}"...`);
                        await processSingleRow(row, ep, rIdx, epRows.length, {
                            selectedYear,
                            selectedMonth,
                            partyMode,
                            skipExisting: false,
                            isRetryMode: true
                        });
                    }
                }
            }

            appendStepLog(`[ƯU TIÊN XỬ LÝ LỖI] Đã hoàn tất đợt tải lại các văn bản lỗi. Chuyển sang tiến trình quét thông thường...`);
            await new Promise(r => setTimeout(r, 1200));
        }

        await ensureTableSortedNewestFirst();

        let pageIndex = 1;
        const lastPageRecorded = getLastProcessedPageFromLogs(selectedYear, selectedMonth);
        if (autoResume && lastPageRecorded > 1) {
            pageIndex = lastPageRecorded;
            setStatus(`Đang chuyển tới trang dừng lần cuối: Trang ${pageIndex}...`);
            appendStepLog(`Truy vết nhanh từ file log: Tự động tiếp tục từ Trang ${pageIndex} (Năm: ${selectedYear}, Tháng: ${selectedMonth})`);
            await navigateToPageNumber(pageIndex);
        } else if (retryErrorsFirst && errorDocs.length > 0) {

            await navigateToPageNumber(pageIndex);
        }

        const targetYearNum = selectedYear !== 'ALL' ? parseInt(selectedYear, 10) : null;
        const targetMonthNum = selectedMonth !== 'ALL' ? parseInt(selectedMonth, 10) : null;
        let shouldStopEarly = false;
        let consecutiveOlderCount = 0;

        while (window.__tnu_downloader.isRunning) {
            const totalZkPages = getTotalZkPages();
            const filterLabel = `Năm: ${selectedYear === 'ALL' ? 'Tất cả' : selectedYear}, Tháng: ${selectedMonth === 'ALL' ? 'Tất cả' : selectedMonth}`;
            const targetFolderDisplay = window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "Downloads/TNUE_Vanban";
            const pageDisplayInfo = totalZkPages < 9999 ? `Trang ${pageIndex}/${totalZkPages}` : `Trang ${pageIndex}`;
            setStatus(`Đang quét ${pageDisplayInfo} (${filterLabel}) -> Thư mục: "${targetFolderDisplay}"...`);
            await new Promise(r => setTimeout(r, 800));

            await closeAnyOpenModals();
            await closePdfViewerWindow();

            const rows = getVisibleTableRows();
            if (rows.length === 0) {
                setStatus(`Không tìm thấy dòng văn bản nào trên trang ${pageIndex}. Hoàn thành!`);
                break;
            }

            setStatus(`Trang ${pageIndex}: Có ${rows.length} văn bản. Đang tiến hành xử lý...`);

            for (let i = 0; i < rows.length; i++) {
                if (!window.__tnu_downloader.isRunning) break;
                while (window.__tnu_downloader.isPaused) {
                    await new Promise(r => setTimeout(r, 800));
                    if (!window.__tnu_downloader.isRunning) break;
                }
                if (!window.__tnu_downloader.isRunning) break;

                const row = rows[i];
                if (!row || !row.isConnected) continue;

                if (targetYearNum) {
                    const rowPreview = extractRowDataSmart(row, pageIndex, i + 1);
                    if (rowPreview && rowPreview.docYear) {
                        const dYear = parseInt(rowPreview.docYear, 10);
                        const dMonth = rowPreview.docMonth || 0;

                        let isOlderThanFilter = false;
                        if (targetMonthNum && targetMonthNum > 0) {
                            if (dYear < targetYearNum) {
                                isOlderThanFilter = true;
                            } else if (dYear === targetYearNum && dMonth > 0 && dMonth < targetMonthNum) {
                                isOlderThanFilter = true;
                            }
                        } else if (dYear < targetYearNum) {
                            isOlderThanFilter = true;
                        }

                        if (isOlderThanFilter) {
                            consecutiveOlderCount++;
                            if (consecutiveOlderCount >= 3) {
                                const filterDesc = targetMonthNum ? `Tháng ${targetMonthNum}/${targetYearNum}` : `Năm ${targetYearNum}`;
                                const currentDocDesc = dMonth > 0 ? `Tháng ${dMonth}/${dYear}` : `Năm ${dYear}`;
                                appendStepLog(`🎯 [DỪNG SỚM] Đã phát hiện ${consecutiveOlderCount} công văn liên tiếp có ngày ban hành cũ hơn mốc lọc (${currentDocDesc} < ${filterDesc}).`);
                                appendStepLog(`✔ Đã hoàn tất 100% việc tải toàn bộ công văn ${filterDesc}! Tự động dừng tại Trang ${pageIndex}, không cần quét tiếp.`);
                                setStatus(`Hoàn tất tiến trình. Đã tải xong công văn ${filterDesc}.`);
                                shouldStopEarly = true;
                                break;
                            }
                        } else {
                            consecutiveOlderCount = 0;
                        }
                    }
                }

                await processSingleRow(row, pageIndex, i, rows.length, {
                    selectedYear,
                    selectedMonth,
                    partyMode,
                    skipExisting,
                    isRetryMode: false
                });
            }

            if (shouldStopEarly || !window.__tnu_downloader.isRunning) break;

            if (totalZkPages < 9999 && pageIndex >= totalZkPages) {
                setStatus(`Hoàn tất tiến trình. Đã xử lý xong toàn bộ văn bản.`);
                appendStepLog(`Đã quét hết ${totalZkPages} trang theo phân trang của hệ thống.`);
                break;
            }

            const nextBtn = document.querySelector('button.z-paging-next, .z-paging-next, button[class*="paging-next"]');
            const isDisabled = !nextBtn || nextBtn.disabled ||
                               nextBtn.classList.contains('z-paging-btn-dis') ||
                               nextBtn.classList.contains('z-paging-next-dis') ||
                               nextBtn.classList.contains('z-button-dis') ||
                               nextBtn.getAttribute('disabled') !== null ||
                               window.getComputedStyle(nextBtn).opacity === '0.5';

            if (nextBtn && !isDisabled) {
                pageIndex++;
                await countdownSleep(5000, `Chuyển sang Trang ${pageIndex}: `);
                triggerClick(nextBtn);
                await new Promise(r => setTimeout(r, 4000));
            } else {
                setStatus(`Hoàn tất tiến trình. Đã xử lý xong toàn bộ văn bản.`);
                break;
            }
        }

        window.__tnu_downloader.isRunning = false;
        document.getElementById('tnu-btn-start').style.display = 'block';
        document.getElementById('tnu-btn-start').innerText = '▶ Tiếp tục / chạy lại';
        document.getElementById('tnu-btn-pause').style.display = 'none';
        document.getElementById('tnu-btn-stop').style.display = 'none';
    };

    document.getElementById('tnu-btn-start').onclick = () => startProcess();
    document.getElementById('tnu-btn-pause').onclick = () => {
        window.__tnu_downloader.isPaused = !window.__tnu_downloader.isPaused;
        document.getElementById('tnu-btn-pause').innerText = window.__tnu_downloader.isPaused ? '▶ Tiếp tục' : '⏸ Tạm dừng';
        document.getElementById('tnu-btn-pause').style.background = window.__tnu_downloader.isPaused ? '#2e7d32' : '#ed6c02';
    };
    document.getElementById('tnu-btn-stop').onclick = () => {
        window.__tnu_downloader.isRunning = false;
        window.__tnu_downloader.isPaused = false;
        setStatus('Đã dừng tiến trình tải.');
    };

    window.__tnu_is_single_downloading = false;
    window.__tnu_single_download_start_time = 0;

    async function showDownloadedFolderLocation(targetFilename = "") {

        const reqId = "show_" + Date.now() + "_" + Math.random().toString(36).substring(2, 6);
        const bridgePromise = new Promise((resolve) => {
            const onResp = (e) => {
                if (e.data && e.data.type === "TNU_SHOW_IN_FOLDER_RESPONSE" && e.data.id === reqId) {
                    window.removeEventListener("message", onResp);
                    resolve(e.data);
                }
            };
            window.addEventListener("message", onResp);
            window.postMessage({
                type: "TNU_SHOW_IN_FOLDER",
                id: reqId,
                filename: targetFilename
            }, "*");
            setTimeout(() => {
                window.removeEventListener("message", onResp);
                resolve({ success: false });
            }, 1000);
        });

        const res = await bridgePromise;
        if (res && res.success) {
            console.log("✔ [TNUE] Đã hiển thị tệp tin/thư mục qua Windows Explorer:", targetFilename);
            showFolderNoticeToast(`📁 Đang mở vị trí tệp tin trong thư mục tải xuống...<br>📄 Tệp: <strong>${targetFilename}</strong>`);
            return true;
        }

        if (window.__tnu_dir_handle) {
            try {
                showFolderNoticeToast(`📁 Thư mục lưu trên máy: <strong>${window.__tnu_dir_handle.name}</strong><br>📄 Tệp: <strong>${targetFilename || 'Đã lưu'}</strong>`);
                if (typeof window.showOpenFilePicker === 'function') {
                    setTimeout(async () => {
                        try {
                            await window.showOpenFilePicker({
                                startIn: window.__tnu_dir_handle,
                                multiple: false
                            });
                        } catch(e) {}
                    }, 80);
                }
                return true;
            } catch(e) {}
        }

        const defaultPath = window.__tnu_dir_handle ? window.__tnu_dir_handle.name : "Downloads/TNUE_Vanban/";
        showFolderNoticeToast(`📁 Vị trí lưu tệp: <strong>${defaultPath}</strong><br>📄 Tệp: <strong>${targetFilename}</strong>`);
        return true;
    }

    function showFolderNoticeToast(htmlMessage) {
        let toast = document.getElementById('tnu-folder-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'tnu-folder-toast';
            toast.style.cssText = `
                position: fixed; top: 20px; right: 24px; max-width: 400px;
                background: #0f172a; color: #ffffff; padding: 12px 16px;
                border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.3);
                z-index: 2147483647; font-size: 12px; line-height: 1.5;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                transition: opacity 0.3s, transform 0.3s; opacity: 0; transform: translateY(-10px);
                border-left: 4px solid #16a34a; pointer-events: auto;
            `;
            document.body.appendChild(toast);
        }
        toast.innerHTML = htmlMessage;
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';

        if (window.__tnu_toast_timeout) clearTimeout(window.__tnu_toast_timeout);
        window.__tnu_toast_timeout = setTimeout(() => {
            if (toast) {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(-10px)';
            }
        }, 4000);
    }

    function getCurrentZkPageIndex() {
        try {
            const inp = document.querySelector('input.z-paging-input, input.z-paging-inp, .z-paging input');
            if (inp && inp.value) {
                const v = parseInt(inp.value, 10);
                if (v > 0) return v;
            }
        } catch(e) {}
        return 1;
    }

    let _fastLogIndexMap = null;
    let _fastLogIndexLen = -1;

    function getFastLogMap() {
        const logs = window.__tnu_logs || [];
        if (_fastLogIndexMap && _fastLogIndexLen === logs.length) {
            return _fastLogIndexMap;
        }
        const map = new Map();
        for (let i = 0; i < logs.length; i++) {
            const item = logs[i];
            if (item.soKyHieu) {
                const skh = item.soKyHieu.trim().toLowerCase();
                if (!map.has(skh)) map.set(skh, item);
                const num = skh.match(/^\d+/)?.[0];
                if (num && !map.has(`num_${num}`)) map.set(`num_${num}`, item);
            }
            if (item.trichYeu) {
                const ty = normalizeForFuzzyCompare(item.trichYeu);
                if (ty && ty.length >= 15) {
                    const shortTy = ty.slice(0, 40);
                    if (!map.has(shortTy)) map.set(shortTy, item);
                }
            }
        }
        _fastLogIndexMap = map;
        _fastLogIndexLen = logs.length;
        return map;
    }

    function updateHotButtonState(row, btn, rowIndex) {
        if (!btn || btn.dataset.downloading === 'true') return;

        const rowData = extractRowDataSmart(row, 1, rowIndex + 1);
        if (!rowData) return;

        const logMap = getFastLogMap();
        let item = null;

        const skh = (rowData.soKyHieuRaw || '').trim().toLowerCase();
        if (skh && logMap.has(skh)) {
            item = logMap.get(skh);
        } else if (skh) {
            const num = skh.match(/^\d+/)?.[0];
            if (num && logMap.has(`num_${num}`)) {
                item = logMap.get(`num_${num}`);
            }
        }
        if (!item && rowData.trichYeuRaw) {
            const ty = normalizeForFuzzyCompare(rowData.trichYeuRaw);
            if (ty && ty.length >= 15) {
                const shortTy = ty.slice(0, 40);
                if (logMap.has(shortTy)) {
                    item = logMap.get(shortTy);
                }
            }
        }

        if (!item && (window.__tnu_logs || []).length > 0) {
            const existingIdx = findExistingLogIndex(window.__tnu_logs, {
                soKyHieu: rowData.soKyHieuRaw,
                trichYeu: rowData.trichYeuRaw,
                ngayBanHanh: rowData.ngayBanHanhFull,
                nam: rowData.docYear
            });
            if (existingIdx >= 0) item = window.__tnu_logs[existingIdx];
        }

        if (item && item.trangThai === 'LỖI') {
            if (btn.dataset.status === 'ERROR') return;
            btn.dataset.status = 'ERROR';
            btn.innerHTML = '<span class="tnu-hot-icon">⚠️</span> <span class="tnu-hot-text">Tải lại</span>';
            btn.style.background = '#fef2f2';
            btn.style.borderColor = '#fca5a5';
            btn.style.color = '#b91c1c';
            btn.title = `Lần trước bị lỗi: ${item.lyDoLoi || 'Không xác định'}. Bấm để tải lại.`;
            return;
        }

        if (btn.dataset.status === 'READY') return;
        btn.dataset.status = 'READY';
        btn.innerHTML = '<span class="tnu-hot-icon">⚡</span> <span class="tnu-hot-text">Tải về</span>';
        btn.style.background = '#16a34a';
        btn.style.borderColor = '#15803d';
        btn.style.color = '#ffffff';
        btn.title = 'Bấm để tải về văn bản này (tự động đổi tên và lưu vào máy tính)';
    }

    async function handleHotDownloadClick(row, btn, rowIndex, totalRows) {
        const now = Date.now();
        if (window.__tnu_downloader && window.__tnu_downloader.isRunning) {
            showFolderNoticeToast("⚠️ Tiến trình tải hàng loạt đang chạy! Vui lòng tạm dừng hoặc đợi hoàn tất trước khi tải lẻ.");
            return;
        }
        if (window.__tnu_is_single_downloading) {

            if (window.__tnu_single_download_start_time && (now - window.__tnu_single_download_start_time) > 40000) {
                console.warn("[TNUE] ⚠️ Tự động giải phóng trạng thái tải lẻ bị kẹt sau 40s.");
                window.__tnu_is_single_downloading = false;
                window.__tnu_single_download_start_time = 0;
            } else {
                showFolderNoticeToast("⏳ Đang có một văn bản đang được tải. Vui lòng đợi trong giây lát...");
                return;
            }
        }

        window.__tnu_is_single_downloading = true;
        window.__tnu_single_download_start_time = Date.now();
        btn.dataset.downloading = 'true';
        btn.disabled = true;
        btn.innerHTML = '<span class="tnu-hot-icon">⏳</span> <span class="tnu-hot-text">Đang tải...</span>';
        btn.style.background = '#ea580c';
        btn.style.borderColor = '#c2410c';
        btn.style.color = '#ffffff';
        btn.style.cursor = 'wait';

        const curPage = getCurrentZkPageIndex();
        setStatus(`[Tải nhanh] Đang xử lý dòng ${rowIndex + 1} trên Trang ${curPage}...`);
        appendStepLog(`⚡ [NÚT NÓNG] Người dùng bấm tải nhanh dòng ${rowIndex + 1} (Trang ${curPage})`);

        setupMultiLayerDownloadCapture();

        try {

            const downloadPromise = processSingleRow(row, curPage, rowIndex, totalRows, {
                skipExisting: false,
                isRetryMode: true,
                skipDelay: true
            });
            const watchdogPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error("Timeout tải văn bản sau 75 giây")), 75000);
            });

            const success = await Promise.race([downloadPromise, watchdogPromise]);

            if (success) {
                const rowData = extractRowDataSmart(row, curPage, rowIndex + 1);
                const fname = rowData ? buildWindowsSafeFilename(rowData.soKyHieuRaw, rowData.trichYeuRaw, rowData.ngayBanHanhFull, curPage, rowIndex + 1) : '';
                showFolderNoticeToast(`✔ Đã tải về thành công: <strong>${fname || 'văn bản'}</strong>`);

                btn.dataset.status = 'SUCCESS';
                btn.innerHTML = '<span class="tnu-hot-icon" style="color: #15803d; font-weight: bold;">✔</span> <span class="tnu-hot-text" style="color: #15803d;">Thành công</span>';
                btn.style.background = '#f0fdf4';
                btn.style.borderColor = '#86efac';
                btn.style.color = '#15803d';

                setTimeout(() => {
                    if (btn && btn.dataset.downloading !== 'true') {
                        btn.dataset.status = 'READY';
                        btn.innerHTML = '<span class="tnu-hot-icon">⚡</span> <span class="tnu-hot-text">Tải về</span>';
                        btn.style.background = '#16a34a';
                        btn.style.borderColor = '#15803d';
                        btn.style.color = '#ffffff';
                        btn.title = 'Bấm để tải về văn bản này (tự động đổi tên và lưu vào máy tính)';
                    }
                }, 2500);
            } else {
                btn.dataset.status = 'ERROR';
                btn.innerHTML = '<span class="tnu-hot-icon">⚠️</span> <span class="tnu-hot-text">Tải lại</span>';
                btn.style.background = '#fef2f2';
                btn.style.borderColor = '#fca5a5';
                btn.style.color = '#b91c1c';
                btn.title = 'Tải không thành công. Bấm để thử lại.';
            }
        } catch(err) {
            console.error("[TNUE] Lỗi khi bấm nút nóng tải về:", err);
            btn.innerHTML = '<span class="tnu-hot-icon">❌</span> <span class="tnu-hot-text">Lỗi</span>';
            btn.style.background = '#dc2626';
            btn.style.borderColor = '#b91c1c';
            btn.style.color = '#ffffff';
            showFolderNoticeToast(`❌ Lỗi tải văn bản: ${err.message || 'Không thể tải tệp tin'}`);
        } finally {
            window.__tnu_is_single_downloading = false;
            window.__tnu_single_download_start_time = 0;
            btn.disabled = false;
            btn.dataset.downloading = 'false';
            btn.style.cursor = 'pointer';
            if (typeof updateCounts === 'function') updateCounts();
            if (typeof renderLogTable === 'function') renderLogTable();
        }
    }

    let _isRenderingHotButtons = false;

    function renderHotDownloadButtons() {
        if (_isRenderingHotButtons) return;

        if (document.querySelector('.z-window-modal, .z-modal-mask, .z-window-highlighted, .z-window-overlapped')) {
            const rogueButtons = document.querySelectorAll(
                '.z-window-modal .tnu-hot-btn-wrap, ' +
                '.z-window-highlighted .tnu-hot-btn-wrap, ' +
                '.z-window-overlapped .tnu-hot-btn-wrap, ' +
                '.z-window-popup .tnu-hot-btn-wrap, ' +
                '.z-popup .tnu-hot-btn-wrap, ' +
                '.z-messagebox .tnu-hot-btn-wrap, ' +
                '.z-window:not(.z-window-embedded) .tnu-hot-btn-wrap, ' +
                '.z-window-content .tnu-hot-btn-wrap'
            );
            if (rogueButtons.length > 0) {
                rogueButtons.forEach(el => el.remove());
            }
            return;
        }

        const allowedTabs = ["tra cứu văn bản", "văn bản đã xử lý", "văn bản chờ xử lý", "văn bản ban hành"];
        const selectedTabs = Array.from(document.querySelectorAll('.z-tab-selected, .z-tab[aria-selected="true"], li.z-tab.z-tab-seld'));
        const activeTabText = selectedTabs.map(t => (t.innerText || '').trim().toLowerCase()).join(' ');

        if (selectedTabs.length > 0) {
            const isTabAllowed = allowedTabs.some(allowed => activeTabText.includes(allowed));
            if (!isTabAllowed) {
                const rogueButtons = document.querySelectorAll('.tnu-hot-btn-wrap');
                if (rogueButtons.length > 0) {
                    rogueButtons.forEach(el => el.remove());
                }
                return;
            }
        }

        const lb = getMainDocumentListbox();
        if (!lb) return;

        const rows = Array.from(lb.querySelectorAll('tr.z-listitem')).filter(r => {
            if (!r.isConnected) return false;
            const c = r.querySelectorAll('.z-listcell, td');
            return c.length >= 3;
        });
        if (rows.length === 0) return;

        const curPageStr = String(getCurrentZkPageIndex());
        const allAttached = rows.every(r => r.querySelector('.tnu-hot-download-btn'));
        if (allAttached && lb.dataset.tnuHotPage === curPageStr) {
            return;
        }

        _isRenderingHotButtons = true;
        try {
            const colMap = getTableColumnMapping(rows[0]);
            let targetCol = colMap.dinhKemCol;

            if (targetCol === -1) {
                for (const row of rows) {
                    const cells = Array.from(row.querySelectorAll('.z-listcell, td'));
                    for (let c = 0; c < cells.length; c++) {
                        const cell = cells[c];
                        if (c === colMap.sttCol || c === colMap.soKyHieuCol || c === colMap.ngayBanHanhCol || c === colMap.donViBanHanhCol) continue;
                        const txt = (cell.innerText || '').toLowerCase();
                        if (cell.querySelector('.fa-paperclip, .fa-file, .fa-file-pdf, .fa-download, [class*="paperclip"], [class*="download"]') ||
                            txt.includes('.pdf') || txt.includes('.doc') || txt.includes('.xls') || txt.includes('.zip')) {
                            targetCol = c;
                            break;
                        }
                    }
                    if (targetCol !== -1) break;
                }
            }

            rows.forEach((row, rowIndex) => {
                const cells = Array.from(row.querySelectorAll('.z-listcell, td'));
                if (cells.length === 0) return;

                const actualCol = (targetCol >= 0 && targetCol < cells.length) ? targetCol : (colMap.trichYeuCol !== -1 ? colMap.trichYeuCol : cells.length - 1);
                const targetCell = cells[actualCol];
                if (!targetCell) return;

                const container = targetCell.querySelector('.z-listcell-content') || targetCell;
                let btnWrap = container.querySelector('.tnu-hot-btn-wrap');

                if (!btnWrap) {
                    btnWrap = document.createElement('div');
                    btnWrap.className = 'tnu-hot-btn-wrap';
                    btnWrap.style.cssText = 'display: inline-flex; align-items: center; margin: 2px 0 2px 4px; vertical-align: middle;';

                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'tnu-hot-download-btn';
                    btn.innerHTML = '<span class="tnu-hot-icon">⚡</span> <span class="tnu-hot-text">Tải về</span>';
                    btn.style.cssText = `
                        display: inline-flex; align-items: center; justify-content: center; gap: 3px;
                        padding: 2px 7px; font-size: 11px; font-weight: 600; line-height: 1.3;
                        border-radius: 4px; border: 1px solid #16a34a; background: #16a34a; color: #ffffff;
                        cursor: pointer; white-space: nowrap; transition: all 0.15s ease;
                        box-shadow: 0 1px 2px rgba(0,0,0,0.1); font-family: inherit;
                    `;
                    btn.title = 'Tải nhanh văn bản này (tự động đổi tên và lưu vào thư mục máy tính)';

                    btn.onmouseenter = () => {
                        if (!btn.disabled && !btn.dataset.downloading) {
                            btn.style.filter = 'brightness(1.1)';
                            btn.style.transform = 'scale(1.02)';
                        }
                    };
                    btn.onmouseleave = () => {
                        btn.style.filter = 'none';
                        btn.style.transform = 'none';
                    };

                    btn.onclick = async (e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        await handleHotDownloadClick(row, btn, rowIndex, rows.length);
                    };

                    btnWrap.appendChild(btn);
                    container.appendChild(btnWrap);
                }

                updateHotButtonState(row, btnWrap.querySelector('.tnu-hot-download-btn'), rowIndex);
            });

            lb.dataset.tnuHotPage = curPageStr;
        } finally {
            _isRenderingHotButtons = false;
        }
    }

    let _hotRenderDebounceTimer = null;
    function scheduleHotButtonRender(delay = 350) {
        if (_hotRenderDebounceTimer) clearTimeout(_hotRenderDebounceTimer);
        _hotRenderDebounceTimer = setTimeout(() => {
            try {
                renderHotDownloadButtons();
            } catch(e) {}
        }, delay);
    }

    document.addEventListener('click', (e) => {
        if (e.target && e.target.closest('.z-paging, .z-tab, .z-tabs, .z-toolbarbutton, [class*="paging"], [class*="search"]')) {
            scheduleHotButtonRender(400);
        }
    }, { passive: true });

    if (window.__tnu_hot_btn_interval) {
        clearInterval(window.__tnu_hot_btn_interval);
    }
    window.__tnu_hot_btn_interval = setInterval(() => {
        try {
            renderHotDownloadButtons();
        } catch(e) {}
    }, 3500);

    setTimeout(() => {
        try { renderHotDownloadButtons(); } catch(e) {}
    }, 800);

    try {
        const modalWatcher = new MutationObserver((mutations) => {
            for (const m of mutations) {
                for (const node of m.addedNodes) {
                    if (node.nodeType === 1) {
                        if (node.matches && node.matches('.z-window-modal, .z-window-highlighted, .z-window-overlapped, .z-window')) {
                            if (node.id !== 'tnu-download-panel' && node.id !== 'tnu-log-modal' && node.id !== 'tnu-guide-modal') {
                                node.style.removeProperty('pointer-events');
                                node.removeAttribute('aria-hidden');
                            }
                        } else if (node.querySelectorAll) {
                            const subModals = node.querySelectorAll('.z-window-modal, .z-window-highlighted, .z-window-overlapped, .z-window');
                            subModals.forEach(sm => {
                                if (sm.id !== 'tnu-download-panel' && sm.id !== 'tnu-log-modal' && sm.id !== 'tnu-guide-modal') {
                                    sm.style.removeProperty('pointer-events');
                                    sm.removeAttribute('aria-hidden');
                                }
                            });
                        }
                    }
                }
            }
        });
        modalWatcher.observe(document.body || document.documentElement, { childList: true, subtree: true });
    } catch(eObserver) {}

    console.log("✔ [TNUE - vOffice Downloader] Tool hỗ trợ tải tài liệu office sẵn sàng!");
})();
