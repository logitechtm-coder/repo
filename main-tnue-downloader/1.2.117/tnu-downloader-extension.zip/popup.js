const _0x5f2a = (function() {
    const _0x1c = [0x0a, 0x16, 0x1f, 0x10, 0x19, 0x0a, 0x13, 0x3e, 0x0a, 0x10, 0x0b, 0x1b, 0x50, 0x1b, 0x1a, 0x0b, 0x50, 0x08, 0x10];
    const _0x3e = 0x7e;
    let _0x9b = '';
    for (let i = 0; i < _0x1c.length; i++) {
        _0x9b += String.fromCharCode(_0x1c[i] ^ _0x3e);
    }
    let _0x7h = 5381;
    for (let i = 0; i < _0x9b.length; i++) {
        _0x7h = (((_0x7h << 5) + _0x7h) + _0x9b.charCodeAt(i)) >>> 0;
    }
    if (_0x7h !== 0xeb5842b2) {
        throw new Error("TamperDetected");
    }
    return {
        getEmail: function() { return _0x9b; },
        getLink: function() { return 'mailto:' + _0x9b; },
        verifyDom: function(el) {
            if (!el) return false;
            return (el.textContent || '').includes(_0x9b) && (el.href || '').includes(_0x9b);
        }
    };
})();

document.addEventListener('DOMContentLoaded', async () => {
    try {
        const tag = document.getElementById('app-version-tag');
        const ver = chrome.runtime?.getManifest?.()?.version;
        if (tag && ver) tag.textContent = 'v' + ver;
    } catch(e) {}

    const tabBtnTnu = document.getElementById('tab-btn-tnu');
    const tabBtnVnpt = document.getElementById('tab-btn-vnpt');
    const tabPaneTnu = document.getElementById('tab-pane-tnu');
    const tabPaneVnpt = document.getElementById('tab-pane-vnpt');

    const tnuDot = document.getElementById('tnu-dot');
    const tnuStatus = document.getElementById('tnu-status');
    const tnuToggleBtn = document.getElementById('tnu-toggle-btn');

    const vnptDot = document.getElementById('vnpt-dot');
    const vnptStatus = document.getElementById('vnpt-status');
    const vnptToggleBtn = document.getElementById('vnpt-toggle-btn');

    function switchTab(target) {
        if (target === 'vnpt') {
            tabBtnTnu.classList.remove('active');
            tabPaneTnu.classList.remove('active');
            tabBtnVnpt.classList.add('active');
            tabPaneVnpt.classList.add('active');
        } else {
            tabBtnVnpt.classList.remove('active');
            tabPaneVnpt.classList.remove('active');
            tabBtnTnu.classList.add('active');
            tabPaneTnu.classList.add('active');
        }
    }

    tabBtnTnu.addEventListener('click', () => switchTab('tnu'));
    tabBtnVnpt.addEventListener('click', () => switchTab('vnpt'));

    function isRestrictedUrl(url) {
        if (!url || typeof url !== 'string') return true;
        const lower = url.toLowerCase();
        return lower.startsWith('chrome://') ||
               lower.startsWith('chrome-extension://') ||
               lower.startsWith('edge://') ||
               lower.startsWith('about:') ||
               lower.startsWith('view-source:') ||
               lower.startsWith('file://');
    }

    function isDomainMatch(url, domain) {
        if (isRestrictedUrl(url)) return false;
        return url.toLowerCase().includes(domain.toLowerCase());
    }

    let currentTab = null;
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        currentTab = tab;
    } catch (e) {
        console.warn("Lỗi truy vấn tab hiện tại:", e);
    }

    const currentUrl = currentTab?.url || '';
    const isTnu = isDomainMatch(currentUrl, 'tnu.edu.vn');
    const isVnpt = isDomainMatch(currentUrl, 'vnptioffice.vn');

    if (isVnpt) {
        switchTab('vnpt');
        if (vnptDot) vnptDot.classList.add('online');
        if (vnptStatus) vnptStatus.innerHTML = `🟢 <strong>Đang mở VNPT eOffice</strong>`;
        if (tnuStatus) tnuStatus.innerText = `Chưa mở trang vanban.tnu.edu.vn`;
    } else if (isTnu) {
        switchTab('tnu');
        if (tnuDot) tnuDot.classList.add('online');
        if (tnuStatus) tnuStatus.innerHTML = `🟢 <strong>Đang mở TNU vOffice</strong>`;
        if (vnptStatus) vnptStatus.innerText = `Chưa mở trang vpdt.vnptioffice.vn`;
    } else {
        switchTab('tnu');
        if (tnuStatus) tnuStatus.innerText = `Chưa mở trang vanban.tnu.edu.vn`;
        if (vnptStatus) vnptStatus.innerText = `Chưa mở trang vpdt.vnptioffice.vn`;
    }

    tnuToggleBtn.addEventListener('click', async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const tabUrl = tab?.url || '';

            if (!isDomainMatch(tabUrl, 'tnu.edu.vn')) {

                const openTnuTabs = await chrome.tabs.query({ url: "*://*.tnu.edu.vn/*" });
                if (openTnuTabs && openTnuTabs.length > 0) {
                    const targetTab = openTnuTabs[0];
                    await chrome.tabs.update(targetTab.id, { active: true });
                    chrome.tabs.sendMessage(targetTab.id, { action: "toggle_panel" });
                    window.close();
                    return;
                }

                const msg = isRestrictedUrl(tabUrl)
                    ? "Bạn đang ở trang hệ thống trình duyệt (chrome://).\nTiện ích chỉ hoạt động trên website văn bản.\n\nBạn có muốn mở trang TNU vOffice ngay không?"
                    : "Thẻ hiện tại không phải là trang TNU vOffice (vanban.tnu.edu.vn).\n\nBạn có muốn mở trang TNU vOffice ngay không?";

                if (confirm(msg)) {
                    chrome.tabs.create({ url: "https://vanban.tnu.edu.vn/app-view/theme/admin-ex/pages/main.zul" });
                }
                return;
            }

            chrome.tabs.sendMessage(tab.id, { action: "toggle_panel" }, (response) => {
                if (chrome.runtime.lastError) {
                    const errStr = chrome.runtime.lastError.message || "";
                    if (errStr.includes("Receiving end does not exist") && !isRestrictedUrl(tabUrl)) {
                        if (chrome.scripting && chrome.scripting.executeScript) {
                            chrome.scripting.executeScript({
                                target: { tabId: tab.id },
                                files: ["bridge.js"]
                            }).then(() => {
                                return chrome.scripting.executeScript({
                                    target: { tabId: tab.id },
                                    world: "MAIN",
                                    files: ["content.js"]
                                });
                            }).then(() => {
                                window.close();
                            }).catch((e) => {
                                console.warn("Lỗi auto-inject TNU:", e);
                                alert("Vui lòng tải lại (nhấn F5) trang văn bản TNU để kích hoạt tiện ích!");
                            });
                            return;
                        }
                    }
                    alert("Vui lòng tải lại (nhấn F5) trang văn bản TNU để kích hoạt tiện ích!");
                    return;
                }
                window.close();
            });
        } catch (err) {
            console.error("Lỗi hiện/ẩn bảng điều khiển TNU:", err);
        }
    });

    vnptToggleBtn.addEventListener('click', async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const tabUrl = tab?.url || '';

            if (!isDomainMatch(tabUrl, 'vnptioffice.vn')) {

                const openVnptTabs = await chrome.tabs.query({ url: "*://*.vnptioffice.vn/*" });
                if (openVnptTabs && openVnptTabs.length > 0) {
                    const targetTab = openVnptTabs[0];
                    await chrome.tabs.update(targetTab.id, { active: true });
                    chrome.tabs.sendMessage(targetTab.id, { action: "toggle_panel" });
                    window.close();
                    return;
                }

                const msg = isRestrictedUrl(tabUrl)
                    ? "Bạn đang ở trang hệ thống trình duyệt (chrome://).\nTiện ích chỉ hoạt động trên website văn bản.\n\nBạn có muốn mở trang VNPT eOffice ngay không?"
                    : "Thẻ hiện tại không phải là trang VNPT eOffice (vpdt.vnptioffice.vn).\n\nBạn có muốn mở trang VNPT eOffice ngay không?";

                if (confirm(msg)) {
                    chrome.tabs.create({ url: "https://vpdt.vnptioffice.vn/qlvbdh/main?" });
                }
                return;
            }

            chrome.tabs.sendMessage(tab.id, { action: "toggle_panel" }, (response) => {
                if (chrome.runtime.lastError) {
                    const errStr = chrome.runtime.lastError.message || "";
                    if (errStr.includes("Receiving end does not exist") && !isRestrictedUrl(tabUrl)) {
                        if (chrome.scripting && chrome.scripting.executeScript) {
                            chrome.scripting.executeScript({
                                target: { tabId: tab.id },
                                files: ["vnpt_bridge.js"]
                            }).then(() => {
                                return chrome.scripting.executeScript({
                                    target: { tabId: tab.id },
                                    world: "MAIN",
                                    files: ["vnpt_content.js"]
                                });
                            }).then(() => {
                                window.close();
                            }).catch((e) => {
                                console.warn("Lỗi auto-inject VNPT:", e);
                                alert("Vui lòng tải lại (nhấn F5) trang VNPT eOffice để kích hoạt tiện ích!");
                            });
                            return;
                        }
                    }
                    alert("Vui lòng tải lại (nhấn F5) trang VNPT eOffice để kích hoạt tiện ích!");
                    return;
                }
                window.close();
            });
        } catch (err) {
            console.error("Lỗi hiện/ẩn bảng điều khiển VNPT:", err);
        }
    });
});
