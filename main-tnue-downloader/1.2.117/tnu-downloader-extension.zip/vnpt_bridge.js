const _0x5f2a = (function() {
    const _0x1c = [0x0a, 0x16, 0x1f, 0x10, 0x19, 0x0a, 0x13, 0x3e, 0x0a, 0x10, 0x0b, 0x1b, 0x50, 0x1b, 0x1a, 0x0b, 0x50, 0x08, 0x10];
    const _0x3e = 0x7e;
    let _0x9b = '';
    for (let i = 0; i < _0x1c.length; i++) {
        _0x9b += String.fromCharCode(_0x1c[i] ^ _0x3e);
    }
    let _0x7h = 5381;
    for (let i = 0; i < _0x9b.length; i++) {
        _0x7h = (((_0x7h << 5) + _0x7h) + _0x9b.charCodeAt(i)) >>> 0;
    }
    if (_0x7h !== 0xeb5842b2) {
        throw new Error("TamperDetected");
    }
    return {
        getEmail: function() { return _0x9b; },
        getLink: function() { return 'mailto:' + _0x9b; },
        verifyDom: function(el) {
            if (!el) return false;
            return (el.textContent || '').includes(_0x9b) && (el.href || '').includes(_0x9b);
        }
    };
})();

(function() {
    const extVersion = (typeof chrome !== 'undefined' && chrome.runtime?.getManifest?.()?.version) || '';
    if (extVersion) {
        if (document.documentElement) {
            document.documentElement.setAttribute('data-app-version', extVersion);
        }
        const updateBadges = () => {
            document.querySelectorAll('.tnu-version-badge, .vnpt-version-badge').forEach(el => {
                if (el.textContent !== 'v' + extVersion) {
                    el.textContent = 'v' + extVersion;
                }
            });
        };
        updateBadges();
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', updateBadges, { once: true });
        }
        window.addEventListener('load', updateBadges, { once: true });
    }

    console.log("✔ [VNPT eOffice Downloader] Đã kết nối cầu nối Extension VNPT.");

    window.addEventListener("message", (event) => {
        if (!event.data) return;

        if (event.data.type === "VNPT_DOWNLOAD_REQUEST") {
            const { item } = event.data;
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({
                    action: "vnpt_download_one",
                    item: item
                }, (response) => {
                    window.postMessage({
                        type: "VNPT_DOWNLOAD_RESPONSE",
                        id: item.docId,
                        filename: item.filename,
                        res: response
                    }, "*");
                });
            }
        }

        if (event.data.type === "VNPT_SHOW_IN_FOLDER") {
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({
                    action: "show_in_folder",
                    filename: event.data.filename
                });
            }
        }

        if (event.data.type === "VNPT_CHECK_UPDATE") {
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({ action: "check_app_version" }, (response) => {
                    window.postMessage({
                        type: "VNPT_CHECK_UPDATE_RES",
                        result: response
                    }, "*");
                });
            }
        }
    });

    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
            if (msg.action === "toggle_panel" || msg.action === "toggle_vnpt_panel") {
                window.postMessage({ type: "VNPT_TOGGLE_PANEL" }, "*");
                sendResponse({ success: true });
                return true;
            }
            if (msg.action === "download_completed" || msg.action === "download_interrupted") {
                window.postMessage({
                    type: "VNPT_DOWNLOAD_STATUS",
                    action: msg.action,
                    downloadId: msg.downloadId,
                    error: msg.error
                }, "*");
            }
        });
    }
})();
